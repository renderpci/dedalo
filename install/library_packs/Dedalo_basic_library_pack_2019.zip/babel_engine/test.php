<?php #die("Sorry: Service temporarily unavailable");
# set errors to display
ini_set('error_reporting', E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);

# include class
include_once('class.Babel_trad.php');

# need request vars $text, $direction, $markUnknown
#$Babel_trad	= new Babel_trad();

#$trad 		= $Babel_trad->translate();

/* Establecer configuración regional al holandés */
setlocale(LC_ALL, 'es_ES.UTF-8');	#setlocale(LC_ALL, "en_US.UTF-8");

#echo exec('locale charmap');
#echo system('locale -a');

echo "<hr>";

$sourceString 	= 'hola mundo camión niño';
$asciiString 	= mb_convert_encoding ($sourceString, 'US-ASCII', 'UTF-8');

$trad 			= shell_exec(" LANG=es_ES.utf-8 | echo 'hola mundo camión niño' | LANG=es_ES.utf-8 /usr/local/bin/apertium es-en "); var_dump($trad);

#echo "<hr>";
#echo shell_exec('echo éêèëàâäîïùûüôöç');
 // This is the function that fixes accented characters.
function fix_string($str) {
	return strtr($str,
		chr(130).chr(136).chr(138).chr(137).
		chr(133).chr(131).chr(132).chr(140).
		chr(139).chr(151).chr(150).chr(129).
		chr(147).chr(148).chr(135),
		chr(233).chr(234).chr(232).chr(235).
		chr(224).chr(226).chr(228).chr(238).
		chr(239).chr(249).chr(251).chr(252).
		chr(244).chr(246).chr(231)
	);
}
#echo fix_string(shell_exec('echo éêèëàâäîïùûüôöç'));
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
# show result
if($trad) print( "<hr>".$trad ) ;
?>
</body>
</html>
