<?php
require_once("config/apertium-config.php");


class Babel_trad {

	protected $ar_valid_ip = array();
	
	protected $text;
	protected $direction;
	protected $mark;
	protected $markUnknown;
	protected $enc;				# encoding
	protected $trad;			# traduction text
	protected $cmd;
	protected $debug = false;	
	
	public function __construct() {
		
		$this->set_ar_valid_ip();
		$this->validate_source_ip();
		
		$this->set_vars();		
	}
	
	# MAP DIRECTIONS FROM DEDALO TO BABEL
	private function map_direction($direction) {
		
		$ar_direction	= explode('-',$direction);
		
		if(!is_array($ar_direction)) die(__METHOD__ ." Babel Error: direction is invalid: $direction ");
		
		$source_lang	= $ar_direction[0];
		$target_lang	= $ar_direction[1];		
		
		if($source_lang=='sp') $source_lang='es';
		
		if($target_lang=='sp') $target_lang='es';
		
		
		# source vl (valenciá)
		if($source_lang=='vl' && $target_lang=='ca') {
			$source_lang = 'val-es';	
		}else if($source_lang=='vl' && $target_lang=='es') {
			#$source_lang = 'val-ca';
			$source_lang = 'ca';
		}else if($source_lang=='vl') {
			$source_lang = 'ca';
		}
		
		# target vl (valenciá)
		if($target_lang=='vl' && $source_lang=='es') {
			$target_lang='ca_valencia';
		}else if($target_lang=='vl') {
			$target_lang='ca';
		}
	
		
		return $source_lang .'-'. $target_lang ;
	}
	
	# SET VALID IP's
	protected function set_ar_valid_ip() {
		
		$this->ar_valid_ip[] = '95.17.26.142';		# jazztel despacho calle denia
		$this->ar_valid_ip[] = '95.17.27.188';		# jazztel despacho calle denia
		$this->ar_valid_ip[] = '95.17.26.189';		# jazztel despacho calle denia
		$this->ar_valid_ip[] = '95.19.70.67';		# jazztel despacho calle denia
		$this->ar_valid_ip[] = '37.14.216.169';		# jazztel despacho calle denia
		
		$this->ar_valid_ip[] = '87.219.53.221';		# jazztel benimamet
		$this->ar_valid_ip[] = '37.15.22.112';		# jazztel benimamet
		
		$this->ar_valid_ip[] = '83.247.136.16';		# Memorial Democratic Barcelona		
		
		$this->ar_valid_ip[] = '87.106.212.13';		# Servidor dedicado fmomo.org (demo)
		
		$this->ar_valid_ip[] = '195.77.17.226';		# Servidor Plaza Manises museudelaparaula.es (muvaet)
		$this->ar_valid_ip[] = '193.145.205.223';	# Servidor Plaza Manises museudelaparaula.es (muvaet)

	}
	

	# VALIDATE SOURCE IP	
	protected function validate_source_ip() {
		
		$current_source_ip 	= $_SERVER['REMOTE_ADDR'];


		# temporal sevilla
		return 	$current_source_ip ;

		
		
		if($current_source_ip=='37.15.22.112') $this->debug = true;
		
		# Si no se puede detectar el ip
		if(!$current_source_ip) die("Error, your IP ($current_source_ip) is not accesible. Please contact your Babel provider to solve this (babel ".$_SERVER['SERVER_ADDR'].")");
		
		# Si el ip no es autorizado y no es el propi servidor el que accede, error de acceso
		if( !in_array($current_source_ip, $this->ar_valid_ip) && $current_source_ip != $_SERVER['SERVER_ADDR'] ) {

			die("Error. You need authorization for access here ! ($current_source_ip) \n[babel ".$_SERVER['SERVER_ADDR']."] ");
		}	
		
		return 	$current_source_ip ;
	}
	
	# SET GENERAL VARS FROM REQUEST
	# @ $_REQUEST['text']
	# @ $_REQUEST['direction']
	# @ $_REQUEST['mark']
	protected function set_vars() {
		
		# if not receive var text die
		if (!array_key_exists('text',$_REQUEST)) die("Error: need more vars!");	
		
		$this->text 		= $_REQUEST['text'];
		
		# direction like es-ca
		$direction 			= $_REQUEST['direction'];
		$this->direction 	= $this->map_direction($direction);		
		
		$this->mark			= false;
		if(isset($_REQUEST['mark']))
			$this->mark 	= $_REQUEST['mark'];		#$mark = 1;				
		
		if($this->mark == 1) {
			$this->markUnknown = "";
		} else {
			$this->markUnknown = "-u";
		}
		
		$this->set_encoding();
	}
	
	# SET ENCODING
	protected function set_encoding() {

	
		# detect encoding
		$this->enc = mb_detect_encoding($this->text,'UTF-8,ISO-8859-1,ASCII',true);		#var_dump($this->enc);
		
		#if(($this->enc != 'ASCII')||($this->enc != 'UTF-8')) {
		if( $this->enc != 'ASCII' && $this->enc != 'UTF-8' ) {	
			$this->text = mb_convert_encoding($this->text,'UTF-8',$this->enc);
		}	
	}
	
	
	# TRANSLATE	
	public function translate() {
				
		# Imports global vars (from config/apertium-config.php)
		global $APERTIUM_TRANSLATOR; #echo $APERTIUM_TRANSLATOR;
		#global $LING_DATA_DIR;
		
		$text 		= stripslashes($this->text);
		$tempfile 	= tempnam("tmp","tradtext");				#var_dump($tempfile);
				
		$fd = fopen($tempfile,"w");		# create random file
		fputs($fd, $text);
		fclose($fd);		
		
		# TEST --------------
		#echo "readfile: " ; readfile($tempfile); echo '<hr>';		
		#$this->trad = shell_exec(" echo ' hola mundo camión niño ' | LANG=es_ES.utf8 /usr/local/bin/apertium es-en "); return $this->trad;
		#$this->trad = shell_exec(" echo ' hola mundo camión niño ' | LANG=en_US.UTF-8 /usr/local/bin/apertium es-en "); return $this->trad;
		
		
		##############################################################
		#
		# PROBLEMAS CON LA CODIFICACIÓN ????
		# REVISAR EN EL LINUX: 
		# 
		# CONSOLA: locale para ver el que hay. (Hace falta reiniciar al cambiarlo)
		# $ locale -a
		# $ export LANG=en_US.utf8
		#
		# EDITAR FICHERO
		# /etc/sysconfig/i18n
		# LANG="en_US.utf8" 
		# SUPPORTED="en_US.utf8:en_US:en"
		# 
		#
		##############################################################

		
		$LOCALE = 'LANG=es_ES.utf8';	# default: LANG=es_ES.UTF-8	 o 	LANG=es_ES.utf8
	  
		#$this->cmd = "LANG=es_ES.UTF-8 $APERTIUM_TRANSLATOR -f txt $this->markUnknown $this->direction $tempfile";		#echo " <hr> $cmd <hr>" ;
		$this->cmd = "$LOCALE $APERTIUM_TRANSLATOR -f txt $this->markUnknown $this->direction $tempfile";		#echo " <hr> $cmd <hr>" ;
		#$cmd = "$APERTIUM_TRANSLATOR -f txt $markUnknown $dir $tempfile";
		#$cmd = "LANG=en.UTF-8 $APERTIUM_TRANSLATOR -f txt $markUnknown $dir $tempfile";
		#$cmd = "LANG=ca $APERTIUM_TRANSLATOR -f txt $markUnknown $dir $tempfile";
		
		 
		$this->trad = shell_exec($this->cmd);		
		#$this->cmd = stripslashes($this->cmd);
		
		#$this->trad = exec( $this->cmd, $output);	#var_dump($output);
		#$this->trad = shell_exec(" echo ' hola mundo niño ' | LANG=es_ES.UTF-8 /usr/local/bin/apertium es-en ");
		
		#$trad = replaceUnknown($trad);
		#$trad = str_replace("\n","<br />\n", $trad);
		
		unlink($tempfile);				# delete created file
		
		return $this->trad;
	}
	
	
	# REPLACE UNKNOWN WORDS WITH LINKS
	function replaceUnknown() {
		
		if(!$this->trad) return false;
		
		$result = "";
		for($i = 0; $i < strlen($this->trad); $i++) {
		if($trad[$i]=='*') {
		  $result = $result.'<span style="color:red;"><a href="engine/index.php?direccion='.$direccion.'&word=';
		  $myword ="";
		  for(; $trad[$i] != ' ' && $trad[$i] != '\n' && $i < strlen($trad); $i++)
		  {
			$myword = $myword.$trad[$i];
		  }
		  $result .= substr($myword,1).'">'.$myword."</a></span>".$trad[$i];
		}
		else
		{
		  $result.=$trad[$i];
		}
	  }
	  return $result;
	}
	
	
	# DESTRUCT DEBUG
	function __destruct() {
		
		if($this->debug) {
			
			echo "<hr>";
			echo " text:<b> ".$this->text."</b>";
			echo "<br>";
			echo " trad:<b> ".$this->trad."</b>";
			echo "<br>";
			echo " direction:<b> ".$this->direction."</b>";
			echo "<br>";
			echo " mark:<b> ".$this->mark."</b>";
			echo "<br>";
			echo " markUnknown:<b> ".$this->markUnknown."</b>";
			echo "<br>";
			echo " enc:<b> ".$this->enc."</b>";
			echo "<br>";			
			echo " cmd:<b> ".$this->cmd."</b>";
			echo "<br>";
			echo " ip:<b> ".$_SERVER['REMOTE_ADDR']."</b>";
			echo "<br>";
		}
	}


	
};

?>