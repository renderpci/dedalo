<?php
// Apertium translator
//$APERTIUM_TRANSLATOR = "/home/fran/svnroot/local/unicode/bin/apertium";
$APERTIUM_TRANSLATOR = "/usr/local/bin/apertium";

//$APERTIUM_PATH= "/home/fran/svnroot/local/unicode/bin";
$APERTIUM_PATH= "/usr/local/bin/";

//$INTERNOSTRUM_LING_DATA = "/home/ebenimeli/archive/internostrum";
//$INTERNOSTRUM_LING_DATA = "/home/ebenimeli/datos/internostrum";

//$TURL_PATH = "/home/ebenimeli/myscripts/turl/turl";
$TURL_PATH = "/usr/local/bin/turl";

//$WWW_ROOT_DIR = "svn-apertium-www";
$WWW_ROOT_DIR = "/var/www/vhosts/babel.antropolis.net/httpdocs/babel_engine";

?>
