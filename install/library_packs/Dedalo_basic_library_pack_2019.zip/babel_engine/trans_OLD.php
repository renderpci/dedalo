<?php

/**/
ini_set('error_reporting', E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);


# verify authorized source IP
$ip	= validate_source_ip();				#die("Wellcome! $ip");


include_once("config/apertium-config.php");
#include_once("common/logging.php");
	

# if not receive var text die
if (!array_key_exists('text',$_REQUEST)) die("Error: need more vars!");	
	
	
# vars	
$text 		= $_REQUEST['text'];
$direction 	= $_REQUEST['direction'];
$mark 		= $_REQUEST['mark'];		#$mark = 1;		


if($mark == 1) {
	$markUnknown = "";
} else {
	$markUnknown = "-u";
}

# detect encoding
$enc = mb_detect_encoding($text,'UTF-8,ISO-8859-1,ASCII');

if(($enc != 'ASCII')||($enc != 'UTF-8')) {
		$text = mb_convert_encoding($text,'UTF-8',$enc);
}

$trad = translate($text, $direction, $markUnknown);

# show result
print( $trad ) ; 

exit();			



/*
  **************************
	   TRANSLATE
	**************************
*/
function translate($text, $dir, $markUnknown) {
	
	// Imports global vars (from config/apertium-config.php)
	global $APERTIUM_TRANSLATOR;
	#global $LING_DATA_DIR;
	
	$text 		= stripslashes($text);
	$tempfile 	= tempnam("tmp","tradtext");
	
	#$tempfile 	= "tradtext";
	
	$fd = fopen($tempfile,"w");		# create random file
	fputs($fd, $text);
	fclose($fd);
  
	$cmd = "LANG=es_ES.UTF-8 $APERTIUM_TRANSLATOR -f txt $markUnknown $dir $tempfile";
	#$cmd = "$APERTIUM_TRANSLATOR -f txt $markUnknown $dir $tempfile";
	#$cmd = "LANG=en.UTF-8 $APERTIUM_TRANSLATOR -f txt $markUnknown $dir $tempfile";
	#$cmd = "LANG=ca $APERTIUM_TRANSLATOR -f txt $markUnknown $dir $tempfile";
	 
	$trad = shell_exec($cmd);
	#$trad = replaceUnknown($trad);
	#$trad = str_replace("\n","<br />\n", $trad);
	
	unlink($tempfile);				# delete created file
	
	return $trad;
}


/*
  *************************************
	   REPLACE UNKNOWN WORDS WITH LINKS
  *************************************
*/
function replaceUnknown($trad) {
	$result = "";
	for($i = 0; $i < strlen($trad); $i++) {
	if($trad[$i]=='*') {
      $result = $result.'<span style="color:red;"><a href="engine/index.php?direccion='.$direccion.'&word=';
      $myword ="";
      for(; $trad[$i] != ' ' && $trad[$i] != '\n' && $i < strlen($trad); $i++)
      {
        $myword = $myword.$trad[$i];
      }
      $result .= substr($myword,1).'">'.$myword."</a></span>".$trad[$i];
    }
    else
    {
      $result.=$trad[$i];
    }
  }
  return $result;
}

/*
  *************************************
	   VALIDATE SOURCE IP
  *************************************
*/
function validate_source_ip() {
	
	$current_source_ip 	= $_SERVER['REMOTE_ADDR'];
	
	$ar_ip_valid 		= array();
	$ar_ip_valid[]		= '95.17.26.142';	# jazztel despacho calle denia
	$ar_ip_valid[]		= '95.17.27.188';	# jazztel despacho calle denia
	
	if( !in_array($current_source_ip, $ar_ip_valid)) die("Error. You need authorization for access here ! ($current_source_ip) ");	
	
	return 	$current_source_ip ;
}



?>
