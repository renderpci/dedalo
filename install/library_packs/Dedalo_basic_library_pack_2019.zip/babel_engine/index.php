<?php #die("Sorry: Service temporarily unavailable");
# set errors to display
ini_set('error_reporting', E_ALL ^ E_NOTICE);
ini_set('display_errors', 1);

# include class
include_once('class.Babel_trad.php');

# need request vars $text, $direction, $markUnknown
$Babel_trad	= new Babel_trad();
$trad 		= $Babel_trad->translate();

# show result
if($trad) print( $trad ) ;
	
exit();
?>
