-- phpMyAdmin SQL Dump
-- version 4.3.13
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 25, 2015 at 04:04 PM
-- Server version: 5.6.20
-- PHP Version: 5.6.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `memorial_web`
--

-- --------------------------------------------------------

--
-- Table structure for table `articulos_proyecto`
--

CREATE TABLE IF NOT EXISTS `articulos_proyecto` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Texto de introducción - mdcat167',
  `articulos_proyecto_portal` text COLLATE utf8_unicode_ci COMMENT 'Artículos sobre el proyecto - mdcat168',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat166'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `articulos_proyecto`
--

INSERT INTO `articulos_proyecto` (`id`, `id_matrix`, `lang`, `presentacion`, `articulos_proyecto_portal`, `publicacion`) VALUES
(1, 20, 'lg-cat', '<h2 style="text-align: justify;"><strong><img src="../../../../web/images/branguli/ANC1-722-N-178.jpg" alt="" width="112" height="76" /></strong></h2> <h2 style="text-align: left;"><strong>Articles sobre el projecte</strong></h2> <p>El Banc Audiovisual de Testimonis és un projecte multidisciplinari que agrupa historiadors, periodistes, antropòlegs, documentalistes i programadors.</p> <p>Entorn d’aquest projecte s’han publicat diversos articles, que recopilem en aquest apartat.</p>', '["21","99"]', 'si'),
(2, 20, 'lg-spa', '<h2><strong><img src="../../../../web/images/branguli/ANC1-722-N-178.jpg" alt="" width="112" height="76" /></strong></h2> <h2 style="text-align: left;"><strong>Artículos sobre el proyecto</strong></h2> <p>El Banco Audiovisual de Testimonios es un proyecto multidisciplinar que agrupa a historiadores, periodistas, antropólogos, documentalistas y programadores.</p> <p>Sobre este proyecto se han publicado varios artículos, que recopilamos en este apartado.</p> <p> </p>', '["21","99"]', 'si'),
(3, 20, 'lg-eng', '<h2><strong><img src="../../../../web/images/branguli/ANC1-722-N-178.jpg" alt="" width="112" height="76" /></strong></h2> <h2 style="text-align: left;"><strong>Articles about the project</strong></h2> <p>The Audiovisual Bank of Testimonies is a multidisciplinary project that unites historians, journalists, anthropologists, documentary makers and programmers.</p> <p>Various articles have been published about this project, and these can be found in this section.</p>', '["21","99"]', 'si'),
(4, 20, 'lg-fra', '<h2><strong><img src="../../../../web/images/branguli/ANC1-722-N-178.jpg" alt="" width="112" height="76" /></strong></h2> <h2 style="text-align: left;"><strong>Articles sur le projet</strong></h2> <p>La Banque Audiovisuelle de Témoignages est un projet multidisciplinaire qui regroupe des historiens, des journalistes, des anthropologies, des documentalistes et des programmateurs.</p> <p>Différents articles ont été publiés dans le cadre de ce projet, ils sont recueillis dans ce paragraphe.  </p> <p> </p>', '["21","99"]', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `articulos_proyecto_portal`
--

CREATE TABLE IF NOT EXISTS `articulos_proyecto_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `comentario` text COLLATE utf8_unicode_ci COMMENT 'Comentario - mdcat278',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `weblink` text COLLATE utf8_unicode_ci COMMENT 'Enlace web - mdcat279',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `articulos_proyecto_portal`
--

INSERT INTO `articulos_proyecto_portal` (`id`, `id_matrix`, `lang`, `fecha`, `titulo`, `comentario`, `version`, `doc_pdf`, `weblink`, `publicacion`) VALUES
(1, 21, 'lg-cat', 'Monday12-2014-06-23T00:00:00+02:00am30', 'Banc Audiovisual de Testimonis del Memorial Democràtic', '', '', 'mdcat288-16', '', 'si'),
(2, 21, 'lg-spa', 'Monday12-00pam', 'Banc Audiovisual de Testimonis del Memorial Democràtic', '', '', 'mdcat288-19', '', 'si'),
(3, 21, 'lg-eng', 'Monday12-Europe/Madrid612', 'Banc Audiovisual de Testimonis del Memorial Democràtic', '', '', 'mdcat288-19', '', 'si'),
(4, 21, 'lg-fra', 'Monday12-fMon, 23 Jun 2014 00:00:00 +0200am', 'Banc Audiovisual de Testimonis del Memorial Democràtic', '', '', 'mdcat288-19', '', 'si'),
(5, 99, 'lg-cat', 'Thursday12-2015-10-15T00:00:00+02:00am31', 'Collecte institutionnelle et valorisation en ligne : El Banco audiovisual del Memorial Democràtic (Catalogne, Espagne)', '', '', 'mdcat288-21', 'http://afas.revues.org/2925#tocto2n1', 'si'),
(6, 99, 'lg-spa', 'Thursday12-00pam', 'Collecte institutionnelle et valorisation en ligne : El Banco audiovisual del Memorial Democràtic (Catalogne, Espagne)', '', '', 'mdcat288-21', 'http://afas.revues.org/2925#tocto2n1', 'si'),
(7, 99, 'lg-eng', 'Thursday12-Europe/Madrid1012', 'Collecte institutionnelle et valorisation en ligne : El Banco audiovisual del Memorial Democràtic (Catalogne, Espagne)', '', '', 'mdcat288-21', 'http://afas.revues.org/2925#tocto2n1', 'si'),
(8, 99, 'lg-fra', 'Thursday12-fThu, 15 Oct 2015 00:00:00 +0200am', 'Collecte institutionnelle et valorisation en ligne : El Banco audiovisual del Memorial Democràtic (Catalogne, Espagne)', '', '', 'mdcat288-21', 'http://afas.revues.org/2925#tocto2n1', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `concepcion_proyecto`
--

CREATE TABLE IF NOT EXISTS `concepcion_proyecto` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Texto de introducción - mdcat149',
  `concepcion_proyecto_portal` text COLLATE utf8_unicode_ci COMMENT 'Concepción del proyecto - mdcat150',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat148'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `concepcion_proyecto`
--

INSERT INTO `concepcion_proyecto` (`id`, `id_matrix`, `lang`, `presentacion`, `concepcion_proyecto_portal`, `publicacion`) VALUES
(1, 15, 'lg-cat', '<p><img src="../../../../web/images/branguli/ANC1-722-N-196.jpg" alt="" width="112" height="76" /></p> <h2 style="text-align: left;"><strong>Documentació tècnica</strong></h2> <p>El Banc Audiovisual de Testimonis del Memorial Democràtic és un arxiu de fonts orals, que des de l’any 2009 promou la recerca sobre història contemporània a través de la memòria oral.</p> <p>Amb la voluntat d’apropar la recerca a públics amplis, publiquem en aquest apartat tota la documentació tècnica relacionada amb el projecte, des de la seva concepció fins al programari utilitzat, passant per articles relacionats amb el projecte o els protocols de recerca utilitzats pels investigadors.</p>', '["16"]', 'si'),
(2, 15, 'lg-spa', '<p><img src="../../../../web/images/branguli/ANC1-722-N-196.jpg" alt="" width="112" height="76" /></p> <h2 style="text-align: left;"> <strong>Documentación técnica</strong></h2> <p>El Banco Audiovisual de Testimonios del Memorial Democràtic es un archivo de fuentes orales, que desde el año 2009 promueve la investigación sobre historia contemporánea a través de la memoria oral.</p> <p>Con la voluntad de acercar la investigación a públicos amplios, publicamos en este apartado toda la documentación técnica relacionada con el proyecto, desde su concepción hasta el software utilizado, pasando por artículos relacionados con el proyecto o los protocolos de investigación utilizados por los investigadores.</p> <p> </p>', '["16"]', 'si'),
(3, 15, 'lg-eng', '<p><strong><img src="../../../../web/images/branguli/ANC1-722-N-196.jpg" alt="" width="112" height="76" /></strong></p> <h2 style="text-align: left;"><strong>Technical documentation</strong></h2> <p>The Audiovisual Bank of Testimonies of the Democratic Memory is an archive of oral testimonies. Since 2009 research has been promoted on contemporary history through oral memory.</p> <p>With the aim of making the research available to a wider public, in this section all of the technical documentation related to the project is published, from its design to the software used, including articles related to the project and the research protocols used by the researchers.</p>', '["16"]', 'si'),
(4, 15, 'lg-fra', '<p><img src="../../../../web/images/branguli/ANC1-722-N-196.jpg" alt="" width="112" height="76" /></p> <h2 style="text-align: left;"><strong>Documentation technique</strong></h2> <p>La Banque audiovisuelle de témoignages du Mémorial Démocratique est un fichier de sources orales, qui depuis 2009 encourage la recherche sur l''histoire contemporaine à travers la mémoire orale.</p> <p>Soucieux de rapprocher la recherche d''un public élargi, nous publions dans ce paragraphe toute la documentation technique associée au projet, depuis sa conception jusqu''au programme utilisé, en passant par les articles associés à ce projet, ou les protocoles de recherche utilisés par les chercheurs. </p> <p> </p> <p> </p>', '["16"]', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `concepcion_proyecto_portal`
--

CREATE TABLE IF NOT EXISTS `concepcion_proyecto_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `weblink` text COLLATE utf8_unicode_ci COMMENT 'Enlace web - mdcat279',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `concepcion_proyecto_portal`
--

INSERT INTO `concepcion_proyecto_portal` (`id`, `id_matrix`, `lang`, `titulo`, `fecha`, `version`, `doc_pdf`, `weblink`, `publicacion`) VALUES
(1, 16, 'lg-cat', 'Concepció del projecte', 'Monday12-2014-06-23T00:00:00+02:00am30', '', 'mdcat288-13', '', 'si'),
(2, 16, 'lg-spa', 'Concepció del projecte', 'Monday12-00pam', '', 'mdcat288-19', '', 'si'),
(3, 16, 'lg-eng', 'Concepció del projecte', 'Monday12-Europe/Madrid612', '', 'mdcat288-19', '', 'si'),
(4, 16, 'lg-fra', 'Concepció del projecte', 'Monday12-fMon, 23 Jun 2014 00:00:00 +0200am', '', 'mdcat288-19', '', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `creditos`
--

CREATE TABLE IF NOT EXISTS `creditos` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Presentación - mdcat26',
  `creditos_personas` text COLLATE utf8_unicode_ci COMMENT 'Personas que han participado - mdcat27',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat24'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `creditos`
--

INSERT INTO `creditos` (`id`, `id_matrix`, `lang`, `presentacion`, `creditos_personas`, `publicacion`) VALUES
(1, 2, 'lg-cat', '<p><strong>Concepció del projecte:</strong> Montserrat Armengou i Ricard Belis</p> <p><strong>Responsable del projecte:</strong> Gerard Corbella</p> <p><strong>Thesaurus:</strong> Gerard Corbella, Maribel Cuadrado, Joan Palahí, Anna Pascual</p> <p><strong>Programari:</strong> Render Comunicación SL</p>', '[]', 'si'),
(2, 2, 'lg-spa', '<p><strong>Concepción del proyecto:</strong> Montserrat Armengou y Ricard Belis</p> <p><strong>Responsable del proyecto:</strong> Gerard Corbella</p> <p><strong>Thesaurus:</strong> Gerard Corbella, Maribel Cuadrado, Joan Palahí, Anna Pascual</p> <p><strong>Software:</strong> Render Comunicación SL</p>', '[]', 'si'),
(3, 2, 'lg-eng', '<p><strong>Conception of the project:</strong> Montserrat Armengou and Ricard Belis</p> <p><strong>Project manager:</strong> Gerard Corbella</p> <p><strong>Thesaurus:</strong> Gerard Corbella, Maribel Cuadrado, Joan Palahí, Anna Pascual</p> <p><strong>Software:</strong> Render Comunicación SL</p>', '[]', 'si'),
(4, 2, 'lg-fra', '<p><strong>Conception du projet:</strong> Montserrat Armengou et Ricard Belis</p> <p><strong>Responsable du projet:</strong> Gerard Corbella</p> <p><strong>Thesaurus:</strong> Gerard Corbella, Maribel Cuadrado, Joan Palahí, Anna Pascual</p> <p><strong>Logiciel:</strong> Render Comunicación SL</p>', '[]', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `creditos_personas`
--

CREATE TABLE IF NOT EXISTS `creditos_personas` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `apellidos` text COLLATE utf8_unicode_ci COMMENT 'Apellidos - rsc86',
  `nombre` text COLLATE utf8_unicode_ci COMMENT 'Nombre - rsc85',
  `tipologia` text COLLATE utf8_unicode_ci COMMENT 'Tipología - rsc90',
  `creditos_personas_imagen` text COLLATE utf8_unicode_ci COMMENT 'Imagen - rsc88',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Uso de imagen - rsc97'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `creditos_personas_imagen`
--

CREATE TABLE IF NOT EXISTS `creditos_personas_imagen` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `url` text COLLATE utf8_unicode_ci COMMENT 'Imagen - rsc29',
  `pie` text COLLATE utf8_unicode_ci COMMENT 'Pie de foto - rsc31'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `documentales`
--

CREATE TABLE IF NOT EXISTS `documentales` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `documentales_portal` text COLLATE utf8_unicode_ci COMMENT 'Documentales - mdcat215',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat213',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Presentacion - mdcat214'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `documentales_portal`
--

CREATE TABLE IF NOT EXISTS `documentales_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `descripcion` text COLLATE utf8_unicode_ci COMMENT 'Descripción / transcripción audiovisual - rsc36',
  `video` text COLLATE utf8_unicode_ci COMMENT 'Vídeo - rsc35',
  `autor` text COLLATE utf8_unicode_ci COMMENT 'Autor - rsc70',
  `observaciones` text COLLATE utf8_unicode_ci COMMENT 'Observaciones - rsc27',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - rsc23',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Difusión - rsc20'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `enlaces_archivos_testimonios`
--

CREATE TABLE IF NOT EXISTS `enlaces_archivos_testimonios` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Texto de introducción - mdcat241',
  `enlaces_archivos_testimonios_portal` text COLLATE utf8_unicode_ci COMMENT 'Enlaces - mdcat242',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat240'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `enlaces_archivos_testimonios`
--

INSERT INTO `enlaces_archivos_testimonios` (`id`, `id_matrix`, `lang`, `presentacion`, `enlaces_archivos_testimonios_portal`, `publicacion`) VALUES
(1, 46, 'lg-cat', '', '["81","82","83","85","86","87","89","90","91","92","93","94"]', 'si'),
(2, 46, 'lg-spa', '<p><img src="../../../../web/images/branguli/ANC1-555-N-1812.jpg" alt="" width="82" height="61" /></p> <p> </p> <p> </p> <p> </p> <p> </p> <p> </p> <p> </p>', '["81","82","83","85","86","87","89","90","91","92","93","94"]', 'si'),
(3, 46, 'lg-eng', '<p><img src="../../../../web/images/branguli/ANC1-555-N-1812.jpg" alt="" width="82" height="61" /></p> <p> </p> <p> </p> <p> </p> <p> </p> <p> </p> <p> </p>', '["81","82","83","85","86","87","89","90","91","92","93","94"]', 'si'),
(4, 46, 'lg-fra', '<p><img src="../../../../web/images/branguli/ANC1-555-N-1812.jpg" alt="" width="82" height="61" /></p> <p> </p> <p> </p> <p> </p> <p> </p> <p> </p> <p> </p>', '["81","82","83","85","86","87","89","90","91","92","93","94"]', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `enlaces_archivos_testimonios_portal`
--

CREATE TABLE IF NOT EXISTS `enlaces_archivos_testimonios_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `weblink` text COLLATE utf8_unicode_ci COMMENT 'Enlace web - mdcat279',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `comentario` text COLLATE utf8_unicode_ci COMMENT 'Comentario - mdcat278',
  `agrupacion` text COLLATE utf8_unicode_ci COMMENT 'Sub-categoría - mdcat351',
  `agrupacion_label` text COLLATE utf8_unicode_ci COMMENT 'Sub-categoría - mdcat351',
  `categoria` text COLLATE utf8_unicode_ci COMMENT 'Categoría - mdcat590',
  `categoria_label` text COLLATE utf8_unicode_ci COMMENT 'Categoría - mdcat590'
) ENGINE=MyISAM AUTO_INCREMENT=49 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `enlaces_archivos_testimonios_portal`
--

INSERT INTO `enlaces_archivos_testimonios_portal` (`id`, `id_matrix`, `lang`, `weblink`, `publicacion`, `titulo`, `comentario`, `agrupacion`, `agrupacion_label`, `categoria`, `categoria_label`) VALUES
(1, 81, 'lg-cat', 'http://www.iohanet.org/home/', 'si', 'International Oral History Association', '', '', '', '84', 'Internacional'),
(2, 81, 'lg-spa', 'http://www.iohanet.org/home/', 'si', 'International Oral History Association', '', '', '', '84', 'Internacional'),
(3, 81, 'lg-eng', 'http://www.iohanet.org/home/', 'si', 'International Oral History Association', '', '', '', '84', 'International'),
(4, 81, 'lg-fra', 'http://www.iohanet.org/home/', 'si', 'International Oral History Association', '', '', '', '84', 'International'),
(5, 82, 'lg-cat', 'http://www.historiaoralargentina.org/ ', 'si', 'Asociación de Historia Oral de la República Argentina (AHORA)', '', '6', 'Argentina', '78', 'Amèrica'),
(6, 82, 'lg-spa', 'http://www.historiaoralargentina.org/ ', 'si', 'Asociación de Historia Oral de la República Argentina (AHORA)', '', '6', 'Argentina', '78', 'América'),
(7, 82, 'lg-eng', 'http://www.historiaoralargentina.org/ ', 'si', 'Asociación de Historia Oral de la República Argentina (AHORA)', '', '6', 'Argentina', '78', 'America'),
(8, 82, 'lg-fra', 'http://www.historiaoralargentina.org/ ', 'si', 'Asociación de Historia Oral de la República Argentina (AHORA)', '', '6', 'Argentine', '78', 'Amérique'),
(9, 83, 'lg-cat', 'http://www.coh.usd.cas.cz/en/', 'si', 'Centrum Orální Historie', '', '12', 'República Txeca', '79', 'Europa'),
(10, 83, 'lg-spa', 'http://www.coh.usd.cas.cz/en/', 'si', 'Centrum Orální Historie', '', '12', 'República Checa', '79', 'Europa'),
(11, 83, 'lg-eng', 'http://www.coh.usd.cas.cz/en/', 'si', 'Centrum Orální Historie', '', '12', 'Czech Republic', '79', 'Europe'),
(12, 83, 'lg-fra', 'http://www.coh.usd.cas.cz/en/', 'si', 'Centrum Orální Historie', '', '12', 'République Txeca', '79', 'Europe'),
(13, 85, 'lg-cat', 'http://www.oralhistory.org/', 'si', 'Oral History Association ', '', '17', 'Estats Units d''Amèrica', '78', 'Amèrica'),
(14, 85, 'lg-spa', 'http://www.oralhistory.org/', 'si', 'Oral History Association ', '', '17', 'Estados Unidos de América', '78', 'América'),
(15, 85, 'lg-eng', 'http://www.oralhistory.org/', 'si', 'Oral History Association ', '', '17', 'United States of America', '78', 'America'),
(16, 85, 'lg-fra', 'http://www.oralhistory.org/', 'si', 'Oral History Association ', '', '17', 'États-Unis d''Amérique', '78', 'Amérique'),
(17, 86, 'lg-cat', 'http://www.oralhistory.org.uk/', 'si', 'Oral History Society ', '', '23', 'Regne Unit', '79', 'Europa'),
(18, 86, 'lg-spa', 'http://www.oralhistory.org.uk/', 'si', 'Oral History Society ', '', '23', 'Reino Unido', '79', 'Europa'),
(19, 86, 'lg-eng', 'http://www.oralhistory.org.uk/', 'si', 'Oral History Society ', '', '23', '', '79', 'Europe'),
(20, 86, 'lg-fra', 'http://www.oralhistory.org.uk/', 'si', 'Oral History Society ', '', '23', '', '79', 'Europe'),
(21, 87, 'lg-cat', 'http://www.cpm.uct.ac.za/', 'si', 'Centre for Popular Memory ', '', '24', 'Sud-Àfrica', '88', 'Àfrica'),
(22, 87, 'lg-spa', 'http://www.cpm.uct.ac.za/', 'si', 'Centre for Popular Memory ', '', '24', 'Suráfrica', '88', 'África'),
(23, 87, 'lg-eng', 'http://www.cpm.uct.ac.za/', 'si', 'Centre for Popular Memory ', '', '24', 'South Africa', '88', 'Africa'),
(24, 87, 'lg-fra', 'http://www.cpm.uct.ac.za/', 'si', 'Centre for Popular Memory ', '', '24', 'Afrique du Sud', '88', 'Afrique'),
(25, 89, 'lg-cat', 'http://www.ohasa.org.za/', 'si', 'Oral History Association of South Africa', '', '24', 'Sud-Àfrica', '88', 'Àfrica'),
(26, 89, 'lg-spa', 'http://www.ohasa.org.za/', 'si', 'Oral History Association of South Africa', '', '24', 'Suráfrica', '88', 'África'),
(27, 89, 'lg-eng', 'http://www.ohasa.org.za/', 'si', 'Oral History Association of South Africa', '', '24', 'South Africa', '88', 'Africa'),
(28, 89, 'lg-fra', 'http://www.ohasa.org.za/', 'si', 'Oral History Association of South Africa', '', '24', 'Afrique du Sud', '88', 'Afrique'),
(29, 90, 'lg-cat', 'http://dougboyd.org/', 'si', 'Doug Boyd', '', '17', 'Estats Units d''Amèrica', '78', 'Amèrica'),
(30, 90, 'lg-spa', 'http://dougboyd.org/', 'si', 'Doug Boyd', '', '17', 'Estados Unidos de América', '78', 'América'),
(31, 90, 'lg-eng', 'http://dougboyd.org/', 'si', 'Doug Boyd', '', '17', 'United States of America', '78', 'America'),
(32, 90, 'lg-fra', 'http://dougboyd.org/', 'si', 'Doug Boyd', '', '17', 'États-Unis d''Amérique', '78', 'Amérique'),
(33, 91, 'lg-cat', 'http://www.historicalstudies.uct.ac.za/hst/people/academic-staff/sean-field ', 'si', 'Sean Field', '', '24', 'Sud-Àfrica', '88', 'Àfrica'),
(34, 91, 'lg-spa', 'http://www.historicalstudies.uct.ac.za/hst/people/academic-staff/sean-field ', 'si', 'Sean Field', '', '24', 'Suráfrica', '88', 'África'),
(35, 91, 'lg-eng', 'http://www.historicalstudies.uct.ac.za/hst/people/academic-staff/sean-field ', 'si', 'Sean Field', '', '24', 'South Africa', '88', 'Africa'),
(36, 91, 'lg-fra', 'http://www.historicalstudies.uct.ac.za/hst/people/academic-staff/sean-field ', 'si', 'Sean Field', '', '24', 'Afrique du Sud', '88', 'Afrique'),
(37, 92, 'lg-cat', 'http://alessandroportelli.blogspot.com ', 'si', 'Alessandro Portelli', '', '19', 'Itàlia', '79', 'Europa'),
(38, 92, 'lg-spa', 'http://alessandroportelli.blogspot.com ', 'si', 'Alessandro Portelli', '', '19', 'Italia', '79', 'Europa'),
(39, 92, 'lg-eng', 'http://alessandroportelli.blogspot.com ', 'si', 'Alessandro Portelli', '', '19', 'Italy', '79', 'Europe'),
(40, 92, 'lg-fra', 'http://alessandroportelli.blogspot.com ', 'si', 'Alessandro Portelli', '', '19', 'Italie', '79', 'Europe'),
(41, 93, 'lg-cat', 'http://profiles.arts.monash.edu.au/alistair-thomson/', 'si', 'Alistair Thomsom', '', '25', 'Austràlia', '80', 'Àsia'),
(42, 93, 'lg-spa', 'http://profiles.arts.monash.edu.au/alistair-thomson/', 'si', 'Alistair Thomsom', '', '25', 'Australia', '80', 'Asia'),
(43, 93, 'lg-eng', 'http://profiles.arts.monash.edu.au/alistair-thomson/', 'si', 'Alistair Thomsom', '', '25', 'Australia', '80', 'Asia'),
(44, 93, 'lg-fra', 'http://profiles.arts.monash.edu.au/alistair-thomson/', 'si', 'Alistair Thomsom', '', '25', 'Australie', '80', 'Asie'),
(45, 94, 'lg-cat', 'http://www.randforce.com/', 'si', 'The Randford Associates', '', '17', 'Estats Units d''Amèrica', '78', 'Amèrica'),
(46, 94, 'lg-spa', 'http://www.randforce.com/', 'si', 'The Randford Associates', '', '17', 'Estados Unidos de América', '78', 'América'),
(47, 94, 'lg-eng', 'http://www.randforce.com/', 'si', 'The Randford Associates', '', '17', 'United States of America', '78', 'America'),
(48, 94, 'lg-fra', 'http://www.randforce.com/', 'si', 'The Randford Associates', '', '17', 'États-Unis d''Amérique', '78', 'Amérique');

-- --------------------------------------------------------

--
-- Table structure for table `enlaces_fuentes_orales`
--

CREATE TABLE IF NOT EXISTS `enlaces_fuentes_orales` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `enlaces_fuentes_orales_portal` text COLLATE utf8_unicode_ci COMMENT 'Enlaces - mdcat233',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Texto de introducción - mdcat232',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat231'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `enlaces_fuentes_orales`
--

INSERT INTO `enlaces_fuentes_orales` (`id`, `id_matrix`, `lang`, `enlaces_fuentes_orales_portal`, `presentacion`, `publicacion`) VALUES
(1, 27, 'lg-cat', '["28","30","29","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","49","50","51","52","53","77","76","75","74","73","72","71","70","69","68","67","66","65","64","63","62","61","60","59","58","57","56","55","54","48","47","95","96","97","98"]', '', 'si'),
(2, 27, 'lg-spa', '["28","30","29","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","49","50","51","52","53","77","76","75","74","73","72","71","70","69","68","67","66","65","64","63","62","61","60","59","58","57","56","55","54","48","47","95","96","97","98"]', '', 'si'),
(3, 27, 'lg-eng', '["28","30","29","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","49","50","51","52","53","77","76","75","74","73","72","71","70","69","68","67","66","65","64","63","62","61","60","59","58","57","56","55","54","48","47","95","96","97","98"]', '', 'si'),
(4, 27, 'lg-fra', '["28","30","29","31","32","33","34","35","36","37","38","39","40","41","42","43","44","45","49","50","51","52","53","77","76","75","74","73","72","71","70","69","68","67","66","65","64","63","62","61","60","59","58","57","56","55","54","48","47","95","96","97","98"]', '', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `enlaces_fuentes_orales_portal`
--

CREATE TABLE IF NOT EXISTS `enlaces_fuentes_orales_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `weblink` text COLLATE utf8_unicode_ci COMMENT 'Enlace web - mdcat279',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `comentario` text COLLATE utf8_unicode_ci COMMENT 'Comentario - mdcat278',
  `agrupacion_label` text COLLATE utf8_unicode_ci COMMENT 'Sub-categoría - mdcat351',
  `agrupacion` text COLLATE utf8_unicode_ci COMMENT 'Sub-categoría - mdcat351',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274',
  `categoria` text COLLATE utf8_unicode_ci COMMENT 'Categoría - mdcat590',
  `categoria_label` text COLLATE utf8_unicode_ci COMMENT 'Categoría - mdcat590'
) ENGINE=MyISAM AUTO_INCREMENT=213 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `enlaces_fuentes_orales_portal`
--

INSERT INTO `enlaces_fuentes_orales_portal` (`id`, `id_matrix`, `lang`, `weblink`, `titulo`, `comentario`, `agrupacion_label`, `agrupacion`, `publicacion`, `categoria`, `categoria_label`) VALUES
(1, 28, 'lg-cat', 'http://portal.ugt.org/fflc/hemeroteca/hemeroteca00.htm', 'Archivo oral del sindicalismo socialista', '', 'Espanya', '1', 'si', '79', 'Europa'),
(2, 28, 'lg-spa', 'http://portal.ugt.org/fflc/hemeroteca/hemeroteca00.htm', 'Archivo oral del sindicalismo socialista', '', 'España', '1', 'si', '79', 'Europa'),
(3, 28, 'lg-eng', 'http://portal.ugt.org/fflc/hemeroteca/hemeroteca00.htm', 'Archivo oral del sindicalismo socialista', '', 'Spain', '1', 'si', '79', 'Europe'),
(4, 28, 'lg-fra', 'http://portal.ugt.org/fflc/hemeroteca/hemeroteca00.htm', '', '', 'Espagne', '1', 'si', '79', 'Europe'),
(5, 30, 'lg-cat', 'http://w110.bcn.cat/portal/site/ArxiuHistoric/menuitem.ab2d885af1118530cef7cef7a2ef8a0c/?vgnextoid=6a19692b13e7c210VgnVCM10000074fea8c0RCRD&vgnextchannel=6a19692b13e7c210VgnVCM10000074fea8c0RCRD&lang=ca_ES ', 'Fons Orals - Arxiu Històric de la Ciutat de Barcelona', '', 'Catalunya', '3', 'si', '79', 'Europa'),
(6, 30, 'lg-spa', 'http://w110.bcn.cat/portal/site/ArxiuHistoric/menuitem.ab2d885af1118530cef7cef7a2ef8a0c/?vgnextoid=6a19692b13e7c210VgnVCM10000074fea8c0RCRD&vgnextchannel=6a19692b13e7c210VgnVCM10000074fea8c0RCRD&lang=ca_ES ', 'Fons Orals - Arxiu Històric de la Ciutat de Barcelona', '', 'Cataluña', '3', 'si', '79', 'Europa'),
(7, 30, 'lg-eng', 'http://w110.bcn.cat/portal/site/ArxiuHistoric/menuitem.ab2d885af1118530cef7cef7a2ef8a0c/?vgnextoid=6a19692b13e7c210VgnVCM10000074fea8c0RCRD&vgnextchannel=6a19692b13e7c210VgnVCM10000074fea8c0RCRD&lang=ca_ES ', 'Fons Orals - Arxiu Històric de la Ciutat de Barcelona', '', 'Catalonia', '3', 'si', '79', 'Europe'),
(8, 30, 'lg-fra', 'http://w110.bcn.cat/portal/site/ArxiuHistoric/menuitem.ab2d885af1118530cef7cef7a2ef8a0c/?vgnextoid=6a19692b13e7c210VgnVCM10000074fea8c0RCRD&vgnextchannel=6a19692b13e7c210VgnVCM10000074fea8c0RCRD&lang=ca_ES ', 'Fons Orals - Arxiu Històric de la Ciutat de Barcelona', '', 'Catalogne', '3', 'si', '79', 'Europe'),
(9, 29, 'lg-cat', 'http://www.rev.hu/portal/page/portal/rev/oha/az_archivumrol', 'Oral History Archive-The Institute for the History of the 1956 Hungarian Revolution', '', 'Hongria', '7', 'si', '79', 'Europa'),
(10, 29, 'lg-spa', 'http://www.rev.hu/portal/page/portal/rev/oha/az_archivumrol', 'Oral History Archive-The Institute for the History of the 1956 Hungarian Revolution', '', 'Hungría', '7', 'si', '79', 'Europa'),
(11, 29, 'lg-eng', 'http://www.rev.hu/portal/page/portal/rev/oha/az_archivumrol', 'Oral History Archive-The Institute for the History of the 1956 Hungarian Revolution', '', 'Hungary', '7', 'si', '79', 'Europe'),
(12, 29, 'lg-fra', 'http://www.rev.hu/portal/page/portal/rev/oha/az_archivumrol', 'Oral History Archive-The Institute for the History of the 1956 Hungarian Revolution', '', 'Hongrie', '7', 'si', '79', 'Europe'),
(13, 31, 'lg-cat', 'http://www.fciprianogarcia.ccoo.cat/ciprianogarcia/arxiuhistoric/aspnet/pagina.aspx?id=9 ', 'Fundació Cipriano García- CCOO', '', 'Catalunya', '3', 'si', '79', 'Europa'),
(14, 31, 'lg-spa', 'http://www.fciprianogarcia.ccoo.cat/ciprianogarcia/arxiuhistoric/aspnet/pagina.aspx?id=9 ', 'Fundació Cipriano García- CCOO', '', 'Cataluña', '3', 'si', '79', 'Europa'),
(15, 31, 'lg-eng', 'http://www.fciprianogarcia.ccoo.cat/ciprianogarcia/arxiuhistoric/aspnet/pagina.aspx?id=9 ', 'Fundació Cipriano García- CCOO', '', 'Catalonia', '3', 'si', '79', 'Europe'),
(16, 31, 'lg-fra', 'http://www.fciprianogarcia.ccoo.cat/ciprianogarcia/arxiuhistoric/aspnet/pagina.aspx?id=9 ', 'Fundació Cipriano García- CCOO', '', 'Catalogne', '3', 'si', '79', 'Europe'),
(17, 32, 'lg-cat', 'http://www.fundacioutopia.com/ ', 'Fundació Utopia', '', 'Catalunya', '3', 'si', '79', 'Europa'),
(18, 32, 'lg-spa', 'http://www.fundacioutopia.com/ ', 'Fundació Utopia', '', 'Cataluña', '3', 'si', '79', 'Europa'),
(19, 32, 'lg-eng', 'http://www.fundacioutopia.com/ ', 'Fundació Utopia', '', 'Catalonia', '3', 'si', '79', 'Europe'),
(20, 32, 'lg-fra', 'http://www.fundacioutopia.com/ ', 'Fundació Utopia', '', 'Catalogne', '3', 'si', '79', 'Europe'),
(21, 33, 'lg-cat', 'http://www.zwangsarbeit-archiv.de/en/', 'Forced Labor 1939-1945', '', 'Alemanya', '8', 'si', '79', 'Europa'),
(22, 33, 'lg-spa', 'http://www.zwangsarbeit-archiv.de/en/', 'Forced Labor 1939-1945', '', 'Alemania', '8', 'si', '79', 'Europa'),
(23, 33, 'lg-eng', 'http://www.zwangsarbeit-archiv.de/en/', 'Forced Labor 1939-1945', '', 'Germany', '8', 'si', '79', 'Europe'),
(24, 33, 'lg-fra', 'http://www.zwangsarbeit-archiv.de/en/', 'Forced Labor 1939-1945', '', 'Allemagne', '8', 'si', '79', 'Europe'),
(25, 34, 'lg-cat', 'http://matricememory.fr/matrice/fr/', 'Matrice Memory', '', 'França', '15', 'si', '79', 'Europa'),
(26, 34, 'lg-spa', 'http://matricememory.fr/matrice/fr/', 'Matrice Memory', '', 'Francia', '15', 'si', '79', 'Europa'),
(27, 34, 'lg-eng', 'http://matricememory.fr/matrice/fr/', 'Matrice Memory', '', 'France', '15', 'si', '79', 'Europe'),
(28, 34, 'lg-fra', 'http://matricememory.fr/matrice/fr/', 'Matrice Memory', '', 'France', '15', 'si', '79', 'Europe'),
(29, 35, 'lg-cat', 'http://postyugoslavvoices.org/', 'Post Yugoslav Voices', '', 'Holanda', '18', 'si', '79', 'Europa'),
(30, 35, 'lg-spa', 'http://postyugoslavvoices.org/', 'Post Yugoslav Voices', '', 'Holanda', '18', 'si', '79', 'Europa'),
(31, 35, 'lg-eng', 'http://postyugoslavvoices.org/', 'Post Yugoslav Voices', '', 'Holland', '18', 'si', '79', 'Europe'),
(32, 35, 'lg-fra', 'http://postyugoslavvoices.org/', 'Post Yugoslav Voices', '', 'Hollande', '18', 'si', '79', 'Europe'),
(33, 36, 'lg-cat', 'http://www.ancr.to.it/new/', 'Archivio Nazzionale Cinematografico della Resistenza', '', 'Itàlia', '19', 'si', '79', 'Europa'),
(34, 36, 'lg-spa', 'http://www.ancr.to.it/new/', 'Archivio Nazzionale Cinematografico della Resistenza', '', 'Italia', '19', 'si', '79', 'Europa'),
(35, 36, 'lg-eng', 'http://www.ancr.to.it/new/', 'Archivio Nazzionale Cinematografico della Resistenza', '', 'Italy', '19', 'si', '79', 'Europe'),
(36, 36, 'lg-fra', 'http://www.ancr.to.it/new/', 'Archivio Nazzionale Cinematografico della Resistenza', '', 'Italie', '19', 'si', '79', 'Europe'),
(37, 37, 'lg-cat', 'http://www.resistance-archive.org/', 'European Resistance Archive', '', 'Alemanya', '8', 'si', '79', 'Europa'),
(38, 37, 'lg-spa', 'http://www.resistance-archive.org/', 'European Resistance Archive', '', 'Alemania', '8', 'si', '79', 'Europa'),
(39, 37, 'lg-eng', 'http://www.resistance-archive.org/', 'European Resistance Archive', '', 'Germany', '8', 'si', '79', 'Europe'),
(40, 37, 'lg-fra', 'http://www.resistance-archive.org/', 'European Resistance Archive', '', 'Allemagne', '8', 'si', '79', 'Europe'),
(41, 38, 'lg-cat', 'http://www.memoryofnations.eu/', 'Memory of nations', '', 'República Txeca', '12', 'si', '79', 'Europa'),
(42, 38, 'lg-spa', 'http://www.memoryofnations.eu/', 'Memory of nations', '', 'República Checa', '12', 'si', '79', 'Europa'),
(43, 38, 'lg-eng', 'http://www.memoryofnations.eu/', 'Memory of nations', '', 'Czech Republic', '12', 'si', '79', 'Europe'),
(44, 38, 'lg-fra', 'http://www.memoryofnations.eu/', 'Memory of nations', '', 'République Txeca', '12', 'si', '79', 'Europe'),
(45, 39, 'lg-cat', 'http://www.ironcurtainstories.eu/', 'Iron Curtain Stories', '', 'República Txeca', '12', 'si', '79', 'Europa'),
(46, 39, 'lg-spa', 'http://www.ironcurtainstories.eu/', 'Iron Curtain Stories', '', 'República Checa', '12', 'si', '79', 'Europa'),
(47, 39, 'lg-eng', 'http://www.ironcurtainstories.eu/', 'Iron Curtain Stories', '', 'Czech Republic', '12', 'si', '79', 'Europe'),
(48, 39, 'lg-fra', 'http://www.ironcurtainstories.eu/', 'Iron Curtain Stories', '', 'République Txeca', '12', 'si', '79', 'Europe'),
(49, 40, 'lg-cat', 'http://ipd-ssi.hr/?page_id=211', 'Istrian destiny (Istrians in concentration camp and prisons during World War II and postwar)', '', 'Croàcia', '20', 'si', '79', 'Europa'),
(50, 40, 'lg-spa', 'http://ipd-ssi.hr/?page_id=211', 'Istrian destiny (Istrians in concentration camp and prisons during World War II and postwar)', '', 'Croacia', '20', 'si', '79', 'Europa'),
(51, 40, 'lg-eng', 'http://ipd-ssi.hr/?page_id=211', 'Istrian destiny (Istrians in concentration camp and prisons during World War II and postwar)', '', 'Croatia', '20', 'si', '79', 'Europe'),
(52, 40, 'lg-fra', 'http://ipd-ssi.hr/?page_id=211', 'Istrian destiny (Istrians in concentration camp and prisons during World War II and postwar)', '', 'Croatie', '20', 'si', '79', 'Europe'),
(53, 41, 'lg-cat', 'http://territoryterror.org.ua/en/witnesses/ ', 'Witnesses Collection of  Memorial Museum of Totalitarian Regimes “Territory of Terror” ', '', 'Ucraïna', '21', 'si', '79', 'Europa'),
(54, 41, 'lg-spa', 'http://territoryterror.org.ua/en/witnesses/ ', 'Witnesses Collection of  Memorial Museum of Totalitarian Regimes “Territory of Terror” ', '', 'Ucrania', '21', 'si', '79', 'Europa'),
(55, 41, 'lg-eng', 'http://territoryterror.org.ua/en/witnesses/ ', 'Witnesses Collection of  Memorial Museum of Totalitarian Regimes “Territory of Terror” ', '', 'Ukraine', '21', 'si', '79', 'Europe'),
(56, 41, 'lg-fra', 'http://territoryterror.org.ua/en/witnesses/ ', 'Witnesses Collection of  Memorial Museum of Totalitarian Regimes “Territory of Terror” ', '', 'Ukraine', '21', 'si', '79', 'Europe'),
(57, 42, 'lg-cat', 'http://www.fenomenulpitesti.ro/video ', 'Fenomenul Pitesti', '', 'Romania', '11', 'si', '79', 'Europa'),
(58, 42, 'lg-spa', 'http://www.fenomenulpitesti.ro/video ', 'Fenomenul Pitesti', '', 'Rumanía', '11', 'si', '79', 'Europa'),
(59, 42, 'lg-eng', 'http://www.fenomenulpitesti.ro/video ', 'Fenomenul Pitesti', '', 'Romania', '11', 'si', '79', 'Europe'),
(60, 42, 'lg-fra', 'http://www.fenomenulpitesti.ro/video ', 'Fenomenul Pitesti', '', 'Rumanie', '11', 'si', '79', 'Europe'),
(61, 43, 'lg-cat', 'http://www.upn.gov.sk/english/project-oral-history-witnesses-of-the-oppression-period ', 'Witnesses of the opression period – Nation’s Memory Institute of Slovakia', '', 'Eslovàquia', '22', 'si', '79', 'Europa'),
(62, 43, 'lg-spa', 'http://www.upn.gov.sk/english/project-oral-history-witnesses-of-the-oppression-period ', 'Witnesses of the opression period – Nation’s Memory Institute of Slovakia', '', 'Eslovaquia', '22', 'si', '79', 'Europa'),
(63, 43, 'lg-eng', 'http://www.upn.gov.sk/english/project-oral-history-witnesses-of-the-oppression-period ', 'Witnesses of the opression period – Nation’s Memory Institute of Slovakia', '', 'Slovakia', '22', 'si', '79', 'Europe'),
(64, 43, 'lg-fra', 'http://www.upn.gov.sk/english/project-oral-history-witnesses-of-the-oppression-period ', 'Witnesses of the opression period – Nation’s Memory Institute of Slovakia', '', 'Slovaquie', '22', 'si', '79', 'Europe'),
(65, 44, 'lg-cat', 'http://entretiens.ina.fr/video/Shoah', 'Memoires de la Shoah- Institut National de l’Audiovisuel, Fondation pour la Memóire de la Shoah', '', 'França', '15', 'si', '79', 'Europa'),
(66, 44, 'lg-spa', 'http://entretiens.ina.fr/video/Shoah', 'Memoires de la Shoah- Institut National de l’Audiovisuel, Fondation pour la Memóire de la Shoah', '', 'Francia', '15', 'si', '79', 'Europa'),
(67, 44, 'lg-eng', 'http://entretiens.ina.fr/video/Shoah', 'Memoires de la Shoah- Institut National de l’Audiovisuel, Fondation pour la Memóire de la Shoah', '', 'France', '15', 'si', '79', 'Europe'),
(68, 44, 'lg-fra', 'http://entretiens.ina.fr/video/Shoah', 'Memoires de la Shoah- Institut National de l’Audiovisuel, Fondation pour la Memóire de la Shoah', '', 'France', '15', 'si', '79', 'Europe'),
(69, 45, 'lg-cat', 'http://mdc.cbuc.cat/cdm/landingpage/collection/pegaso', 'Pegaso: memòria obrera', '', 'Catalunya', '3', 'si', '79', 'Europa'),
(70, 45, 'lg-spa', 'http://mdc.cbuc.cat/cdm/landingpage/collection/pegaso', 'Pegaso: memòria obrera', '', 'Cataluña', '3', 'si', '79', 'Europa'),
(71, 45, 'lg-eng', 'http://mdc.cbuc.cat/cdm/landingpage/collection/pegaso', 'Pegaso: memòria obrera', '', 'Catalonia', '3', 'si', '79', 'Europe'),
(72, 45, 'lg-fra', 'http://mdc.cbuc.cat/cdm/landingpage/collection/pegaso', 'Pegaso: memòria obrera', '', 'Catalogne', '3', 'si', '79', 'Europe'),
(73, 49, 'lg-cat', 'https://msrp.univie.ac.at/', 'Mauthausen Survivors Documentation Project', '', 'Àustria', '16', 'si', '79', 'Europa'),
(74, 49, 'lg-spa', 'https://msrp.univie.ac.at/', 'Mauthausen Survivors Documentation Project', '', 'Austria', '16', 'si', '79', 'Europa'),
(75, 49, 'lg-eng', 'https://msrp.univie.ac.at/', 'Mauthausen Survivors Documentation Project', '', 'Austria', '16', 'si', '79', 'Europe'),
(76, 49, 'lg-fra', 'https://msrp.univie.ac.at/', 'Mauthausen Survivors Documentation Project', '', 'Autriche', '16', 'si', '79', 'Europe'),
(77, 50, 'lg-cat', 'http://voices.iit.edu/', 'Voices of the Holocaust- Illinois Institute of Technology', '', 'Estats Units d''Amèrica', '17', 'si', '78', 'Amèrica'),
(78, 50, 'lg-spa', 'http://voices.iit.edu/', 'Voices of the Holocaust- Illinois Institute of Technology', '', 'Estados Unidos de América', '17', 'si', '78', 'América'),
(79, 50, 'lg-eng', 'http://voices.iit.edu/', 'Voices of the Holocaust- Illinois Institute of Technology', '', 'United States of America', '17', 'si', '78', 'America'),
(80, 50, 'lg-fra', 'http://voices.iit.edu/', 'Voices of the Holocaust- Illinois Institute of Technology', '', 'États-Unis d''Amérique', '17', 'si', '78', 'Amérique'),
(81, 51, 'lg-cat', 'http://www.library.yale.edu/testimonies/', 'Fortunoff Video Archive- Yale University', '', 'Estats Units d''Amèrica', '17', 'si', '78', 'Amèrica'),
(82, 51, 'lg-spa', 'http://www.library.yale.edu/testimonies/', 'Fortunoff Video Archive- Yale University', '', 'Estados Unidos de América', '17', 'si', '78', 'América'),
(83, 51, 'lg-eng', 'http://www.library.yale.edu/testimonies/', 'Fortunoff Video Archive- Yale University', '', 'United States of America', '17', 'si', '78', 'America'),
(84, 51, 'lg-fra', 'http://www.library.yale.edu/testimonies/', 'Fortunoff Video Archive- Yale University', '', 'États-Unis d''Amérique', '17', 'si', '78', 'Amérique'),
(85, 52, 'lg-cat', 'http://holocaust.umd.umich.edu/', 'Voice/Vision Holocaust Survivor Oral History Archive of the University of Michigan', '', 'Estats Units d''Amèrica', '17', 'si', '78', 'Amèrica'),
(86, 52, 'lg-spa', 'http://holocaust.umd.umich.edu/', 'Voice/Vision Holocaust Survivor Oral History Archive of the University of Michigan', '', 'Estados Unidos de América', '17', 'si', '78', 'América'),
(87, 52, 'lg-eng', 'http://holocaust.umd.umich.edu/', 'Voice/Vision Holocaust Survivor Oral History Archive of the University of Michigan', '', 'United States of America', '17', 'si', '78', 'America'),
(88, 52, 'lg-fra', 'http://holocaust.umd.umich.edu/', 'Voice/Vision Holocaust Survivor Oral History Archive of the University of Michigan', '', 'États-Unis d''Amérique', '17', 'si', '78', 'Amérique'),
(89, 53, 'lg-cat', 'http://sfi.usc.edu/explore', 'Visual History Archive', '', 'Estats Units d''Amèrica', '17', 'si', '78', 'Amèrica'),
(90, 53, 'lg-spa', 'http://sfi.usc.edu/explore', 'Visual History Archive', '', 'Estados Unidos de América', '17', 'si', '78', 'América'),
(91, 53, 'lg-eng', 'http://sfi.usc.edu/explore', 'Visual History Archive', '', 'United States of America', '17', 'si', '78', 'America'),
(92, 53, 'lg-fra', 'http://sfi.usc.edu/explore', 'Visual History Archive', '', 'États-Unis d''Amérique', '17', 'si', '78', 'Amérique'),
(93, 77, 'lg-cat', 'http://www.thehistorymakers.com/', 'The History Makers', '', 'Estats Units d''Amèrica', '17', 'si', '78', 'Amèrica'),
(94, 77, 'lg-spa', 'http://www.thehistorymakers.com/', 'The History Makers', '', 'Estados Unidos de América', '17', 'si', '78', 'América'),
(95, 77, 'lg-eng', 'http://www.thehistorymakers.com/', 'The History Makers', '', 'United States of America', '17', 'si', '78', 'America'),
(96, 77, 'lg-fra', 'http://www.thehistorymakers.com/', 'The History Makers', '', 'États-Unis d''Amérique', '17', 'si', '78', 'Amérique'),
(97, 76, 'lg-cat', 'http://www.doew.at/english', 'Documentation Centre of Austrian Resistance', '', 'Àustria', '16', 'si', '79', 'Europa'),
(98, 76, 'lg-spa', 'http://www.doew.at/english', 'Documentation Centre of Austrian Resistance', '', 'Austria', '16', 'si', '79', 'Europa'),
(99, 76, 'lg-eng', 'http://www.doew.at/english', 'Documentation Centre of Austrian Resistance', '', 'Austria', '16', 'si', '79', 'Europe'),
(100, 76, 'lg-fra', 'http://www.doew.at/english', 'Documentation Centre of Austrian Resistance', '', 'Autriche', '16', 'si', '79', 'Europe'),
(101, 75, 'lg-cat', 'http://www.seminariofuentesorales.es/index.html', 'Seminario de fuentes orales de la Universidad Complutense de Madrid', '', 'Espanya', '1', 'si', '79', 'Europa'),
(102, 75, 'lg-spa', 'http://www.seminariofuentesorales.es/index.html', 'Seminario de fuentes orales de la Universidad Complutense de Madrid', '', 'España', '1', 'si', '79', 'Europa'),
(103, 75, 'lg-eng', 'http://www.seminariofuentesorales.es/index.html', 'Seminario de fuentes orales de la Universidad Complutense de Madrid', '', 'Spain', '1', 'si', '79', 'Europe'),
(104, 75, 'lg-fra', 'http://www.seminariofuentesorales.es/index.html', 'Seminario de fuentes orales de la Universidad Complutense de Madrid', '', 'Espagne', '1', 'si', '79', 'Europe'),
(105, 74, 'lg-cat', 'http://www.ub.edu/cehi/', 'Centre d’Estudis Històrics Internacionals – Universitat de Barcelona', '', 'Catalunya', '3', 'si', '79', 'Europa'),
(106, 74, 'lg-spa', 'http://www.ub.edu/cehi/', 'Centre d’Estudis Històrics Internacionals – Universitat de Barcelona', '', 'Cataluña', '3', 'si', '79', 'Europa'),
(107, 74, 'lg-eng', 'http://www.ub.edu/cehi/', 'Centre d’Estudis Històrics Internacionals – Universitat de Barcelona', '', 'Catalonia', '3', 'si', '79', 'Europe'),
(108, 74, 'lg-fra', 'http://www.ub.edu/cehi/', 'Centre d’Estudis Històrics Internacionals – Universitat de Barcelona', '', 'Catalogne', '3', 'si', '79', 'Europe'),
(109, 73, 'lg-cat', 'http://centresderecerca.uab.cat/cefid/content/arxiu-de-fonts-orals', 'Centre d’Estudis de l’Época Franquista i Democràtica (CEFID)- Universitat Autònoma de Barcelona', '', 'Catalunya', '3', 'si', '79', 'Europa'),
(110, 73, 'lg-spa', 'http://centresderecerca.uab.cat/cefid/content/arxiu-de-fonts-orals', 'Centre d’Estudis de l’Época Franquista i Democràtica (CEFID)- Universitat Autònoma de Barcelona', '', 'Cataluña', '3', 'si', '79', 'Europa'),
(111, 73, 'lg-eng', 'http://centresderecerca.uab.cat/cefid/content/arxiu-de-fonts-orals', 'Centre d’Estudis de l’Época Franquista i Democràtica (CEFID)- Universitat Autònoma de Barcelona', '', 'Catalonia', '3', 'si', '79', 'Europe'),
(112, 73, 'lg-fra', 'http://centresderecerca.uab.cat/cefid/content/arxiu-de-fonts-orals', 'Centre d’Estudis de l’Época Franquista i Democràtica (CEFID)- Universitat Autònoma de Barcelona', '', 'Catalogne', '3', 'si', '79', 'Europe'),
(113, 72, 'lg-cat', 'http://www.ahoaweb.org/', 'AHOA (Ahozko Historiaren Artxiboa)', '', 'Espanya', '1', 'si', '79', 'Europa'),
(114, 72, 'lg-spa', 'http://www.ahoaweb.org/', 'AHOA (Ahozko Historiaren Artxiboa)', '', 'España', '1', 'si', '79', 'Europa'),
(115, 72, 'lg-eng', 'http://www.ahoaweb.org/', 'AHOA (Ahozko Historiaren Artxiboa)', '', 'Spain', '1', 'si', '79', 'Europe'),
(116, 72, 'lg-fra', 'http://www.ahoaweb.org/', 'AHOA (Ahozko Historiaren Artxiboa)', '', 'Espagne', '1', 'si', '79', 'Europe'),
(117, 71, 'lg-cat', 'http://www.unioviedo.es/AFOHSA/', 'Archivo de Fuentes orales para la historia social de Asturias', '', 'Espanya', '1', 'si', '79', 'Europa'),
(118, 71, 'lg-spa', 'http://www.unioviedo.es/AFOHSA/', 'Archivo de Fuentes orales para la historia social de Asturias', '', 'España', '1', 'si', '79', 'Europa'),
(119, 71, 'lg-eng', 'http://www.unioviedo.es/AFOHSA/', 'Archivo de Fuentes orales para la historia social de Asturias', '', 'Spain', '1', 'si', '79', 'Europe'),
(120, 71, 'lg-fra', 'http://www.unioviedo.es/AFOHSA/', 'Archivo de Fuentes orales para la historia social de Asturias', '', 'Espagne', '1', 'si', '79', 'Europe'),
(121, 70, 'lg-cat', 'http://www.nomesevoces.net/', 'Proyecto interuniversitario “Nomes e voces”', '', 'Espanya', '1', 'si', '79', 'Europa'),
(122, 70, 'lg-spa', 'http://www.nomesevoces.net/', 'Proyecto interuniversitario “Nomes e voces”', '', 'España', '1', 'si', '79', 'Europa'),
(123, 70, 'lg-eng', 'http://www.nomesevoces.net/', 'Proyecto interuniversitario “Nomes e voces”', '', 'Spain', '1', 'si', '79', 'Europe'),
(124, 70, 'lg-fra', 'http://www.nomesevoces.net/', 'Proyecto interuniversitario “Nomes e voces”', '', 'Espagne', '1', 'si', '79', 'Europe'),
(125, 69, 'lg-cat', 'http://museuexili.cat/', 'Museu Memorial de l’Exili', '', 'Catalunya', '3', 'si', '79', 'Europa'),
(126, 69, 'lg-spa', 'http://museuexili.cat/', 'Museu Memorial de l’Exili', '', 'Cataluña', '3', 'si', '79', 'Europa'),
(127, 69, 'lg-eng', 'http://museuexili.cat/', 'Museu Memorial de l’Exili', '', 'Catalonia', '3', 'si', '79', 'Europe'),
(128, 69, 'lg-fra', 'http://museuexili.cat/', 'Museu Memorial de l’Exili', '', 'Catalogne', '3', 'si', '79', 'Europe'),
(129, 68, 'lg-cat', 'http://exiliorepublicano.org/presentacion.html', 'Fills i néts de l’exili republicà', '', 'Catalunya', '3', 'si', '79', 'Europa'),
(130, 68, 'lg-spa', 'http://exiliorepublicano.org/presentacion.html', 'Fills i néts de l’exili republicà', '', 'Cataluña', '3', 'si', '79', 'Europa'),
(131, 68, 'lg-eng', 'http://exiliorepublicano.org/presentacion.html', 'Fills i néts de l’exili republicà', '', 'Catalonia', '3', 'si', '79', 'Europe'),
(132, 68, 'lg-fra', 'http://exiliorepublicano.org/presentacion.html', 'Fills i néts de l’exili republicà', '', 'Catalogne', '3', 'si', '79', 'Europe'),
(133, 67, 'lg-cat', 'http://www.memoria.cat/', 'Associació Memòria i Història de Manresa', '', 'Catalunya', '3', 'si', '79', 'Europa'),
(134, 67, 'lg-spa', 'http://www.memoria.cat/', 'Associació Memòria i Història de Manresa', '', 'Cataluña', '3', 'si', '79', 'Europa'),
(135, 67, 'lg-eng', 'http://www.memoria.cat/', 'Associació Memòria i Història de Manresa', '', 'Catalonia', '3', 'si', '79', 'Europe'),
(136, 67, 'lg-fra', 'http://www.memoria.cat/', 'Associació Memòria i Història de Manresa', '', 'Catalogne', '3', 'si', '79', 'Europe'),
(137, 66, 'lg-cat', 'http://www.memorialdelashoah.org/index.php/fr/', 'Memorial de la Shoah', '', 'França', '15', 'si', '79', 'Europa'),
(138, 66, 'lg-spa', 'http://www.memorialdelashoah.org/index.php/fr/', 'Memorial de la Shoah', '', 'Francia', '15', 'si', '79', 'Europa'),
(139, 66, 'lg-eng', 'http://www.memorialdelashoah.org/index.php/fr/', 'Memorial de la Shoah', '', 'France', '15', 'si', '79', 'Europe'),
(140, 66, 'lg-fra', 'http://www.memorialdelashoah.org/index.php/fr/', 'Memorial de la Shoah', '', 'France', '15', 'si', '79', 'Europe'),
(141, 65, 'lg-cat', 'http://www.mistapameti.cz/', 'Tragická Místa Pamêti ', '', 'República Txeca', '12', 'si', '79', 'Europa'),
(142, 65, 'lg-spa', 'http://www.mistapameti.cz/', 'Tragická Místa Pamêti ', '', 'República Checa', '12', 'si', '79', 'Europa'),
(143, 65, 'lg-eng', 'http://www.mistapameti.cz/', 'Tragická Místa Pamêti ', '', 'Czech Republic', '12', 'si', '79', 'Europe'),
(144, 65, 'lg-fra', 'http://www.mistapameti.cz/', 'Tragická Místa Pamêti ', '', 'République Txeca', '12', 'si', '79', 'Europe'),
(145, 64, 'lg-cat', 'http://www.geschichtswerkstatt-europa.org/homepage.html ', 'Gescichtswerkstatt Europa', '', 'Alemanya', '8', 'si', '79', 'Europa'),
(146, 64, 'lg-spa', 'http://www.geschichtswerkstatt-europa.org/homepage.html ', 'Gescichtswerkstatt Europa', '', 'Alemania', '8', 'si', '79', 'Europa'),
(147, 64, 'lg-eng', 'http://www.geschichtswerkstatt-europa.org/homepage.html ', 'Gescichtswerkstatt Europa', '', 'Germany', '8', 'si', '79', 'Europe'),
(148, 64, 'lg-fra', 'http://www.geschichtswerkstatt-europa.org/homepage.html ', 'Gescichtswerkstatt Europa', '', 'Allemagne', '8', 'si', '79', 'Europe'),
(149, 63, 'lg-cat', 'http://www.instytut.net/en/ ', 'Insitute for Applied History – Society and Science in Dialogue', '', 'Alemanya', '8', 'si', '79', 'Europa'),
(150, 63, 'lg-spa', 'http://www.instytut.net/en/ ', 'Insitute for Applied History – Society and Science in Dialogue', '', 'Alemania', '8', 'si', '79', 'Europa'),
(151, 63, 'lg-eng', 'http://www.instytut.net/en/ ', 'Insitute for Applied History – Society and Science in Dialogue', '', 'Germany', '8', 'si', '79', 'Europe'),
(152, 63, 'lg-fra', 'http://www.instytut.net/en/ ', 'Insitute for Applied History – Society and Science in Dialogue', '', 'Allemagne', '8', 'si', '79', 'Europe'),
(153, 62, 'lg-cat', 'http://www.karta.org.pl/', 'Osrodek Karta', '', 'Polònia', '14', 'si', '79', 'Europa'),
(154, 62, 'lg-spa', 'http://www.karta.org.pl/', 'Osrodek Karta', '', 'Polonia', '14', 'si', '79', 'Europa'),
(155, 62, 'lg-eng', 'http://www.karta.org.pl/', 'Osrodek Karta', '', 'Poland', '14', 'si', '79', 'Europe'),
(156, 62, 'lg-fra', 'http://www.karta.org.pl/', 'Osrodek Karta', '', 'Pologne', '14', 'si', '79', 'Europe'),
(157, 61, 'lg-cat', 'http://minaloto.org/', 'Institute for Studies of the Recent Past ', '', 'Bulgària', '13', 'si', '79', 'Europa'),
(158, 61, 'lg-spa', 'http://minaloto.org/', 'Institute for Studies of the Recent Past ', '', 'Bulgaria', '13', 'si', '79', 'Europa'),
(159, 61, 'lg-eng', 'http://minaloto.org/', 'Institute for Studies of the Recent Past ', '', 'Bulgaria', '13', 'si', '79', 'Europe'),
(160, 61, 'lg-fra', 'http://minaloto.org/', 'Institute for Studies of the Recent Past ', '', 'Bulgarie', '13', 'si', '79', 'Europe'),
(161, 60, 'lg-cat', 'http://www.memorialsighet.ro/index.php?lang=en', 'The Memorial of the Victims of Communism and of the Resistance', '', 'Romania', '11', 'si', '79', 'Europa'),
(162, 60, 'lg-spa', 'http://www.memorialsighet.ro/index.php?lang=en', 'The Memorial of the Victims of Communism and of the Resistance', '', 'Rumanía', '11', 'si', '79', 'Europa'),
(163, 60, 'lg-eng', 'http://www.memorialsighet.ro/index.php?lang=en', 'The Memorial of the Victims of Communism and of the Resistance', '', 'Romania', '11', 'si', '79', 'Europe'),
(164, 60, 'lg-fra', 'http://www.memorialsighet.ro/index.php?lang=en', 'The Memorial of the Victims of Communism and of the Resistance', '', 'Rumanie', '11', 'si', '79', 'Europe'),
(165, 59, 'lg-cat', 'http://www.ustrcr.cz/en', 'The Institute for the Study of Totalitarian Regimes ', '', 'República Txeca', '12', 'si', '79', 'Europa'),
(166, 59, 'lg-spa', 'http://www.ustrcr.cz/en', 'The Institute for the Study of Totalitarian Regimes ', '', 'República Checa', '12', 'si', '79', 'Europa'),
(167, 59, 'lg-eng', 'http://www.ustrcr.cz/en', 'The Institute for the Study of Totalitarian Regimes ', '', 'Czech Republic', '12', 'si', '79', 'Europe'),
(168, 59, 'lg-fra', 'http://www.ustrcr.cz/en', 'The Institute for the Study of Totalitarian Regimes ', '', 'République Txeca', '12', 'si', '79', 'Europe'),
(169, 58, 'lg-cat', 'http://www.rommuz.cz', 'Museum of Romani Culture ', '', 'República Txeca', '12', 'si', '79', 'Europa'),
(170, 58, 'lg-spa', 'http://www.rommuz.cz', 'Museum of Romani Culture ', '', 'República Checa', '12', 'si', '79', 'Europa'),
(171, 58, 'lg-eng', 'http://www.rommuz.cz', 'Museum of Romani Culture ', '', 'Czech Republic', '12', 'si', '79', 'Europe'),
(172, 58, 'lg-fra', 'http://www.rommuz.cz', 'Museum of Romani Culture ', '', 'République Txeca', '12', 'si', '79', 'Europe'),
(173, 57, 'lg-cat', 'http://www.terrorhaza.hu/', 'Terror Haza', '', 'Hongria', '7', 'si', '79', 'Europa'),
(174, 57, 'lg-spa', 'http://www.terrorhaza.hu/', 'Terror Haza', '', 'Hungría', '7', 'si', '79', 'Europa'),
(175, 57, 'lg-eng', 'http://www.terrorhaza.hu/', 'Terror Haza', '', 'Hungary', '7', 'si', '79', 'Europe'),
(176, 57, 'lg-fra', 'http://www.terrorhaza.hu/', 'Terror Haza', '', 'Hongrie', '7', 'si', '79', 'Europe'),
(177, 56, 'lg-cat', 'http://www.iiccr.ro/en/', 'The Institute for the Investigation of the Communist Crimes and the Memory of the Romanian Exile', '', 'Romania', '11', 'si', '79', 'Europa'),
(178, 56, 'lg-spa', 'http://www.iiccr.ro/en/', 'The Institute for the Investigation of the Communist Crimes and the Memory of the Romanian Exile', '', 'Rumanía', '11', 'si', '79', 'Europa'),
(179, 56, 'lg-eng', 'http://www.iiccr.ro/en/', 'The Institute for the Investigation of the Communist Crimes and the Memory of the Romanian Exile', '', 'Romania', '11', 'si', '79', 'Europe'),
(180, 56, 'lg-fra', 'http://www.iiccr.ro/en/', 'The Institute for the Investigation of the Communist Crimes and the Memory of the Romanian Exile', '', 'Rumanie', '11', 'si', '79', 'Europe'),
(181, 55, 'lg-cat', 'http://www.komisija.lt/en/', 'The International Comission for the Evaluation of the Crimes of the Nazi and Soviet Occupation Regimes in Lithuania', '', 'Lituània', '10', 'si', '79', 'Europa'),
(182, 55, 'lg-spa', 'http://www.komisija.lt/en/', 'The International Comission for the Evaluation of the Crimes of the Nazi and Soviet Occupation Regimes in Lithuania', '', 'Lituania', '10', 'si', '79', 'Europa'),
(183, 55, 'lg-eng', 'http://www.komisija.lt/en/', 'The International Comission for the Evaluation of the Crimes of the Nazi and Soviet Occupation Regimes in Lithuania', '', 'Lithuania', '10', 'si', '79', 'Europe'),
(184, 55, 'lg-fra', 'http://www.komisija.lt/en/', 'The International Comission for the Evaluation of the Crimes of the Nazi and Soviet Occupation Regimes in Lithuania', '', 'Lituanie', '10', 'si', '79', 'Europe'),
(185, 54, 'lg-cat', 'http://timorarchives.wordpress.com/archives-in-timor/camstl/', 'Centro Audiovisual Max Stahl Timor-Leste', '', 'Timor Oriental', '9', 'si', '80', 'Àsia'),
(186, 54, 'lg-spa', 'http://timorarchives.wordpress.com/archives-in-timor/camstl/', 'Centro Audiovisual Max Stahl Timor-Leste', '', 'Timor Oriental', '9', 'si', '80', 'Asia'),
(187, 54, 'lg-eng', 'http://timorarchives.wordpress.com/archives-in-timor/camstl/', 'Centro Audiovisual Max Stahl Timor-Leste', '', 'East Timor', '9', 'si', '80', 'Asia'),
(188, 54, 'lg-fra', 'http://timorarchives.wordpress.com/archives-in-timor/camstl/', 'Centro Audiovisual Max Stahl Timor-Leste', '', 'Timor Oriental', '9', 'si', '80', 'Asie'),
(189, 48, 'lg-cat', 'http://www.mcu.es/archivos/MC/CDMH/', 'Centro Documental de la Memoria Histórica', '', 'Espanya', '1', 'si', '79', 'Europa'),
(190, 48, 'lg-spa', 'http://www.mcu.es/archivos/MC/CDMH/', 'Centro Documental de la Memoria Histórica', '', 'España', '1', 'si', '79', 'Europa'),
(191, 48, 'lg-eng', 'http://www.mcu.es/archivos/MC/CDMH/', 'Centro Documental de la Memoria Histórica', '', 'Spain', '1', 'si', '79', 'Europe'),
(192, 48, 'lg-fra', 'http://www.mcu.es/archivos/MC/CDMH/', 'Centro Documental de la Memoria Histórica', '', 'Espagne', '1', 'si', '79', 'Europe'),
(193, 47, 'lg-cat', 'http://www.memoriaabierta.org.ar/bases/opac/Registros/oral/index.html', 'Arxiu de testimonis de Memoria Abierta. Argentina', '', 'Argentina', '6', 'si', '78', 'Amèrica'),
(194, 47, 'lg-spa', 'http://www.memoriaabierta.org.ar/bases/opac/Registros/oral/index.html', 'Arxiu de testimonis de Memoria Abierta. Argentina', '', 'Argentina', '6', 'si', '78', 'América'),
(195, 47, 'lg-eng', 'http://www.memoriaabierta.org.ar/bases/opac/Registros/oral/index.html', 'Arxiu de testimonis de Memoria Abierta. Argentina', '', 'Argentina', '6', 'si', '78', 'America'),
(196, 47, 'lg-fra', 'http://www.memoriaabierta.org.ar/bases/opac/Registros/oral/index.html', 'Arxiu de testimonis de Memoria Abierta. Argentina', '', 'Argentine', '6', 'si', '78', 'Amérique'),
(197, 95, 'lg-cat', 'http://phonotheque.hypotheses.org', 'Phonotèque de la Maison Méditerranéenne des Sciences de l''Homme ', '', 'França', '15', 'si', '79', 'Europa'),
(198, 95, 'lg-spa', 'http://phonotheque.hypotheses.org', 'Phonotèque de la Maison Méditerranéenne des Sciences de l''Homme ', '', 'Francia', '15', 'si', '79', 'Europa'),
(199, 95, 'lg-eng', 'http://phonotheque.hypotheses.org', 'Phonotèque de la Maison Méditerranéenne des Sciences de l''Homme ', '', 'France', '15', 'si', '79', 'Europe'),
(200, 95, 'lg-fra', 'http://phonotheque.hypotheses.org', 'Phonotèque de la Maison Méditerranéenne des Sciences de l''Homme ', '', 'France', '15', 'si', '79', 'Europe'),
(201, 96, 'lg-cat', 'www.postbellum.cz/', 'Post Bellum', '', 'República Txeca', '12', 'si', '79', 'Europa'),
(202, 96, 'lg-spa', 'www.postbellum.cz/', 'Post Bellum', '', 'República Checa', '12', 'si', '79', 'Europa'),
(203, 96, 'lg-eng', 'www.postbellum.cz/', 'Post Bellum', '', 'Czech Republic', '12', 'si', '79', 'Europe'),
(204, 96, 'lg-fra', 'www.postbellum.cz/', 'Post Bellum', '', 'République Txeca', '12', 'si', '79', 'Europe'),
(205, 97, 'lg-cat', 'http://www.auschwitz.be/index.php/fr/', 'Fondation Auschwitz- Mémoire d''Auschwitz ASBL', '', 'Bèlgica', '26', 'si', '79', 'Europa'),
(206, 97, 'lg-spa', 'http://www.auschwitz.be/index.php/fr/', 'Fondation Auschwitz- Mémoire d''Auschwitz ASBL', '', 'Bélgica', '26', 'si', '79', 'Europa'),
(207, 97, 'lg-eng', 'http://www.auschwitz.be/index.php/fr/', 'Fondation Auschwitz- Mémoire d''Auschwitz ASBL', '', 'Belgium', '26', 'si', '79', 'Europe'),
(208, 97, 'lg-fra', 'http://www.auschwitz.be/index.php/fr/', 'Fondation Auschwitz- Mémoire d''Auschwitz ASBL', '', 'Belgique', '26', 'si', '79', 'Europe'),
(209, 98, 'lg-cat', 'http://libraries.ucsd.edu/speccoll/scwmemory/', 'Spanish Civil War Memory Project- University of California, San Diego', '', 'Estats Units d''Amèrica', '17', 'si', '78', 'Amèrica'),
(210, 98, 'lg-spa', 'http://libraries.ucsd.edu/speccoll/scwmemory/', 'Spanish Civil War Memory Project- University of California, San Diego', '', 'Estados Unidos de América', '17', 'si', '78', 'América'),
(211, 98, 'lg-eng', 'http://libraries.ucsd.edu/speccoll/scwmemory/', 'Spanish Civil War Memory Project- University of California, San Diego', '', 'United States of America', '17', 'si', '78', 'America'),
(212, 98, 'lg-fra', 'http://libraries.ucsd.edu/speccoll/scwmemory/', 'Spanish Civil War Memory Project- University of California, San Diego', '', 'États-Unis d''Amérique', '17', 'si', '78', 'Amérique');

-- --------------------------------------------------------

--
-- Table structure for table `entrevistas_expertos`
--

CREATE TABLE IF NOT EXISTS `entrevistas_expertos` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Presentación - mdcat42',
  `entrevistas_expertos_personas` text COLLATE utf8_unicode_ci COMMENT 'Entrevista a expertos - mdcat43',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat40'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `entrevistas_expertos`
--

INSERT INTO `entrevistas_expertos` (`id`, `id_matrix`, `lang`, `presentacion`, `entrevistas_expertos_personas`, `publicacion`) VALUES
(1, 4, 'lg-cat', '', '[]', 'no'),
(2, 4, 'lg-spa', '', '[]', 'no'),
(3, 4, 'lg-eng', '', '[]', 'no'),
(4, 4, 'lg-fra', '', '[]', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `entrevistas_expertos_personas`
--

CREATE TABLE IF NOT EXISTS `entrevistas_expertos_personas` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `video` text COLLATE utf8_unicode_ci COMMENT 'Vídeo - rsc35',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - rsc23',
  `subtitulado` text COLLATE utf8_unicode_ci COMMENT 'Descripción / transcripción audiovisual - rsc36',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Difusión - rsc20'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `exposiciones_virtuales`
--

CREATE TABLE IF NOT EXISTS `exposiciones_virtuales` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Texto de introducción - mdcat223',
  `exposiciones_virtuales_portal` text COLLATE utf8_unicode_ci COMMENT 'Exposiciones virtuales - mdcat224',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat222'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `exposiciones_virtuales`
--

INSERT INTO `exposiciones_virtuales` (`id`, `id_matrix`, `lang`, `presentacion`, `exposiciones_virtuales_portal`, `publicacion`) VALUES
(1, 25, 'lg-cat', '<p><img src="../../../../web/images/branguli/ACBL50-4-N-669.jpg" alt="" width="112" height="76" /></p> <h2 style="text-align: left;"><strong>Exposicions virtuals</strong></h2> <p>A partir de l’exposició <a href="../../../../web_cet/ca/" target="_blank">“Catalunya en transició”</a> del Memorial Democràtic, es va encetar paral·lelament un projecte de recollida de testimonis a l’entorn de la transició democràtica a Catalunya que va recollir un total de 30 entrevistes.</p> <p>D’aquell projecte d’entrevistes s’han seleccionat 179 fragments que acompanyen els àmbits de l’exposició i que mostren un relat ampli i estructurat de la transició democràtica a Catalunya.</p> <p>Aquell projecte de recollida d’entrevistes es preserva al Banc Audiovisual de Testimonis, i l’exposició virtual que va generar és consultable des d’aquí.</p> <p> </p> <p> </p> <p> </p>', '["26"]', 'si'),
(2, 25, 'lg-spa', '<p><img src="../../../../web/images/branguli/ACBL50-4-N-669.jpg" alt="" width="112" height="76" /></p> <h2 style="text-align: left;"><strong>Exposiciones virtuales</strong></h2> <p>A partir de la exposición <a href="../../../../web_cet/es/" target="_blank">“Catalunya en transició”</a> del Memorial Democràtico, se abrió paralelamente un proyecto de recogida de testimonios sobre la transición democrática en Cataluña, que recogió un total de 30 entrevistas.</p> <p>De aquel proyecto de entrevistas se han seleccionado 179 fragmentos que acompañan los ámbitos de la exposición y que muestran un relato amplio y estructurado de la transición democrática en Cataluña.</p> <p>Aquel proyecto de recogida de entrevistas se preserva en el Banco Audiovisual de Testimonios, y la exposición virtual que generó es consultable desde aquí.</p> <p> </p> <p> </p>', '["26"]', 'si'),
(3, 25, 'lg-eng', '<p><img src="../../../../web/images/branguli/ACBL50-4-N-669.jpg" alt="" width="112" height="76" /></p> <h2 style="text-align: left;"> <strong>Virtual exhibitions</strong></h2> <p>Based on and at the same time as the Democratic Memory''s exhibition <a href="../../../../web_cet/en/" target="_blank">''Catalunya en transició''</a> (Catalonia in transition), a project to gather testimonies on the transition to democracy in Catalonia was carried out, which includes a total of 30 interviews.</p> <p>From this interview project 179 fragments have been selected to be included in different parts of the exhibition, showing a wide and structured story of the transition to democracy in Catalonia.</p> <p>This project involving the recording of interviews is archived with the Audiovisual Bank of Testimonies, and here you can consult the virtual exhibition that was created.</p> <p> </p>', '["26"]', 'si'),
(4, 25, 'lg-fra', '<p><img src="../../../../web/images/branguli/ACBL50-4-N-669.jpg" alt="" width="112" height="76" /></p> <h2 style="text-align: left;"><strong>Expositions virtuelles</strong></h2> <p>À partir de l''exposition «<a href="../../../../web_cet/fr/" target="_blank">Catalunya en transició</a>» (La Catalogne en transition) du Mémorial Démocratique, a été réalisé en parallèle un projet de recueil de témoignages autour de la transition démocratique en Catalogne, qui a englobé un total de 30 entretiens.</p> <p>De ce projet d''entretiens, ont été sélectionnés 179 fragments qui accompagnent les domaines de l''exposition, en montrant un récit large et structuré de la transition démocratique en Catalogne.</p> <p>Ce projet de recueil d''entretiens est conservé à la Banque Audiovisuelle de Témoignages, et l''exposition virtuelle qui en émane, et qui est consultable ici. </p>', '["26"]', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `exposiciones_virtuales_portal`
--

CREATE TABLE IF NOT EXISTS `exposiciones_virtuales_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `comentario` text COLLATE utf8_unicode_ci COMMENT 'Comentario - mdcat278',
  `weblink` text COLLATE utf8_unicode_ci COMMENT 'Enlace web - mdcat279',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `exposiciones_virtuales_portal`
--

INSERT INTO `exposiciones_virtuales_portal` (`id`, `id_matrix`, `lang`, `titulo`, `comentario`, `weblink`, `publicacion`) VALUES
(1, 26, 'lg-cat', 'Catalunya en transició', '', 'http://bancmemorial.gencat.cat/web_cet/ca/', 'si'),
(2, 26, 'lg-spa', 'Catalunya en transició', '', 'http://bancmemorial.gencat.cat/web_cet/ca/', 'si'),
(3, 26, 'lg-eng', '''Catalunya en transició'' (Catalonia in transition)', '', 'http://bancmemorial.gencat.cat/web_cet/ca/', 'si'),
(4, 26, 'lg-fra', 'Catalunya en transició', '', 'http://bancmemorial.gencat.cat/web_cet/ca/', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `formularios`
--

CREATE TABLE IF NOT EXISTS `formularios` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Normativa y limitaciones - mdcat205',
  `formularios_precios` text COLLATE utf8_unicode_ci COMMENT 'Precios - mdcat206',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat204'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `formularios_precios`
--

CREATE TABLE IF NOT EXISTS `formularios_precios` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `gestion_ho`
--

CREATE TABLE IF NOT EXISTS `gestion_ho` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Texto de introducción - mdcat176',
  `gestion_ho_portal` text COLLATE utf8_unicode_ci COMMENT 'Sistema de gestión de HO - mdcat177',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat175'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `gestion_ho`
--

INSERT INTO `gestion_ho` (`id`, `id_matrix`, `lang`, `presentacion`, `gestion_ho_portal`, `publicacion`) VALUES
(1, 23, 'lg-cat', '<h2 style="text-align: justify;"><strong><img src="../../../../web/images/branguli/ANC1-42-N-34525.jpg" alt="" width="97" height="66" /></strong></h2> <h2 style="text-align: left;"><strong>Programari</strong></h2> <p>El Banc Audiovisual de Testimonis es gestiona a partir del programa <a href="http://www.fmomo.org/dedalo/pg/?lang=ca" target="_blank">Dédalo</a>, basat en codi lliure, i que permet la gestió integral del projecte.</p> <p>Aquest programari ha estat concebut per a la gestió d’història oral i ens permet controlar tot el procés de treball, des de l’entrada de les entrevistes a l’arxiu fins a la seua difusió en línia, incloent la transcripció de les entrevistes, la creació del tesaurus, la indexació dels continguts i la difusió dels projectes de recerca.</p> <p>Atès que es basa en codi lliure, el programari s’ha anat adaptant a les necessitats del projecte. A continuació trobareu informacions relatives al programa <a href="http://www.fmomo.org/dedalo/pg/?lang=ca" target="_blank">Dédalo</a>.</p>', '["24"]', 'si'),
(2, 23, 'lg-spa', '<p><img src="../../../../web/images/branguli/ANC1-42-N-34525.jpg" alt="" width="97" height="66" /></p> <h2 style="text-align: left;"><strong>Software</strong></h2> <p>El Banco Audiovisual de Testimonios se gestiona a partir del programa <a href="http://www.fmomo.org/dedalo/pg/?lang=es" target="_blank">Dédalo</a>, basado en código libre y que permite la gestión integral del proyecto.</p> <p>Este software ha sido concebido para la gestión de historia oral, y nos permite controlar todo el proceso de trabajo, desde la entrada de las entrevistas en el archivo hasta su difusión en línea, incluidas la transcripción de las entrevistas, la creación del tesauro, la indexación de los contenidos y la difusión de los proyectos de investigación.</p> <p>Dado que se basa en código libre, el software se ha ido adaptando a las necesidades del proyecto. A continuación se ofrecen información relativa al programa <a href="http://www.fmomo.org/dedalo/pg/?lang=es" target="_blank">Dédalo</a>.</p>', '["24"]', 'si'),
(3, 23, 'lg-eng', '<p><img src="../../../../web/images/branguli/ANC1-42-N-34525.jpg" alt="" width="97" height="66" /></p> <h2 style="text-align: left;"><strong>Software</strong></h2> <p>The Audiovisual Bank of Testimonies is managed using the <a href="http://www.fmomo.org/dedalo/pg/?lang=en" target="_blank">Dédalo</a> program, based on free code, and allows the project to be managed in its entirety.</p> <p>This software was created for the management of oral history and enables us to control the complete work process, from the uploading of interviews to the archive to their online publication, including the transcription of interviews, the creation of the thesaurus, indexing of content and the dissemination of the research projects.</p> <p>Given that it is based on free code, the software is adapted to the requirements of the project. Here you will find information regarding the <a href="http://www.fmomo.org/dedalo/pg/?lang=en" target="_blank">Dédalo</a> program.</p>', '["24"]', 'si'),
(4, 23, 'lg-fra', '<p><img src="../../../../web/images/branguli/ANC1-42-N-34525.jpg" alt="" width="97" height="66" /></p> <h2 style="text-align: left;"><strong>Programme</strong></h2> <p>La Banque Audiovisuelle de Témoignages est gérée à partir du programme <a href="http://www.fmomo.org/dedalo/pg/?lang=fr" target="_blank">Dédalo</a>, qui repose sur un code libre, et qui permet la gestion intégrale du projet.</p> <p>Ce programme a été conçu aux fins de la gestion de l''histoire orale et nous permet de contrôler tout le processus de travail, de l''entrée des entretiens dans le fichier à leur diffusion en ligne, y compris la transcription des entretiens, la création du thésaurus, l''indexation des contenus et la diffusion des projets de recherche.  </p> <p>Se fondant sur un code libre, le programme s''est adapté progressivement aux besoins du projet. Vous trouverez ci-après les informations relatives au programme <a href="http://www.fmomo.org/dedalo/pg/?lang=fr" target="_blank">Dédalo</a>. </p>', '["24"]', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `gestion_ho_portal`
--

CREATE TABLE IF NOT EXISTS `gestion_ho_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `comentario` text COLLATE utf8_unicode_ci COMMENT 'Comentario - mdcat278',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `weblink` text COLLATE utf8_unicode_ci COMMENT 'Enlace web - mdcat279',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `gestion_ho_portal`
--

INSERT INTO `gestion_ho_portal` (`id`, `id_matrix`, `lang`, `titulo`, `comentario`, `fecha`, `version`, `doc_pdf`, `weblink`, `publicacion`) VALUES
(1, 24, 'lg-cat', 'En el laberinto la memoria', '', 'Tuesday12-2014-07-08T00:00:00+02:00am31', '', 'mdcat288-18', '', 'si'),
(2, 24, 'lg-spa', 'En el laberinto la memoria', '', 'Tuesday12-00pam', '', 'mdcat288-20', '', 'si'),
(3, 24, 'lg-eng', 'En el laberinto la memoria', '', 'Tuesday12-Europe/Madrid712', '', 'mdcat288-20', '', 'si'),
(4, 24, 'lg-fra', 'En el laberinto la memoria', '', 'Tuesday12-fTue, 08 Jul 2014 00:00:00 +0200am', '', 'mdcat288-20', '', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `info_legal`
--

CREATE TABLE IF NOT EXISTS `info_legal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `info_legal_doc` text COLLATE utf8_unicode_ci COMMENT 'Documentación - mdcat35',
  `intro` text COLLATE utf8_unicode_ci COMMENT 'Introducción - mdcat34',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat32'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `info_legal`
--

INSERT INTO `info_legal` (`id`, `id_matrix`, `lang`, `info_legal_doc`, `intro`, `publicacion`) VALUES
(1, 3, 'lg-cat', '[]', '<h2 style="text-align: left;"><strong>Informació legal</strong></h2> <p>Totes les entrevistes contingudes en aquest arxiu i fetes públiques tenen el consentiment legal signat de cada entrevistat, que ha cedit voluntàriament els seus drets d’imatge.</p> <p>El Memorial Democràtic no es fa responsable de les opinions dels entrevistats.</p> <p>No és possible la descàrrega d’entrevistes per mitjans legals. L´ús fraudulent de les imatges és punible penalment.</p> <p>L’exhibició pública amb finalitats comercials i/o lucratives està prohibida.</p> <p>L’exhibició pública amb finalitats d''estudi, ensenyament, investigació o difusió cultural està permesa.</p> <p>Per a la citació d’entrevistes, és obligatori assenyalar la procedència:</p> <p style="text-align: center;">Banc Audiovisual de Testimonis del Memorial Democràtic</p> <p style="text-align: center;"><a href="../../../../">http://bancmemorial.gencat.cat</a></p> <p>Per a publicacions que utilitzin fragments transcrits de les entrevistes, cal enviar còpia del treball al Memorial Democràtic.</p> <div><em>Protecció de dades:</em></div> <div><em>D''acord amb l''article 5 de la Llei orgànica 15/1999, de 13 de desembre, de protecció de dades de caràcter personal, les vostes dades seran incorporades al fitxer ''Banc Audiovisual del Memorial Democràtic'', del qual és responsable el Memorial Democràtic. La finalitat és enregistrar i reunir en una base de dades els testimonis dels fets viscuts entre 1931 i 1980 en relació amb la memòria democràtica, per tal d''ampliar i difondre el coneixement d''aquests fets de manera científica i objectiva i facilitar-ne la comprensió, tal com es preveu en el marc de les funcions de la Llei 13/2007, de 31 d''octubre, del Memorial Democràtic. Difondre els testimonis enregistrats i fer-ne difusió pública, a través de mitjans propis habilitats gràcies al consentiment signat dels testimonis i d''acord amb la legislació vigent. Atendre les sol·licituds de cessió de drets d''explotació dels enregistraments (drets de reproducció, distribució, comunicació pública i transformació) dels investigadors que acreditin un interès legítim, en els supòsits que estableix la legislació vigent. Podeu exercir els drets d''accés, rectificació, cancel·lació i oposició mitjançant un escrit adreçat al director del Memorial Democràtic, Peu de la Creu, 2-4, 08001 Barcelona. </em></div>', 'si'),
(2, 3, 'lg-spa', '[]', '<h2 style="text-align: left;">Información legal:</h2> <p>Todas las entrevistas contenidas en este archivo y hechas públicas tienen el consentimiento legal firmado de cada entrevistado, que ha cedido voluntariamente sus derechos de imagen.</p> <p>El Memorial Democràtic no se hace responsable de las opiniones de los entrevistados.</p> <p>No es posible la descarga de entrevistas por medios legales. El uso fraudulento de las imágenes es punible penalmente.</p> <p>La exhibición pública con finalidades comerciales y/o lucrativas está prohibida.</p> <p>La exhibición pública con finalidades de estudio, enseñanza, investigación o difusión cultural está permitida.</p> <p>Para la citación de entrevistas, es obligatorio señalar la procedencia:</p> <p style="text-align: center;">Banco Audiovisual de Testimonios del Memorial Democràtic</p> <p style="text-align: center;"><a href="../../../../">http://bancmemorial.gencat.cat</a></p> <p>Para publicaciones que utilicen fragmentos transcritos de las entrevistas, hay que enviar copia del trabajo al Memorial Democràtic.</p> <p><em>Protección de datos:</em></p> <p><em>De acuerdo con el artículo 5 de la Ley Orgánica 15/1999, de 13 de diciembre, de protección de datos de carácter personal, sus datos serán incorporados en el fichero “Banc Audiovisual del Memorial Democràtic”, del que es responsable el Memorial Democràtic. La finalidad es grabar y reunir en una base de datos los testigos de los hechos vividos entre 1931 y 1980 en relación con la memoria democrática, a fin de ampliar y difundir el conocimiento de estos hechos de forma científica y objetiva, así como facilitar su comprensión, tal como se prevé en el marco de las funciones de la Ley 13/2007, de 31 de octubre, del Memorial Democrático. Difundir los testimonios grabados y hacer difusión pública, a través de medios propios habilitados gracias al consentimiento firmado de los testigos y de acuerdo con la legislación vigente. Atender las solicitudes de cesión de derechos de explotación de las grabaciones (derechos de reproducción, distribución, comunicación pública y transformación) de los investigadores que acrediten un interés legítimo, en los supuestos que establece la legislación vigente. Puede ejercer los derechos de acceso, rectificación, cancelación y oposición mediante un escrito dirigido al director del Memorial Democrático, Peu de la Creu, 2-4, 08001 Barcelona.</em></p>', 'si'),
(3, 3, 'lg-eng', '[]', '<h2 style="text-align: left;">Legal information</h2> <p>All of the interviews held in this archive and made public have the signed legal consent of the interviewee, each of whom have voluntarily surrendered their image rights. </p> <p>The Democratic Memory will not be held responsible for the opinions of the interviewees.</p> <p>The interviews cannot be downloaded for legal reasons. The improper use of the images is punishable under criminal law.</p> <p>The public broadcast of the content for commercial and/or lucrative purposes is prohibited.</p> <p>The public broadcast of the content for study, educational, research or cultural purposes, is permitted.</p> <p>The following source must be stated when citing interviews:</p> <p style="text-align: center;">Audiovisual Bank of Testimonies of the Democratic Memory</p> <p style="text-align: center;"><a href="../../../../">http://bancmemorial.gencat.cat</a></p> <p>For publications that use written fragments of the interview transcripts, a copy of the work must be sent to the Democratic Memory.</p> <p><em>Data protection:</em></p> <p><em>In accordance with article 5 of Organic Law 15/1999 of 13 December on Personal Data Protection, you are herein notified that your details shall be added to the file ‘Memorial Democràtic Audiovisual Data Bank, for which the Memorial Democràtic is responsible. The purpose is to record and collect testimonies in a database on the events experienced between 1931 and 1980 related to democratic memories, in order to increase and propagate knowledge of these events in a scientific and objective way to thus contribute to overall understanding, as set out in the framework of the functions of Act 13/2007 of 31 October by the Memorial Democràtic. Disseminate the testimonies recorded and carry out their public propagation via own means established thanks to the signed consents on said testimonies and in accordance with current legislation in force. Heed requests for transferring exploitation rights of the recordings (reproduction, distribution, public communication and transformation) of researchers who accredit their legitimate interest, under the cases established by current legislation in force. You may exercise your rights to access, rectify, cancel or oppose by sending a letter addressed to the director of Memorial Democràtic, Peu de la Creu, 2-4, 08001 Barcelona. </em></p>', 'si'),
(4, 3, 'lg-fra', '[]', '<h2 style="text-align: left;">Mention légale</h2> <p>Tous les entretiens contenus dans ce fichier et rendus publics bénéficient du consentement légal signé de chaque personne interrogée, qui a cédé volontairement ses droits à l''image. </p> <p>Le Mémorial Démocratique est dégagé de toute responsabilité concernant l''opinion des personnes interrogée.</p> <p>Le téléchargement d''entretiens par des moyens légaux est impossible. L''utilisation frauduleuse des images est passible de sanctions pénales.</p> <p>La diffusion publique à des fins commerciales et/ou lucratives est interdite.</p> <p>La diffusion publique à des fins d''études, d''enseignement, de recherche ou culturelles est autorisée.</p> <p>En  cas de mention aux entretiens, il sera obligatoire d''en indiquer l''origine :</p> <p style="text-align: center;">Banque Audiovisuelle de Témoignages du Mémorial Démocratique</p> <p style="text-align: center;"><a href="../../../../">http://bancmemorial.gencat.cat</a></p> <p>Pour des publications utilisant des fragments retranscrits des entretiens, il conviendra d''en envoyer une copie au Mémorial Démocratique. </p> <p><em>Protection des données :</em></p> <p><em>Conformément à l’article 5 de la loi organique 15/1999, du 13 décembre, relative à la protection des données personnelles, vos données seront incorporées dans un fichier de « Banque Audiovisuelle du Mémorial Démocratique », qui appartient au Mémorial Démocratique. L’objectif est d’enregistrer et de réunir dans une base de données, les témoignages des faits vécus entre 1931 et 1980 liés à la mémoire démocratique, afin d’élargir et de diffuser la connaissance de ces faits de façon scientifique et objective et de faciliter leur compréhension, comme cela est établi dans le cadre des fonctions de la Loi 13/2007, du 31 octobre, du Mémorial Démocratique. Divulguer les témoignages enregistrés et les diffuser publiquement au travers de nos propres moyens, habilités grâce au consentement signé des témoignages et conformément à la loi en vigueur. Répondre aux demandes de cession des droits d’exploitation des enregistrements (droits de reproduction, distribution, communication publique et transformation) des chercheurs qui prouvent un intérêt légitime, dans les cas établis par la loi en vigueur. Vous disposez d’un droit d’accès, de correction, d’annulation et d’opposition que vous pouvez exercer en écrivant au Mémorial Démocratique, Peu de la Creu, 2-4, 08001 Barcelone.</em></p>', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `info_legal_doc`
--

CREATE TABLE IF NOT EXISTS `info_legal_doc` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `Comentario` text COLLATE utf8_unicode_ci COMMENT 'Comentario - mdcat278',
  `html` text COLLATE utf8_unicode_ci COMMENT 'Documento HTML - mdcat289',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `listado_entrevistados`
--

CREATE TABLE IF NOT EXISTS `listado_entrevistados` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Presentación - mdcat131',
  `listado_entrevistados_portal` text COLLATE utf8_unicode_ci COMMENT 'Entrevistados por proyecto - mdcat132',
  `publicacion` text COLLATE utf8_unicode_ci COMMENT 'Publicación - mdcat130'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `listado_entrevistados_logo`
--

CREATE TABLE IF NOT EXISTS `listado_entrevistados_logo` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `logo_pie` text COLLATE utf8_unicode_ci COMMENT 'Pié de foto - mdcat270',
  `logo` text COLLATE utf8_unicode_ci COMMENT 'Imágen - mdcat269'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `listado_entrevistados_portal`
--

CREATE TABLE IF NOT EXISTS `listado_entrevistados_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `listado_entrevistados_logo` text COLLATE utf8_unicode_ci COMMENT 'Logotipo - mdcat275',
  `html` text COLLATE utf8_unicode_ci COMMENT 'Documento HTML - mdcat289',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `listado_proyectos`
--

CREATE TABLE IF NOT EXISTS `listado_proyectos` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `listado_proyectos_portal` text COLLATE utf8_unicode_ci COMMENT 'Proyectos - mdcat123',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Presentación - mdcat122',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat121'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `listado_proyectos`
--

INSERT INTO `listado_proyectos` (`id`, `id_matrix`, `lang`, `listado_proyectos_portal`, `presentacion`, `publicacion`) VALUES
(1, 14, 'lg-cat', '[]', '<p style="text-align: center;"><strong><img src="../../../../web/images/branguli/ANC1-42-N-35567.jpg" alt="" width="125" height="86" /></strong></p> <h2 style="text-align: left;"><strong>Catàleg de fons</strong></h2> <p style="text-align: left;">El Banc Audiovisual de Testimonis està format per 22 projectes de recerca d’història oral de procedència diversa.</p> <p>Totes aquestes investigacions van ser finançades pel Memorial Democràtic o l’antiga Direcció General de Memòria Democràtica entre els anys 2009 i 2010, i una part significativa de les entrevistes són inèdites.</p> <p>L’arxiu s’estructura per projectes que agrupen un nombre determinat de testimonis, amb un total de 403 entrevistes. A continuació podeu trobar la llista completa de projectes, al costat dels resums de totes les entrevistes vinculades als testimonis.</p> <p>Els continguts consultables en línia representen el 43,85% del total d’entrevistes que alberga el Banc, el qual fa públics els projectes a mesura que els va indexant.</p>', 'si'),
(2, 14, 'lg-spa', '[]', '<p><strong><img style="display: block; margin-left: auto; margin-right: auto;" src="../../../../web/images/branguli/ANC1-42-N-35567.jpg" alt="" width="125" height="86" /></strong></p> <h2 style="text-align: left;"><strong>Catálogo de fondo</strong></h2> <p>El Banco Audiovisual de Testimonios está formado por 22 proyectos de investigación de historia oral de procedencia diversa.</p> <p>Todas estas investigaciones fueron financiadas por el Memorial Democràtic o la antigua Dirección General de Memoria Democrática entre los años 2009 y 2010, y una parte significativa de las entrevistas son inéditas.</p> <p>El archivo se estructura por proyectos que agrupan un número determinado de testimonios, con un total de 403 entrevistas. A continuación figura la lista completa de proyectos, junto con los resúmenes de todas las entrevistas vinculadas a los testimonios.</p> <p>Los contenidos consultables en línea representan el 43,85 % del total de entrevistas que alberga el Banco, que hace públicos los proyectos conforme los va indexando.</p>', 'si'),
(3, 14, 'lg-eng', '[]', '<p><strong><img style="display: block; margin-left: auto; margin-right: auto;" src="../../../../web/images/branguli/ANC1-42-N-35567.jpg" alt="" width="125" height="86" /></strong></p> <h2 style="text-align: left;"><strong>Catalogue</strong></h2> <p>The Audiovisual Bank of Testimonies includes 22 oral history research projects of different origin.</p> <p>All of these projects were financed by Democratic Memory or the former General Directorate for Democratic Memory, between 2009 and 2010, and a large part of the interviews are unpublished.</p> <p>The archive is structured by project, each with a specific number of testimonies, and contains a total of 403 interviews. Following is a complete list of projects together with summaries of all of the testimony interviews.</p> <p>Currently 43.85% of the total number of interviews contained in the Bank can be consulted online. The Bank publishes the projects as and when they have been indexed.</p>', 'si'),
(4, 14, 'lg-fra', '[]', '<p style="text-align: center;"><strong><img src="../../../../web/images/branguli/ANC1-42-N-35567.jpg" alt="" width="125" height="86" /> </strong></p> <h2 style="text-align: left;">Catalogue de fonds</h2> <p>La Banque audiovisuelle de témoignages compte 22 projets de recherche d''histoire orale de diverses provenances.</p> <p>Toutes ces recherches ont été financées par le Mémorial Démocratique ou l''ancienne Direction générale de la Mémoire démocratique entre 2009 et 2010, une importante partie des entretiens est inédite.</p> <p>Le fichier est structuré selon des projets comportant un certain nombre de témoignages, et cumulant un total de 403 entretiens. Vous pouvez trouver ci-joint la liste complète des projets en compagnie du résumé de tous les entretiens associés aux témoignages.</p> <p>Les contenus consultables en ligne représentent 43,85 % du total des entretiens qu''héberge la Banque, qui elle-même rend publics les projets à mesure qu''elle les indexe.</p>', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `listado_proyectos_logo`
--

CREATE TABLE IF NOT EXISTS `listado_proyectos_logo` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `logo` text COLLATE utf8_unicode_ci COMMENT 'Imágen - mdcat269',
  `logo_pie` text COLLATE utf8_unicode_ci COMMENT 'Pié de foto - mdcat270'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `listado_proyectos_portal`
--

CREATE TABLE IF NOT EXISTS `listado_proyectos_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `html` text COLLATE utf8_unicode_ci COMMENT 'Documento HTML - mdcat289',
  `listado_proyectos_logo` text COLLATE utf8_unicode_ci COMMENT 'Logotipo - mdcat275',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `listado_resumen_entrevistas`
--

CREATE TABLE IF NOT EXISTS `listado_resumen_entrevistas` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Presentación - mdcat140',
  `listado_resumen_entrevistas_portal` text COLLATE utf8_unicode_ci COMMENT 'Entrevistas por entrevistado y proyecto - mdcat141',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat139'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `listado_resumen_entrevistas_logo`
--

CREATE TABLE IF NOT EXISTS `listado_resumen_entrevistas_logo` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `logo_pie` text COLLATE utf8_unicode_ci COMMENT 'Pié de foto - mdcat270',
  `logo` text COLLATE utf8_unicode_ci COMMENT 'Imágen - mdcat269'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `listado_resumen_entrevistas_portal`
--

CREATE TABLE IF NOT EXISTS `listado_resumen_entrevistas_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `html` text COLLATE utf8_unicode_ci COMMENT 'Documento HTML - mdcat289',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `listado_resumen_entrevistas_logo` text COLLATE utf8_unicode_ci COMMENT 'Logotipo - mdcat275',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `protocolos_investigacion`
--

CREATE TABLE IF NOT EXISTS `protocolos_investigacion` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Texto de introducción - mdcat158',
  `protocolos_investigacion_portal` text COLLATE utf8_unicode_ci COMMENT 'Protocolos de investigación - mdcat159',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat157'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `protocolos_investigacion`
--

INSERT INTO `protocolos_investigacion` (`id`, `id_matrix`, `lang`, `presentacion`, `protocolos_investigacion_portal`, `publicacion`) VALUES
(1, 17, 'lg-cat', '<p><img src="../../../../web/images/branguli/ANC1-722-N-184.jpg" alt="" width="97" height="66" /></p> <h2 style="text-align: left;"><strong>Protocols de recerca</strong></h2> <p>El Banc Audiovisual de Testimonis és un arxiu de fonts orals que des del 2009 ha estat promovent projectes de recerca amb testimonis. Tots els projectes que han rebut ajudes públiques han hagut de complir uns protocols de recerca bàsics; així mateix, s’han dut a terme jornades de formació per als investigadors que han treballat per al Banc.</p> <p>Anteriorment, l’any 2008 es va publicar el llibre <em>Eines per a treballs de memòria oral</em> com a manual bàsic per als projectes que volien investigar a partir de testimonis.</p> <p>A continuació trobareu tant els protocols com el manual en què s’han basat els diferents projectes de recerca. </p>', '["18","19"]', 'si'),
(2, 17, 'lg-spa', '<p><img src="../../../../web/images/branguli/ANC1-722-N-184.jpg" alt="" width="97" height="66" /></p> <h2 style="text-align: left;"><strong>Protocolos de investigación</strong></h2> <p>El Banco Audiovisual de Testimonios es un archivo de fuentes orales que desde el 2009 ha promovido proyectos de investigación con testimonios. Todos los proyectos que han recibido ayudas públicas han tenido que cumplir unos protocolos de investigación básicos; así mismo, se han llevado a cabo jornadas de formación para los investigadores que han trabajado para el Banco.</p> <p>Anteriormente, en el 2008 se publicó el libro <em>''Eines per a treballs de memòria oral''</em> como manual básico para los proyectos que querían investigar a partir de testimonios.</p> <p>A continuación figuran tanto los protocolos como el manual en que se han basado los diferentes proyectos de investigación.</p> <p> </p>', '["18","19"]', 'si'),
(3, 17, 'lg-eng', '<p><img src="../../../../web/images/branguli/ANC1-722-N-184.jpg" alt="" width="97" height="66" /></p> <h2 style="text-align: left;"><strong>Search protocols</strong></h2> <p>The Audiovisual Bank of Testimonies is an archive of oral testimonies that has been promoting research projects with testimonies since 2009. All of the projects that have been publically financed have had to meet basic research protocols, and training has been given to the researchers that have worked for the Bank.</p> <p>In 2008 the book ''Eines per a treballs de memòria oral'' (Tools for oral memory projects) was published as the basic manual for research projects based on testimonies.</p> <p>Here you can find the protocols and the manual on which the different research projects are based. </p> <p> </p>', '["18","19"]', 'si'),
(4, 17, 'lg-fra', '<p><img src="../../../../web/images/branguli/ANC1-722-N-184.jpg" alt="" width="97" height="66" /></p> <h2 style="text-align: left;"><strong>Protocoles de recherche</strong></h2> <p>La Banque audiovisuelle de témoignages est un fichier de sources orales qui a encouragé depuis 2009 des projets de recherche contenant des témoignages. Tous les projets ayant reçu des aides publiques ont dû se soumettre à des protocoles de recherche de base, en outre, des journées de formation pour les chercheurs ayant travaillé pour la Banque ont été organisées.</p> <p>Avant cela, a été publié en 2008 le livre <em>Eines per a treballs de memòria oral</em> (Outils pour des travaux de mémoire orale) servant de manuel de base destiné aux projets sur lesquels ils effectuaient leurs recherches à partir de témoignages.</p> <p>Vous trouverez ci-après les protocoles sous forme de manuel, sur lesquels s''appuient différents projets de recherche. </p> <p> </p>', '["18","19"]', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `protocolos_investigacion_portal`
--

CREATE TABLE IF NOT EXISTS `protocolos_investigacion_portal` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `weblink` text COLLATE utf8_unicode_ci COMMENT 'Enlace web - mdcat279',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `comentario` text COLLATE utf8_unicode_ci COMMENT 'Comentario - mdcat278',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `protocolos_investigacion_portal`
--

INSERT INTO `protocolos_investigacion_portal` (`id`, `id_matrix`, `lang`, `weblink`, `doc_pdf`, `titulo`, `comentario`, `version`, `fecha`, `publicacion`) VALUES
(1, 18, 'lg-cat', '', 'mdcat288-14', 'Protocols de recerca', '', '', 'Monday12-2014-06-23T00:00:00+02:00am30', 'si'),
(2, 18, 'lg-spa', '', 'mdcat288-19', 'Protocols de recerca', '', '', 'Monday12-00pam', 'si'),
(3, 18, 'lg-eng', '', 'mdcat288-19', 'Protocols de recerca', '', '', 'Monday12-Europe/Madrid612', 'si'),
(4, 18, 'lg-fra', '', 'mdcat288-19', 'Protocols de recerca', '', '', 'Monday12-fMon, 23 Jun 2014 00:00:00 +0200am', 'si'),
(5, 19, 'lg-cat', '', 'mdcat288-15', 'Eines de memòria oral', '', '', 'Monday12-2014-06-23T00:00:00+02:00am30', 'si'),
(6, 19, 'lg-spa', '', 'mdcat288-19', 'Eines de memòria oral', '', '', 'Monday12-00pam', 'si'),
(7, 19, 'lg-eng', '', 'mdcat288-19', 'Eines de memòria oral', '', '', 'Monday12-Europe/Madrid612', 'si'),
(8, 19, 'lg-fra', '', 'mdcat288-19', 'Eines de memòria oral', '', '', 'Monday12-fMon, 23 Jun 2014 00:00:00 +0200am', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `proyecto`
--

CREATE TABLE IF NOT EXISTS `proyecto` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Texto de presentación - mdcat17',
  `proyecto_fotografias` text COLLATE utf8_unicode_ci COMMENT 'Fotografías - mdcat18',
  `proyecto_video` text COLLATE utf8_unicode_ci COMMENT 'Vídeo presentación - mdcat19',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat15'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `proyecto`
--

INSERT INTO `proyecto` (`id`, `id_matrix`, `lang`, `presentacion`, `proyecto_fotografias`, `proyecto_video`, `publicacion`) VALUES
(1, 1, 'lg-cat', '<h2 style="text-align: left;"><strong>Presentació</strong></h2> <h2><strong><img src="../../../../web/images/branguli/ANC1-585-N-1602.jpg" alt="" width="124" height="85" /></strong></h2> <h3><strong>Què és el Banc Audiovisual de Testimonis?</strong></h3> <p>És l’arxiu d’història oral del Memorial Democràtic, que recull entrevistes sobre les temàtiques i el període de referència d’aquesta institució (1931-1980). Memòries polítiques, històries de vida, vivències personals i familiars sobre la Segona República, la Guerra Civil, la dictadura franquista, l’exili, la lluita per les llibertats democràtiques o la Transició espanyola, tenen cabuda en aquest arxiu.</p> <p>Aquest és un arxiu de memòria oral que recull la pluralitat de les memòries de la història recent de Catalunya i que fa un tractament innovador en la catalogació i la difusió de les entrevistes.</p> <h3><strong>La vocació del Banc Audiovisual de Testimonis</strong></h3> <p>Una de les seues voluntats és esdevenir un arxiu de fonts orals de referència, tant per a investigadors interessats en el segle xx com per a estudiants que treballen el passat recent o per a un públic general que busca conèixer la història.</p> <p>El Banc Audiovisual de Testimonis és un projecte viu, que continua potenciant la recerca en història oral i que segueix rebent entrevistes. Projectes d’investigació en fonts orals i persones que vulguin deixar el seu testimoni tenen en aquest arxiu un espai on dipositar les seues entrevistes.</p> <h3><strong>El Banc en xifres</strong></h3> <p>Al juny del 2014, el Banc Audiovisual de Testimonis conté 918 entrevistes provinents de 72 projectes de recerca en fonts orals, que sumen un total de 1121 hores d’enregistraments audiovisuals. Tan sols una part d’aquestes entrevistes i projectes són totalment consultables: 22 projectes que contenen 403 entrevistes. Estem treballant per posar els testimonis restants a disposició del públic i per incorporar noves entrevistes.</p> <h3><strong>Les entrevistes</strong></h3> <p>Els enregistraments provenen de projectes de recerca en fonts orals del Memorial Democràtic, de projectes subvencionats per l’antiga Direcció General de Memòria Democràtica i de donacions d’investigadors.</p> <p>Totes les entrevistes estan enregistrades en format audiovisual i estan íntegrament transcrites en l’idioma original del testimoni. Els subtítols a altres idiomes són automàtics i poden contenir errors.</p> <p>Per a la reutilització de les entrevistes en publicacions, documentals, televisió, exposicions, etcètera, vegeu l’apartat d’informació legal.</p> <h3><strong><img src="../../../../web/images/branguli/ANC1-555-N-1729.jpg" alt="" width="118" height="81" /></strong></h3> <h3><strong>Com funciona?</strong></h3> <p>La navegació a través dels continguts és senzilla i intuïtiva. Podeu fer-hi cerques a diferents nivells: per paraules, per significat, per context, pel temps històric o per l’espai geogràfic.</p> <p>Per conèixer la totalitat dels continguts accessibles del Banc Memorial, a l’apartat de documentació del web trobareu el catàleg de fons amb el llistat de projectes i d’entrevistats, així com el resum de cada entrevista.</p> <p>Si voleu conèixer més a fons el projecte (com s’ha creat el tesaurus, com s’ha concebut el projecte, quins articles científics sobre el Banc Audiovisual de Testimonis es poden llegir...), consulteu l’apartat de documentació.</p>', '[]', '[]', 'si'),
(2, 1, 'lg-spa', '<h2 style="text-align: left;">Presentación</h2> <h2><strong><img src="../../../../web/images/branguli/ANC1-585-N-1602.jpg" alt="" width="124" height="85" /></strong></h2> <h3>¿Qué es el Banco Audiovisual de Testimonios?</h3> <p>Es el archivo de historia oral del Memorial Democràtic, que recoge entrevistas sobre las temáticas y el periodo de referencia de esta institución (1931-1980). Memorias políticas, historias de vida, vivencias personales y familiares sobre la Segunda República, la Guerra Civil, la dictadura franquista, el exilio, la lucha por las libertades democráticas o la Transición española tienen cabida en este archivo.</p> <p>Este es un archivo de memoria oral que recoge la pluralidad de las memorias de la historia reciente de Cataluña y que hace un tratamiento innovador en la catalogación y la difusión de las entrevistas.</p> <h3>La vocación del Banco Audiovisual de Testimonios</h3> <p>Una de sus voluntades es convertirse en un archivo de fuentes orales de referencia, tanto para investigadores interesados en el siglo xx como para estudiantes que trabajan el pasado reciente o para un público general que busca conocer la historia.</p> <p>El Banco Audiovisual de Testimonios es un proyecto vivo, que continúa potenciando la investigación en historia oral y que sigue recibiendo entrevistas. Proyectos de investigación en fuentes orales y personas que quieran dejar su testimonio tienen en este archivo un espacio donde depositar sus entrevistas.</p> <h3>El Banco en cifras</h3> <p>En junio del 2014, el Banco Audiovisual de Testimonios contiene 918 entrevistas provenientes de 72 proyectos de investigación en fuentes orales, que suman un total de 1121 horas de grabaciones audiovisuales. Tan solo una parte de estas entrevistas y proyectos son totalmente consultables: 22 proyectos que contienen 403 entrevistas. Estamos trabajando para poner los testimonios restantes a disposición del público y para incorporar nuevas entrevistas.</p> <h3>Las entrevistas</h3> <p>Las grabaciones provienen de proyectos de investigación en fuentes orales del Memorial Democràtic, de proyectos subvencionados por la antigua Dirección General de Memoria Democrática y de donaciones de investigadores.</p> <p>Todas las entrevistas están grabadas en formato audiovisual y están íntegramente transcritas en el idioma original del testimonio. Los subtítulos a otros idiomas son automáticos y pueden contener errores.</p> <p>Para la reutilización de las entrevistas en publicaciones, documentales, televisión, exposiciones, etcétera, véase el apartado de información legal.</p> <h3><strong><img src="../../../../web/images/branguli/ANC1-555-N-1729.jpg" alt="" width="118" height="81" /></strong></h3> <h3>¿Cómo funciona?</h3> <p>La navegación a través de los contenidos es sencilla e intuitiva. Pueden hacerse búsquedas a diferentes niveles: por palabras, por significado, por contexto, por el tiempo histórico o por el espacio geográfico.</p> <p>Para conocer la totalidad de los contenidos accesibles del Banco Audiovisual de Testimonios, en el apartado de documentación de la web se encuentra el catálogo de fondo con la lista de proyectos y de entrevistados, así como el resumen de cada entrevista.</p> <p>Si se desea conocer más a fondo el proyecto (cómo se ha creado el tesauro, cómo se ha concebido el proyecto, qué artículos científicos sobre el Banco Audiovisual de Testimonis se pueden leer...), consúltese el apartado de documentación.</p> <p> </p>', '[]', '[]', 'si'),
(3, 1, 'lg-eng', '<h2 style="text-align: left;">Presentation</h2> <h2><strong><img src="../../../../web/images/branguli/ANC1-585-N-1602.jpg" alt="" width="124" height="85" /></strong></h2> <h3>What is the Audiovisual Bank of Testimonies?</h3> <p>It is an archive of oral history of the Memorial Democràtic (Democratic Memory of Catalonia), which includes interviews on the subjects and period of reference of this institution (1931-1980).Political memories, life stories, personal and family experiences of the Second Republic, the Civil War, Franco’s dictatorship, exile, the struggle for democratic freedom and the Spanish transition to democracy, all have a place in this archive.</p> <p>It is an oral memory archive which records the plurality of the memories of Catalonia’s recent history and which handles the cataloguing and dissemination of the interviews in an innovative way.</p> <h3>Audiovisual Bank of Testimonies’ vocation</h3> <p>One of its purposes is to become a benchmark archive of oral testimonies, for both researchers interested in the 20<sup>th</sup> century and students who are studying recent history as well as the general public interested in discovering history.</p> <p>The Audiovisual Bank of Testimonies is a living project that continues to expand research in oral history and to record interviews.Research projects on oral testimonies and people who wish to record their testimony have, thanks to this archive, a place where they can leave their interviews.</p> <h3>The Bank in numbers</h3> <p>By June 2014, the Audiovisual Bank of Testimonies included 918 interviews from 72 oral testimony research projects, which total 1,121 hours of audiovisual recordings.Only part of these interviews and projects can be consulted in their entirety:22 projects that contain 403 interviews.We are working to make the remaining testimonies available to the public and to add new interviews.</p> <h3>The interviews</h3> <p>The recordings are the result of oral testimony research projects of the Democratic Memory, of projects subsidised by the former General Directorate for Democratic Memory and of donations from researchers.</p> <p>All of the interviews are recorded in audiovisual format and are fully transcribed in the original language of the testimony.The subtitles in other languages are automatic and could contain mistakes.</p> <p>To reuse the interviews for publications, documentaries, television, exhibitions, etc, please refer to the legal information section.</p> <h3><strong><img src="../../../../web/images/branguli/ANC1-555-N-1729.jpg" alt="" width="118" height="81" /></strong></h3> <h3>How it works</h3> <p>Browsing through the contents is simple and intuitive.Searches can be made on different levels:by word, meaning, context, historical time or geographic area.</p> <p>To find out about all of the content accessible on the Audiovisual Bank of Testimonies, there is a catalogue in the website''s documentation section with a list of the projects and interviews, as well as a summary of each interview.</p> <p>If you wish to receive more in-depth information about the project (how the thesaurus was created, how the project came about, which scientific articles about the Audiovisual Bank of Testimonies can be read...), consult the documentation section.</p>', '[]', '[]', 'si'),
(4, 1, 'lg-fra', '<h2 class="ParaAttribute0" style="text-align: left;"><span class="CharAttribute1"><span lang="FR">Pr</span></span><span class="CharAttribute1"><span lang="FR">é</span></span><span class="CharAttribute1"><span lang="FR">sentation</span></span></h2> <h2><strong><img src="../../../../web/images/branguli/ANC1-585-N-1602.jpg" alt="" width="124" height="85" /></strong></h2> <h3 class="ParaAttribute0" align="left"><span class="CharAttribute1"><span lang="FR">Qu''est ce que la Banque Audiovisuel de T</span></span><span class="CharAttribute1"><span lang="FR">é</span></span><span class="CharAttribute1"><span lang="FR">moignages?</span></span></h3> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">Il s''agit de l</span></span><span class="CharAttribute2"><span lang="FR">’</span></span><span class="CharAttribute2"><span lang="FR">archive d</span></span><span class="CharAttribute2"><span lang="FR">’</span></span><span class="CharAttribute2"><span lang="FR">histoire orale du Memorial Democr</span></span><span class="CharAttribute2"><span lang="FR">à</span></span><span class="CharAttribute2"><span lang="FR">tic, il recueille les entretiens sur les th</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">matiques et le p</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">riode de r</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">f</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">rence de cette institution (1931-1980). M</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">moires politiques, histoires de vie, v</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">cus personnels et familiaux sous la Seconde R</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">publique, la Guerre Civile, la dictature franquiste, l</span></span><span class="CharAttribute2"><span lang="FR">’</span></span><span class="CharAttribute2"><span lang="FR">exil, la lutte pour les libert</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">s d</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">mocratiques ou la Transition espagnole,  toutes ces questions sont rassembl</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">es dans ce archive.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">Celui-ci est un fichier de m</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">moire orale qui recueille toute la diversit</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR"> des souvenirs de l''histoire r</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">cente de la Catalogne et qui proc</span></span><span class="CharAttribute2"><span lang="FR">è</span></span><span class="CharAttribute2"><span lang="FR">de </span></span><span class="CharAttribute2"><span lang="FR">à</span></span><span class="CharAttribute2"><span lang="FR"> un traitement innovant du classement et de la diffusion des entretiens.</span></span></p> <h3 class="ParaAttribute1"><span class="CharAttribute1"><span lang="FR">La vocation de la Banque Audiovisuel de T</span></span><span class="CharAttribute1"><span lang="FR">é</span></span><span class="CharAttribute1"><span lang="FR">moignages</span></span></h3> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">Une de ses vocations consiste </span></span><span class="CharAttribute2"><span lang="FR">à</span></span><span class="CharAttribute2"><span lang="FR"> devenir un fichier de donn</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">es orales de r</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">f</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">rence que ce soit pour les chercheurs int</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">ress</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">s par le XX</span></span><span class="CharAttribute2"><span lang="FR">è</span></span><span class="CharAttribute2"><span lang="FR">me si</span></span><span class="CharAttribute2"><span lang="FR">è</span></span><span class="CharAttribute2"><span lang="FR">cle,  pour les </span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">tudiants qui travaillent sur le pass</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR"> r</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">cent ou pour un public plus large qui cherche </span></span><span class="CharAttribute2"><span lang="FR">à</span></span><span class="CharAttribute2"><span lang="FR"> d</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">velopper ses connaissances historiques.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">La </span></span><span class="CharAttribute1"><span lang="FR">Banque Audiovisuel de T</span></span><span class="CharAttribute1"><span lang="FR">é</span></span><span class="CharAttribute1"><span lang="FR">moignages</span></span><span class="CharAttribute2"><span lang="FR"> est un projet vivant, elle vient consolider la recherche en histoire orale et elle continue </span></span><span class="CharAttribute2"><span lang="FR">à</span></span><span class="CharAttribute2"><span lang="FR"> recevoir des entretiens. Que ce soit dans le cadre de projets de recherche sur sources orales ou qu''il s''agisse de personnes souhaitant d</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">poser leur t</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">moignage, ce fichier est un espace o</span></span><span class="CharAttribute2"><span lang="FR">ù</span></span><span class="CharAttribute2"><span lang="FR"> il est possible de d</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">poser son entretien.</span></span></p> <h3 class="ParaAttribute1"><span class="CharAttribute1"><span lang="FR">La Banque en chiffres</span></span></h3> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">En juin 2014,  la </span></span><span class="CharAttribute1"><span lang="FR">Banque Audiovisuel de T</span></span><span class="CharAttribute1"><span lang="FR">é</span></span><span class="CharAttribute1"><span lang="FR">moignages</span></span><span class="CharAttribute2"><span lang="FR"> comptait 918 entretiens provenant de 72 projets de recherche sur sources orales, totalisant 1121 heures d</span></span><span class="CharAttribute2"><span lang="FR">’</span></span><span class="CharAttribute2"><span lang="FR">enregistrements audiovisuels. Seulement certains de ces entretiens et projets sont enti</span></span><span class="CharAttribute2"><span lang="FR">è</span></span><span class="CharAttribute2"><span lang="FR">rement consultables : 22 projets contenant 402 entretiens. Nous travaillons pour mettre les t</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">moignages restants </span></span><span class="CharAttribute2"><span lang="FR">à</span></span><span class="CharAttribute2"><span lang="FR"> la disposition du public et pour incorporer de nouveaux entretiens.</span></span></p> <h3 class="ParaAttribute1"><span class="CharAttribute1"><span lang="FR">Les entretiens</span></span></h3> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">Ce sont des enregistrements provenant de projets de recherche sur sources orales du Memorial Democr</span></span><span class="CharAttribute2"><span lang="FR">à</span></span><span class="CharAttribute2"><span lang="FR">tic, de projets subventionn</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">s par l''ancienne Direction G</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">n</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">rale de la M</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">moire D</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">mocratique et des legs de chercheurs.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">Tous les entretiens sont enregistr</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">s dans un format audiovisuel et sont int</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">gralement transcrits dans la langue originale du t</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">moignage. Les sous titres dans d''autres langues sont automatiques et peuvent contenir des erreurs.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">Afin de pouvoir utiliser les entretiens dans des publications, documentaires, </span></span><span class="CharAttribute2"><span lang="FR">à</span></span><span class="CharAttribute2"><span lang="FR"> la t</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">l</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">vision,  lors d''expositions,  etc., veuillez consulter le paragraphe sur les mentions l</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">gales.</span></span></p> <h3><strong><img src="../../../../web/images/branguli/ANC1-555-N-1729.jpg" alt="" width="118" height="81" /></strong></h3> <h3 class="ParaAttribute1"><span class="CharAttribute1"><span lang="FR">Comment fonctionne-t-elle?</span></span></h3> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">La navigation </span></span><span class="CharAttribute2"><span lang="FR">à</span></span><span class="CharAttribute2"><span lang="FR"> travers ses contenus est simple et intuitive. Vous pouvez effectuer des recherches sur diff</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">rents niveaux : par mot cl</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">,  par signification,  par contexte, en fonction de la p</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">riode historique ou de la zone g</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">ographique.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">Afin de d</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">couvrir la totalit</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR"> des contenus accessibles dans la </span></span><span class="CharAttribute1"><span lang="FR">Banque Audiovisuel de T</span></span><span class="CharAttribute1"><span lang="FR">é</span></span><span class="CharAttribute1"><span lang="FR">moignages</span></span><span class="CharAttribute2"><span lang="FR">,  vous trouverez dans la rubrique documentation du site Internet le catalogue des sources avec la liste des projets et entretiens, vous trouverez </span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">galement le r</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">sum</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR"> de chaque entretien.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute2"><span lang="FR">Si vous souhaitez conna</span></span><span class="CharAttribute2"><span lang="FR">î</span></span><span class="CharAttribute2"><span lang="FR">tre plus en d</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">tail le projet (comment le th</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">saurus a-t-il </span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">t</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR"> cr</span></span><span class="CharAttribute2"><span lang="FR">éé</span></span><span class="CharAttribute2"><span lang="FR">,  comment a </span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR">t</span></span><span class="CharAttribute2"><span lang="FR">é</span></span><span class="CharAttribute2"><span lang="FR"> con</span></span><span class="CharAttribute2"><span lang="FR">ç</span></span><span class="CharAttribute2"><span lang="FR">u le projet, quels articles scientifiques sur la </span></span><span class="CharAttribute1"><span lang="FR">Banque Audiovisuel de T</span></span><span class="CharAttribute1"><span lang="FR">é</span></span><span class="CharAttribute1"><span lang="FR">moignages</span></span><span class="CharAttribute2"><span lang="FR"> il est possible de lire...), veuillez consulter la rubrique documentation.</span></span></p> <p class="ParaAttribute1"> </p>', '[]', '[]', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `proyecto_fotografias`
--

CREATE TABLE IF NOT EXISTS `proyecto_fotografias` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `url` text COLLATE utf8_unicode_ci COMMENT 'Imágen - mdcat269',
  `pie` text COLLATE utf8_unicode_ci COMMENT 'Pié de foto - mdcat270'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `proyecto_video`
--

CREATE TABLE IF NOT EXISTS `proyecto_video` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `video` text COLLATE utf8_unicode_ci COMMENT 'Video de presentación - mdcat267',
  `subtitulacion` text COLLATE utf8_unicode_ci COMMENT 'Descripción / transcripción - mdcat268'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

-- --------------------------------------------------------

--
-- Table structure for table `tesauro_alfabetico`
--

CREATE TABLE IF NOT EXISTS `tesauro_alfabetico` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Presentación - mdcat104',
  `tesauro_alfabetico_documento` text COLLATE utf8_unicode_ci COMMENT 'Documento - mdcat105',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat103'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `tesauro_alfabetico`
--

INSERT INTO `tesauro_alfabetico` (`id`, `id_matrix`, `lang`, `presentacion`, `tesauro_alfabetico_documento`, `publicacion`) VALUES
(1, 10, 'lg-cat', '', '["11"]', 'si'),
(2, 10, 'lg-spa', '', '["11"]', 'si'),
(3, 10, 'lg-eng', '', '["11"]', 'si'),
(4, 10, 'lg-fra', '', '["11"]', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `tesauro_alfabetico_documento`
--

CREATE TABLE IF NOT EXISTS `tesauro_alfabetico_documento` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `tesauro_alfabetico_logo` text COLLATE utf8_unicode_ci COMMENT 'Logotipo - mdcat275',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `html` text COLLATE utf8_unicode_ci COMMENT 'Documento HTML - mdcat289',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `tesauro_alfabetico_documento`
--

INSERT INTO `tesauro_alfabetico_documento` (`id`, `id_matrix`, `lang`, `titulo`, `doc_pdf`, `tesauro_alfabetico_logo`, `fecha`, `html`, `version`, `publicacion`) VALUES
(1, 11, 'lg-cat', 'Tesaurus alfabètic', 'mdcat288-2', '["9"]', 'Thursday12-2014-07-31T00:00:00+02:00am31', 'mdcat289-1', 'Versió 3.0', 'si'),
(2, 11, 'lg-spa', 'Tesauro alfabético', 'mdcat288-11', '["9"]', 'Thursday12-00pam', 'mdcat289-2', 'Versió 3.0', 'si'),
(3, 11, 'lg-eng', 'Alphabetic thesaurus', 'mdcat288-12', '["9"]', 'Thursday12-Europe/Madrid712', 'mdcat289-3', 'Versió 3.0', 'si'),
(4, 11, 'lg-fra', 'Tesaurus alfabètic', 'mdcat288-10', '["9"]', 'Thursday12-fThu, 31 Jul 2014 00:00:00 +0200am', 'mdcat289-4', 'Versió 3.0', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `tesauro_alfabetico_logo`
--

CREATE TABLE IF NOT EXISTS `tesauro_alfabetico_logo` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `logo` text COLLATE utf8_unicode_ci COMMENT 'Imágen - mdcat269',
  `logo_pie` text COLLATE utf8_unicode_ci COMMENT 'Pié de foto - mdcat270'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `tesauro_alfabetico_logo`
--

INSERT INTO `tesauro_alfabetico_logo` (`id`, `id_matrix`, `lang`, `logo`, `logo_pie`) VALUES
(1, 9, 'lg-cat', 'mdcat269-1', ''),
(2, 9, 'lg-spa', 'mdcat269-1', ''),
(3, 9, 'lg-eng', 'mdcat269-1', ''),
(4, 9, 'lg-fra', 'mdcat269-1', '');

-- --------------------------------------------------------

--
-- Table structure for table `tesauro_jerarquico`
--

CREATE TABLE IF NOT EXISTS `tesauro_jerarquico` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion` text COLLATE utf8_unicode_ci COMMENT 'Presentación - mdcat113',
  `tesauro_jerarquico_documento` text COLLATE utf8_unicode_ci COMMENT 'Documento - mdcat114',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat112'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `tesauro_jerarquico`
--

INSERT INTO `tesauro_jerarquico` (`id`, `id_matrix`, `lang`, `presentacion`, `tesauro_jerarquico_documento`, `publicacion`) VALUES
(1, 12, 'lg-cat', '', '["13"]', 'si'),
(2, 12, 'lg-spa', '', '["13"]', 'si'),
(3, 12, 'lg-eng', '', '["13"]', 'si'),
(4, 12, 'lg-fra', '', '["13"]', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `tesauro_jerarquico_documento`
--

CREATE TABLE IF NOT EXISTS `tesauro_jerarquico_documento` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `tesauro_jerarquico_logo` text COLLATE utf8_unicode_ci COMMENT 'Logotipo - mdcat275',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `html` text COLLATE utf8_unicode_ci COMMENT 'Documento HTML - mdcat289',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `tesauro_jerarquico_documento`
--

INSERT INTO `tesauro_jerarquico_documento` (`id`, `id_matrix`, `lang`, `tesauro_jerarquico_logo`, `version`, `titulo`, `doc_pdf`, `html`, `fecha`, `publicacion`) VALUES
(1, 13, 'lg-cat', '["9"]', 'Versió 3.0', 'Tesaurus jeràrquic', 'mdcat288-3', 'mdcat289-5', 'Thursday12-2014-07-31T00:00:00+02:00am31', 'no'),
(2, 13, 'lg-spa', '["9"]', 'Versió 3.0', 'Tesauro jerárquico', 'mdcat288-4', 'mdcat289-6', 'Thursday12-00pam', 'no'),
(3, 13, 'lg-eng', '["9"]', 'Versió 3.0', 'Hierarchical thesaurus', 'mdcat288-5', 'mdcat289-7', 'Thursday12-Europe/Madrid712', 'no'),
(4, 13, 'lg-fra', '["9"]', 'Versió 3.0', 'Tesaurus jeràrquic', 'mdcat288-6', 'mdcat289-8', 'Thursday12-fThu, 31 Jul 2014 00:00:00 +0200am', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `tesauro_jerarquico_logo`
--

CREATE TABLE IF NOT EXISTS `tesauro_jerarquico_logo` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `logo_pie` text COLLATE utf8_unicode_ci COMMENT 'Pié de foto - mdcat270',
  `logo` text COLLATE utf8_unicode_ci COMMENT 'Imágen - mdcat269'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `tesauro_jerarquico_logo`
--

INSERT INTO `tesauro_jerarquico_logo` (`id`, `id_matrix`, `lang`, `logo_pie`, `logo`) VALUES
(1, 9, 'lg-cat', '', 'mdcat269-1'),
(2, 9, 'lg-spa', '', 'mdcat269-1'),
(3, 9, 'lg-eng', '', 'mdcat269-1'),
(4, 9, 'lg-fra', '', 'mdcat269-1');

-- --------------------------------------------------------

--
-- Table structure for table `tesauro_presentacion`
--

CREATE TABLE IF NOT EXISTS `tesauro_presentacion` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `documento_completo` text COLLATE utf8_unicode_ci COMMENT 'Teasuro Completo - mdcat93',
  `tesauro_presentacion_documento` text COLLATE utf8_unicode_ci COMMENT 'Documento - mdcat96',
  `presentacion_pdf` text COLLATE utf8_unicode_ci COMMENT 'Presentación para PDF - mdcat95',
  `presentacion_general` text COLLATE utf8_unicode_ci COMMENT 'Presentación para la web - mdcat94',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat91'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `tesauro_presentacion`
--

INSERT INTO `tesauro_presentacion` (`id`, `id_matrix`, `lang`, `documento_completo`, `tesauro_presentacion_documento`, `presentacion_pdf`, `presentacion_general`, `publicacion`) VALUES
(1, 7, 'lg-cat', 'mdcat93-1', '["8"]', '<h2 style="text-align: center;"><strong>TESAURUS DEL MEMORIAL DEMOCRÀTIC</strong></h2> <p style="text-align: center;"> </p> <p style="text-align: left;"><strong>Origen:</strong></p> <p>El Tesaurus del Memorial Democràtic és un vocabulari controlat sobre història contemporània de Catalunya, fet a mida per al projecte del Banc Memorial, l’arxiu de testimonis d’aquesta institució.</p> <p>Per a la seua creació, es va prendre com a punt de partida el <a href="http://www.vocabularyserver.com/historia_catalunya/">Tesaurus d’Història de Catalunya</a> del Servei d’Informació Bibliogràfica i de Documentació d’Història, Llengua, Literatura i Art de Catalunya de la Universitat Autònoma de Barcelona (<a href="http://sct.uab.cat/sibhilla/">SIBHIL·LA</a>-UAB).</p> <p>La decisió de crear un tesaurus específic parteix de la constatació de la inexistència de llenguatges documentals adients per al marc històric del qual s’ocupa el Memorial Democràtic.</p> <p>El 2009 es signa un conveni de col·laboració entre la UAB i el Memorial Democràtic, que té com a objectiu l’adaptació del Tesaurus d’Història de Catalunya de la UAB a les necessitats del Banc Memorial. Així, s’adapta aquest a un tesaurus específic sobre història contemporània per al període de referència del Memorial Democràtic: de la proclamació de la Segona República (14 d’abril de 1931) a les primeres eleccions al Parlament de Catalunya després de la dictadura de Franco (20 de març de 1980).</p> <p><strong>Creació del tesaurus:</strong></p> <p>A partir de l’estructura d’un tesaurus preexistent, el procés de construcció del nou es va iniciar amb l’elaboració d’una cronologia del període, la creació d’un compendi de vocabulari i de termes, la selecció i normalització dels descriptors i l’establiment de les relacions d’equivalència, jerarquia i associació entre descriptors.</p> <p>El primer pas fou la recopilació dels fets històrics més rellevants, a través de la consulta de bibliografia especialitzada. En segon lloc, a partir d’un mostreig de 67 entrevistes, es recolliren un total de 758 conceptes. Aquests, juntament, amb un primer estudi de les fonts terminològiques més característiques de la disciplina, permeteren establir una primera gran estructura amb les possibles àrees de coneixement o micro-disciplines. A partir d’aquí, es va establir un llistat de “descriptors candidats” i mitjançant un mètode deductiu es reagruparen els descriptors en funció de la seva temàtica.</p> <p>En una segona fase es va normalitzar el vocabulari recollit i es va concretar en un llenguatge documental. S’examinà cadascuna de les micro-disciplines amb la finalitat de seleccionar i normalitzar els descriptors. Aquest procés suposà una primera tria entre descriptors i no-descriptors i, per tant, l’elaboració d’una primera estructura d’equivalència semàntica entre sinònims. Una vegada seleccionats i normalitzats els termes descriptors s’elaborà una estructura jeràrquica dins de cadascuna de les micro-disciplines. La creació de cadenes jeràrquiques permeté detectar i eliminar els dobles usos de descriptors i trobar possibles llacunes que s’ompliren afegint els conceptes que faltaven per mantenir la coherència. Finalment, s’examinà cadascun dels descriptors del tesaurus per poder establir les seves relacions associatives amb d’altres descriptors ubicats en altres àrees de coneixement.</p> <p>A març de 2010, es disposà d’una primera versió del tesaurus, concebuda com a estructura base vàlida, que hauria de ser obligatòriament transformada a partir de la inducció de nous termes en el procés d’indexació, i de les revisions a nivell de coherència. I efectivament, dels inicials 2.315 termes, aquests s’han multiplicat per 5 fins al 2014.</p> <p>Al llarg de l’any 2010, s’introduí aquesta primera versió a la plataforma <a href="http://www.fmomo.org/dedalo">Dédalo</a> que gestiona el Banc Memorial, i s’inicià el procés d’indexació de les primeres 109 entrevistes. Aquest procés anà acompanyat de la revisió del tesaurus i la creació de nous termes deduïts, valent-nos de l’estructura bàsica creada. L’ampliació d’algunes micro-disciplines, a partir d’obres de referència, la deducció de termes i l’ampliació de determinades branques del tesaurus, com ara els de centres de privació de llibertat de la Guerra Civil, la repressió franquista i la Segona Guerra Mundial, comportaren un augment exponencial del nombre de termes. I a partir de la necessitat de situar poblacions que es deduïen dels relats orals, s’optà per la inclusió de nomenclàtors de diversos països, els descriptors toponímics, que ens permeteren situar poblacions o territoris. Aquesta última decisió comportà la revisió estructural del tesaurus en 4 micro-disciplines, que és la que es manté en el tesaurus actual (2014). Així, a finals de 2010 disposàvem d’una segona versió del tesaurus amb una gran ampliació de  termes i un canvi estructural.</p> <p>L’any 2012 es reprengué el projecte, començant per l’ampliació de l’apartat de personatges públics a partir de bibliografia especialitzada, sense indexar nous continguts.</p> <p>Els anys 2013 i 2014 es reprengueren les tasques d’indexació, fet que comportà altre cop la revisió del tesaurus i la proposició de nous termes induïts. Durant aquest període es procedí a una revisió integral de la coherència del tesaurus, donat que l’estructuració feta el 2010 en la segona versió del tesaurus, havia deixat sense resoldre aspectes de coherència, que provenien de l’estructura de la primera versió. Aquesta revisió íntegra es realitzà a partir de la indexació de nous continguts, que elevaren el nombre d’entrevistes finalitzades a 377.</p> <p>És important destacar que amb aquesta darrera revisió, s’eliminaren termes que no tenien en compte la possibilitat de realitzar cerques combinades per part dels usuaris, tot implementant com a pràctica per a la indexació l’ús de paraules claus combinades (així per exemple, s’eliminaren paraules clau com “Oci i lleure en temps de la República” per indexar amb “Oci i lleure” i “Segona República espanyola”). Aquesta revisió suposà tornar a indexar tots aquells fragments d’entrevistes dels termes que s’eliminaren, estimulant així l’ús de cerques combinades per part dels usuaris.</p> <p>A maig de 2014, la tercera versió del tesaurus compta amb 77.982 termes, dels quals 11.745 són descriptors no toponímics (el projecte té carregats el nomenclàtor oficial de 6 països dels quals es parla en les entrevistes, de manera que el nombre total de topònims és molt elevat tot i utilitzar una ínfima part d’aquests descriptors). Així, el nucli del tesaurus són els descriptors cronològics, temàtics i onomàstics, que representen un nombre considerable de paraules clau a utilitzar. Aquesta versió, sense els descriptors toponímics (els nomenclàtors) es pot descarregar íntegrament, o parcialment en les seues versions alfabètiques i jeràrquiques.</p> <p> El tesaurus segueix viu, es manté i es revisa regularment en cada indexació de projectes. Amb aquest vocabulari controlat s’han creat a maig de 2014, un total de 7.594 fragments d’entrevistes, als quals s’han assignat 19.636 termes. Aquestes dades ens permeten veure també el grau de catalogació detallada, ja que es dóna una mitja de 2,5 termes utilitzats per fragment, fet que ens permet deduir que la cerca combinada a partir de termes del tesaurus, donarà resultats molt precisos a les cerques que realitzin els usuaris.</p> <p><strong>L’estructuració del tesaurus:</strong></p> <p>El tesaurus s’estructura en 4 grans àrees o micro-disciplines, que donen resposta a 4 preguntes: quan (descriptors cronològics), què (descriptors temàtics), qui (descriptors onomàstics) i on (descriptors toponímics).</p> <p>Els descriptors cronològics tenen un límit establert per la pròpia llei del Memorial Democràtic (14/04/1931-20/03/1980). Aquest límit cronològic, queda sobrepassat en algunes ocasions donat que el relat dels testimonis el supera. És per això que ens trobem amb termes fora d’aquest marc (com per exemple: “Dictadura de Primo de Rivera” o “Cop d’estat de Tejero”). En aquesta primera micro-disciplina hem agrupat els períodes històrics, i hem creat dos agrupacions cronològiques diferenciades d’aquests períodes per raons de coherència: hem creat una agrupació amb el nom de “Fets internacionals” per a aquells que han pogut tenir relació amb els relats dels testimonis, però que no s’ubiquen geogràficament a Catalunya o a Espanya (p.e. Concili Vaticà II), i hem agrupat dins el terme “Exili 1939” tots aquells termes que semànticament hi guarden relació però que també per raons geogràfiques queden fora dels grans períodes històrics. L’ordenació dels descriptors cronològics, en la visualització jeràrquica, correspon a la cronologia i no a un ordre alfabètic.</p> <p>Els descriptors temàtics mantenen una estructura idèntica a la del Tesaurus d’Història de Catalunya de la UAB, i s’hi ha inclòs una nova agrupació amb el nom de “Guerra i conseqüències de la guerra”, donada l’especificitat de moltes entrevistes, que són memòries vinculades a un fet bèl·lic, però que no poden ubicar-se en els descriptors cronològics, i al mateix temps s’ha desvinculat de l’agrupació semàntica “Defensa i ordre públic”, junt als termes dependents del concepte “Guerra”.</p> <p>Els descriptors onomàstics són una micro-disciplina nova i diferenciada del tesaurus mare, el de la UAB, que va decidir crear-se donat que les entrevistes contenen moltes referències a personatges públics, i sobretot, són memòries que guarden relació amb llocs de memòria, especialment centres de privació de llibertat.</p> <p>Finalment, els descriptors toponímics es van incloure també en el tesaurus, conscients del volum que suposava la introducció de nomenclàtors de països, però valorant que moltes de les memòries dels entrevistats s’ubicaven en un espai geogràfic que podia ser d’interès pels usuaris en la recuperació d’informació, com les poblacions d’acollida dels exiliats.</p> <p><strong>Equip humà:</strong></p> <p>El Tesaurus del Memorial Democràtic parteix del Tesaurus d’Història de Catalunya de la UAB. Aquesta base i la primera adaptació (2009-2010) són obra d’Anna Pascual Bosser, que fou dirigida per Maribel Cuadrado i Núria Rius (<a href="http://sct.uab.cat/sibhilla/">SIBHIL·LA</a>-UAB).</p> <p>L’ampliació dels personatges públics de l’any 2012 és obra de Laura Molinos. La revisió íntegra del thesaurus que es dugué a terme durant el període 2013-2014, a partir de la indexació de nous continguts ha estat realitzada per Anna Pascual Bosser i Joan Palahí.</p> <p>La coordinació i la revisió és obra de Gerard Corbella, responsable del Banc Memorial. En la revisió dels termes històrics hi ha participat puntualment tant historiadors del Memorial Democràtic com de la UAB.</p> <p><strong> </strong></p> <p><strong>Norma ISO i tesaurus multilingüe:</strong></p> <p>Des de la primera a la darrera versió del tesaurus s’ha tingut en compte la norma ISO 2788:1986 (UNE 50-106-90), per a la creació de thesaurus monolingües. Donat que el projecte està plantejat per a ser visualitzat en 4 idiomes, la plataforma <a href="http://www.fmomo.org/dedalo">Dédalo</a> ha tingut en compte la norma ISO 5964 (UNE 50-125), per als tesaurus multilingües.</p> <p>Respecte a l’ús del llenguatge natural, en els tesaurus d’història consultats, constatem que aquest no s’utilitza en el cas dels números ordinals, per tal de facilitar la recuperació d’informació. Donada la utilització d’una base de dades (<a href="http://www.fmomo.org/dedalo">Dédalo</a>) per a la creació i gestió del tesaurus, hem optat per la utilització del llenguatge natural donat que podem recuperar la informació (p.e. no usem República II com fan els altres tesaurus, sinó el natural Segona República).</p> <p>En l’apartat de la bibliografia, es donen compte de les obres utilitzades, tant pel que fa a normativa tècnica, com obres de referència i de consulta.</p> <p>A partir de la creació d’una tercera versió definitiva del tesaurus, en una única llengua, hem optat per la traducció íntegra del mateix a 4 idiomes (del català cap al castellà, francès i anglès). El tesaurus en els diferents idiomes té exactament els mateixos termes que en l’original, i es presenta tant alfabèticament com jeràrquica. La traducció ha estat realitzada per professionals acreditats, dins de la base de dades. La única diferència amb l’original és que no s’han traduït les notes d’abast dels termes.</p> <p>Tant la navegació a través de la web, com les presentacions del tesaurus en text, es fan sempre a partir de l’idioma de consulta de l’usuari.</p> <p><strong>Gestió tecnològica:</strong></p> <p>El tesaurus es gestiona amb <a href="http://www.fmomo.org/dedalo">Dédalo</a>, la plataforma que ens permet fer la gestió íntegra del Banc Memorial (des de la ingesta dels vídeos a la indexació de continguts). La creació de termes en la base de dades ens permet establir les relacions jeràrquiques i semàntiques de termes, introduir les notes d’abast, restringir l’ús dels termes per a la indexació, controlar i guiar la polisèmia i la sinonímia, generar espais semàntics sobre conjunts de models, modificar dependències jeràrquiques i semàntiques, així com modificar l’ortografia, sense perdre el treball d''indexació ja realitzat, i traduir els termes a les llengües del projecte.</p> <p>La indexació dels continguts es fa mitjançant el tesaurus i a partir de les transcripcions de les entrevistes. Donat que aquestes transcripcions estan relacionades mitjançant codis de temps als vídeos dels testimonis, en la recuperació de la informació, les indexacions coincideixen tant amb els fragments de text com els de vídeo.</p> <p>De les transcripcions de les entrevistes en la llengua original (català o castellà), se’n generen traduccions automàtiques, que si bé contenen errors, permeten als usuaris d’altres llengües d’entendre el contingut de les entrevistes. Les entrevistes traduïdes no es reindexen a partir del tesaurus traduït, sinó que les marques d’indexació de l’idioma original es propaguen en les transcripcions en els altres idiomes, inserint-hi els termes ja traduïts en el tesaurus de la llengua de destinació. Aquests avenços tecnològics ens han permès de comptar amb un tesaurus multilingüe i amb idèntiques indexacions en els 4 idiomes, permetent cerques semàntiques igual de precises sigui quin sigui l’idioma de consulta de l’usuari.</p> <p><strong> </strong></p> <p><strong>Publicació i visualització:</strong></p> <p>Aquest tesaurus no s’ha publicat en paper, però es posa a disposició dels usuaris que se’l poden descarregar, íntegre o en les versions alfabètica i jeràrquica per separat. A part de la versió digital estàtica (una versió determinada), existeix la possibilitat de veure el tesaurus en la seua visualització jeràrquica dinàmica (podent desplegar les jerarquies), en el primer cas en l’apartat documentació, i en el segon en l’apartat de cerca de la web del Banc Memorial.</p> <p>Existeix però una altra forma de visualització del tesaurus, lligada amb els continguts, i que és aquella que ens permet fer cerques semàntiques dins de la web. Es tracta d’una presentació jeràrquica, on només són visibles els 1.674 termes assignats del tesaurus, junt als termes genèrics als quals està adscrit el descriptor.</p> <p> </p> <h2 style="text-align: center;"><strong><br /> </strong></h2> <p><strong> </strong></p> <p><strong>Bibliografia utilitzada:</strong></p> <p><strong>Tesaurus:</strong></p> <p>AITCHISON, Jean: <em>Tesauro de la Unesco: lista estructurada de descriptores para la indización y la recuperación bibliográficas en las esferas de la educación, la ciencia, las ciencias sociales, la cultura y la comunicación</em>, París: UNESCO, 1984</p> <p>CUADRADO, M.; GARCÍA, C.; PERPINYÀ, M. et al. <em>Tesaurus d’Història de Catalunya. Edició 0. Presentació jeràrquica i alfabètica.</em> Bellaterra : Servei de Documentació d’Història Local de Catalunya, 1999</p> <p>RUBIO LINIERS, María Cruz: <em>Tesauro de Historia Contemporánea de España</em>, Madrid:  Centro de Información y Documentación Científica-Centro Superior de Investigaciones Científicas, 1999</p> <p>VIET, Jean<em>: POPIN Thesaurus: Population Multilingual Thesaurus</em>, Paris: Population Information Network (POPIN); Comité International de Coopération dans les Recherches Nationales en Démographie (CICRED); United Nations Population Fund (UNFPA), 1993.</p> <p><strong> </strong></p> <p><strong>Normativa técnica:</strong></p> <p>UNE 50-106 (ISO 2788-1986) <em>Documentación: Directrices para el establecimiento y desarrollo de tesauros monolingües</em>, Madrid: Asociación Española de Normalización y Certificación</p> <p>(AENOR), 1990.</p> <p>UNE-50-125 (ISO 5964-1985). <em>Documentación: Directrices para la creación y desarrollo</em></p> <p><em>de tesaurus multilingües</em>. Asociación Española de Normalización y Certificación (AENOR), 1997</p> <p><strong> </strong></p> <p><strong>Obra científica:</strong></p> <p>GIL LEIVA, I.: <em>Manual de indización: teoría y práctica</em>. Gijón: Trea, 2008.</p> <p>LANCASTER, F.W.: <em>El control del vocabulario en la recuperación de la información</em>, Universitat de València, 1995.</p> <p>LANCASTER, F. W.: <em>Indexing and abstracting in theory and practice</em>, Facet Publishing, 2003</p> <p>SLYPE, G. Van: <em>Los lenguajes de indización. Concepción, construcción y utilización en los sistemas documentales</em>. Madrid: Pirámide / Fundación Sánchez Ruipérez (“Biblioteca del Libro”), 1991.</p> <p><strong> </strong></p> <p><strong>Obres de referència:</strong></p> <p>ARTAL, Francesc, GABRIEL, Pere i LLUCH, Ernest [et al.] (ed.), <em>Ictíneu</em>, <em>Diccionari de les Ciències de la Societat als Països Catalans: segles XVIII-XX</em>, Barcelona, Edicions 62, 1979.</p> <p>BARDAVÍO, Joaquín, <em>Todo Franco: franquismo y antifranquismo de la A a la Z, </em>Barcelona, Plaza &amp; Janés, 2001.</p> <p>CENTRE D’ESTUDIS SOBRE LES ÈPOQUES FRANQUISTA I DEMOCRÀTICA (CEFID), <em>Catalunya durant el franquisme: diccionari</em>, Vic, Eumo, 2006, Referències, 46.</p> <p>CENTRE D’ESTUDIS HISTÒRICS INTERNACIONALS, <em>Premsa clandestina i de l’exili (1939-1976): inventari de la Col·lecció de C.E.H.I.</em>, Barcelona, Universitat de Barcelona, 1977.</p> <p>CREXELL, Joan, <em>Premsa catalana clandestina 1970-1977</em>, Barcelona, Edicions Crit, 1977, Crit, 2.</p> <p>CULLA, Joan B., <em>La premsa republicana</em>, Barcelona, Col·legi de Periodistes de Catalunya, DL, 1990, Vaixells de paper, 8.</p> <p>FERNÁNDEZ PÉREZ, Adolfo (coord.), <em>Antifranquismo y prensa,</em> Oviedo, Fundación José José Barreiro, DL, 2005.</p> <p>GODICHEAU, François, <em>La Guerra Civil en 250 términos</em>, Madrid, Historia Alianza Editorial, 2005.</p> <p>LAVIANA, Juan Carlos, <em>1939-1976: los protagonistas y los hechos</em>, Madrid, Unidad Editorial, 2006.</p> <p>LLORENS SALA, Teresa, <em>Premsa clandestina i de l’exili a l’Hemeroteca de l’Arxiu Històric de la Ciutat: 1939-1977</em>, Barcelona, Ajuntament de Barcelona. Arxiu Municipal de Barcelona, DL, 2000.</p> <p>MADRIDEJOS, Mateo, <em>Diccionario onomástico de la guerra civil</em>, Barcelona, Flor de Viento, 2006.</p> <p>MARTÍNEZ, María Teresa i PAGÈS, Pelai (coord.),<em> Diccionari biogràfic del moviment obrer als Països Catalans</em>, Barcelona, Publicacions de la Universitat de Barcelona/Publicacions de l’Abadia de Montserrat, 2000.</p> <p>MESTRE, Jesús (dir.), <em>Diccionari d’Història de Catalunya</em>, Barcelona, Edicions 62, 1992.</p> <p>MOLAS, I. (ed.), <em>Diccionari dels partits polítics de Catalunya</em>, Barcelona, Enciclopèdia Catalana, 2000.</p> <p>SOLÉ I SABATÉ, Josep Maria i VILARROYA, Joan, <em>Cronologia de la repressió de la llengua i la cultura catalanes: 1936-1975</em>, Barcelona, Curial, 1994.</p> <p> </p> <p><strong>Obres de caràcter general. Història de Catalunya</strong></p> <p>BALCELLS, Albert (dir.), <em>Història de Catalunya</em>, Barcelona, L’Esfera dels llibres, 2004.</p> <p>- <em>El franquisme a Catalunya (1939-1977),</em> Barcelona, Edicions 62, 2006.</p> <p>- <em>Història política, societat i cultura dels Països Catalans</em>, Barcelona, Enciclopèdia Catalana, 1995.</p> <p>RIQUER, Borja de (dir.), <em>Cronologia dels Països Catalans: història, societat, economia, cultura, ciencia</em>, Barcelona, Pòrtic, 1999, Biblioteca universitària, 40.</p> <p>RISQUES, Manel (dir.), <em>Historia de la Catalunya contemporània: de la Guerra del Francès al nou Estatut</em>, Barcelona, Pòrtic, 1999, Biblioteca universitària (Enciclopedia Catalana), 39.</p> <p>SOBREQUÉS I CALLICÓ, Jaume (ed.), <em>Història contemporània de Catalunya</em>, Barcelona, Columna, 1997-1998, Columna assaig, 8-9.</p> <p>VILAR, Pierre (dir.), <em>Història de Catalunya</em>, Barcelona, Edicions 62, 1990.</p> <p><strong> </strong></p> <p><strong>Obres de caràcter general. Història d’Espanya</strong></p> <p>CASANOVA, Julián, <em>República y guerra civil</em>, Volum 8 de la col·lecció de FONTANA, Josep i VILLARES, Ramón (dir.), <em>Historia de España</em>, Sabadell, Crítica/Marcial Pons, 2007.</p> <p> </p> <p><strong>Bibliografia específica:</strong></p> <p>Segona República</p> <p>CUCURULL, F., <em>Catalunya republicana i autònoma</em>, 1936-1939, Madrid, Nossa y Jara, 1996.</p> <p>RISQUES, Manel (coord.), <em>Visca la República!</em>, Barcelona, Proa, 2007.</p> <p>SOLÉ I SABATÉ, Josep Maria i VILARROYA, Joan, <em>Els Anys de la Segona República (1931-1936)</em>, Barcelona, Edicions 62/La Vanguardia, 2006.</p> <p> </p> <p>Guerra civil</p> <p>BADIA, Francesc, <em>Els camps de treball a Catalunya durant la Guerra Civil</em>, Barcelona, Publicacions de l’Abadia de Montserrat, 2001.</p> <p>CARDONA, Joan,<em> Un fusell i un biberó. A la guerra amb 17 anys</em>, Valls, Cossetània, 2003.</p> <p>GALLEGO, Ferran, <em>Barcelona, mayo de 1937: la crisis del antifascismo en Cataluña,</em> Barcelona, Debate, 2007.</p> <p>PAGÈS, Pelai, <em>La presó Model de Barcelona. Història d’un centre penitenciari en temps de guerra (1936-1939)</em>, Barcelona, Publicacions de l’Abadia de Montserrat, 1996.</p> <p>SOLÉ I SABATÉ, Josep Maria i VILARROYA, Joan, <em>Catalunya sota les bombes: 1936-1939</em>, Barcelona, Publicacions de l’Abadia de Montserrat, 1986.</p> <p>- <em>La Repressió a la rereguarda de Catalunya: 1936-1939</em>, Barcelona, Publicacions de l’Abadia de Montserrat, 1989-1990.</p> <p>VOLTAS, Eduard (dir.), <em>La Guerra civil a Catalunya (1936-1939)</em>, Barcelona, Edicions 62, 2004-2005.</p> <p> </p> <p>Franquisme</p> <p>CALVET BELLERA, J i altres, Xarxes d’informació i d’evasió aliades al Pallars Sobirà, a l’Alt Urgell i a Andorra durant la Segona Guerra Mundial, Garsineu edicions 2011.</p> <p>CASANOVA, Julián (coord.), <em>Morir, matar, sobrevivir: la violencia en la dictadura de Franco</em>, Barcelona, Crítica, 2002.</p> <p>CULLA, Joan B. i RIQUER, Borja de, <em>El franquisme i la transició democràtica: 1939-1988</em>, Barcelona, Edicions 62, 1989, Història de Catalunya, 7.</p> <p>FONT AGULLÓ, Jordi, <em>Història i memòria: el franquisme i els seus efectes als Països Catalans</em>, València, Universitat de València, 2007.</p> <p>GRACIA, Jordi i RUIZ-CARNICER, Miguel Ángel, <em>La España de Franco: 1939-1975: cultura y vida cotidiana</em>, Madrid, Síntesis, 2001.</p> <p>MARÍN i CORBERA, Martí, <em>Història del franquisme a Catalunya</em>, Lleida, Pagès, Vic, Eumo, 2006, Biblioteca d’història de Catalunya, 9.</p> <p>MIR i CURCÓ, Conxita,<em> Vivir es sobrevivir: justicia, orden y marginación en la Cataluña rural de posguerra</em>, Lleida, Milenio, 2000.</p> <p>MOLINERO, Carme, SALA, M. i SOBREQUÉS, J. (eds.), <em>Una inmensa prisión: los campos de concentración y las prisiones durante la guerra civil y el franquismo</em>, Barcelona, Crítica, 2003.</p> <p>MOLINERO, Carme i YSÀS, Pere, <em>El règim franquista. Feixisme, modernització i consens</em>, Vic (Barcelona), Eumo, 1992.</p> <p>- <em>Catalunya durant el franquisme</em>, Barcelona, Empúries, 1999, Història de Catalunya, 3.</p> <p>RODRIGO, Javier, <em>Cautivos: campos de concentración en la España franquista, 1936-1947</em>, Barcelona, Crítica, 2005.</p> <p>ROIG, Montserrat, <em>Els catalans als camps nazis</em>, Barcelona, Edicions 62, 1977.</p> <p>SOLÉ i SABATÉ, Josep Maria, <em>La repressió franquista a Catalunya 1938-1953</em>, Barcelona, Edicions 62, 1985.</p> <p> </p> <p>Transició</p> <p>ARACIL, Rafael, MAYAYO, Andreu i SEGURA, Antoni (ed.), <em>Memòria de la transició a Espanya i a Catalunya</em>, Barcelona, Edicions Universitat de Barcelona, 2003.</p> <p>BASSETS, LL., CULLA, J.B. i RIQUER, B. de (dir.), <em>Memòria de Catalunya. Del retorn de Tarradellas al pacte Pujol-Aznar</em>, Madrid-Barcelona, Taurus, 1997.</p> <p>CULLA, Joan B., <em>La Transició i Catalunya, una visió interpretativa</em>, Barcelona, Fundació Ramon Trias Fargas, 2002.</p> <p>JARNE MÒDOL, Antonieta: Estratègies de contestació a la Lleida franquista (1939-1977). Lleida, Servei de Publicacions de la Universitat de Lleida, 1998.</p> <p>GALLEGO MARGALEF, Ferran, <em>El mito de la transición: la crisis del franquismo y los orígenes de la democracia (1973-1977)</em>, Barcelona, Crítica, 2008.</p> <p>MAYAYO, Andreu, <em>La ruptura catalana: les eleccions del 15-J del 1977</em>, Catarroja/Barcelona, Afers, 2002.</p> <p>MOLINERO, Carme (ed.), <em>La Transición treinta años después</em>, Barcelona, Península, 2006, Atalaya, 250.</p> <p>YSÀS, Pere (ed.), <em>La transició a Catalunya i Espanya</em>, Barcelona, Fundació Doctor Vila d’Abadal/L’Avenç, 1997.</p> <p>- <em>La configuració de la democràcia a Espanya</em>, Vic, Eumo: Universitat de Vic, 2009, Referències, 52.</p> <p><strong> </strong></p> <h2 style="text-align: center;"><strong><br /> </strong></h2> <p><strong> </strong></p> <p><strong>Acrònims utilitzats en les notes d’abast:</strong></p> <p>En el cas d’haver utilitzat les definicions dels termes en les notes d’abast del tesaurus, s’ha inclòs l’acrònim de l’obra al final de la definició. Són els següents:</p> <p><strong> </strong></p> <p><strong>DCEFID: </strong>CENTRE D’ESTUDIS SOBRE LES ÈPOQUES FRANQUISTA I DEMOCRÀTICA (CEFID), <em>Catalunya durant el franquisme: diccionari</em>, Vic, Eumo, 2006, Referències, 46.</p> <p><strong>DHC:</strong> MESTRE, Jesús (dir.), <em>Diccionari d’Història de Catalunya</em>, Barcelona, Edicions 62, 1992.</p> <p><strong>DOGC:</strong> MADRIDEJOS, Mateo, <em>Diccionario onomástico de la guerra civil</em>, Barcelona, Flor de Viento, 2006.</p> <p><strong>DPPC:</strong> MOLAS, I. (ed.), <em>Diccionari dels partits polítics de Catalunya</em>, Barcelona, Enciclopèdia Catalana, 2000.</p> <p><strong>EC:</strong> DD.AA.: Gran Enciclopèdia Catalana, Barcelona, Grup Enciclopèdia Catalana, versió online. [http://www.enciclopedia.cat/enciclopèdies/gran-enciclopèdia-catalana]</p> <p><strong>LGC:</strong> GODICHEAU, François, <em>La Guerra Civil en 250 términos</em>, Madrid, Historia Alianza Editorial, 2005.</p>', '<h2 style="text-align: left;"><strong>Tesaurus del Memorial Democràtic</strong></h2> <h3><strong>Origen</strong></h3> <p>El Tesaurus del Memorial Democràtic és un vocabulari controlat sobre història contemporània de Catalunya, fet a mida per al projecte del Banc Memorial, l’arxiu de testimonis d’aquesta institució.</p> <p>Per a la seua creació, es va prendre com a punt de partida el <a href="http://www.vocabularyserver.com/historia_catalunya/" target="_blank">Tesaurus d’Història de Catalunya</a> del Servei d’Informació Bibliogràfica i de Documentació d’Història, Llengua, Literatura i Art de Catalunya de la Universitat Autònoma de Barcelona (<a href="http://sct.uab.cat/sibhilla/" target="_blank">SIBHIL·LA</a>-UAB).</p> <p>La decisió de crear un tesaurus específic parteix de la constatació de la inexistència de llenguatges documentals adients per al marc històric del qual s’ocupa el Memorial Democràtic.</p> <h3><strong>L’estructuració del tesaurus</strong></h3> <p>El tesaurus s’estructura en 4 grans àrees o micro-disciplines, que donen resposta a 4 preguntes: quan (descriptors cronològics), què (descriptors temàtics), qui (descriptors onomàstics) i on (descriptors toponímics).</p> <p>Els descriptors cronològics tenen un límit establert per la pròpia llei del Memorial Democràtic (14/04/1931-20/03/1980). Aquest límit cronològic, queda sobrepassat en algunes ocasions donat que el relat dels testimonis el supera.</p> <h3><strong>Publicació i visualització</strong></h3> <p>Aquest tesaurus no s’ha publicat en paper, però es posa a disposició dels usuaris que se’l poden descarregar, íntegre o en les versions alfabètica i jeràrquica per separat.</p> <p>Existeix però una altra forma de visualització del tesaurus, lligada amb els continguts, i que és aquella que ens permet fer cerques semàntiques dins de la web. Es tracta d’una presentació jeràrquica, on només són visibles els 1.762 termes assignats del tesaurus, junt als termes genèrics als quals està adscrit el descriptor. </p>', 'si'),
(2, 7, 'lg-spa', 'mdcat93-2', '["8"]', '<h2 style="text-align: center;"><strong>TESAURUS DEL MEMORIAL DEMOCRÀTIC</strong></h2> <p> </p> <h3><strong>Origen</strong></h3> <p>El Tesaurus del Memorial Democràtic es un vocabulario controlado sobre historia contemporánea de Cataluña, hecho a medida para el proyecto del Banc Audiovisual de Testimonios, el archivo de historia oral de esta institución.</p> <p>Para su creación, se tomó como punto de partida el <a href="http://www.vocabularyserver.com/historia_catalunya/">Tesaurus d’Història de Catalunya</a> del Servicio de Información Bibliográfica y de Documentación de Historia, Lengua, Literatura y Arte de Cataluña de la Universidad Autónoma de Barcelona (<a href="http://sct.uab.cat/sibhilla/">SIBHIL·LA</a>-UAB).</p> <p>La decisión de crear un tesauro específico parte de la constatación de la inexistencia de lenguajes documentales adecuados para el marco histórico del que se ocupa el Memorial Democràtic.</p> <p>En el 2009 se firma un convenio de colaboración entre la UAB y el Memorial Democràtic, que tiene como objetivo la adaptación del Tesaurus d''Història de Catalunya de la UAB a las necesidades del Banc Memorial. Así, se adapta este corpus a un tesauro específico sobre historia contemporánea para el periodo de referencia del Memorial Democràtic: desde la proclamación de la Segunda República (14 de abril de 1931) hasta las primeras elecciones al Parlament de Catalunya después de la dictadura de Franco (20 de marzo de 1980).</p> <p> </p> <h3><strong>Creación del tesauro</strong></h3> <p>A partir de la estructura de un tesauro preexistente, el proceso de construcción del nuevo corpus se inició con la elaboración de una cronología del periodo, la creación de un compendio de vocabulario y de términos, la selección y normalización de los descriptores y el establecimiento de las relaciones de equivalencia, jerarquía y asociación entre descriptores.</p> <p>El primer paso fue la recopilación de los hechos históricos más relevantes, mediante la consulta de bibliografía especializada. En segundo lugar, a partir de un muestreo de 67 entrevistas, se recogieron un total de 758 conceptos. Estos conceptos, junto con un primer estudio de las fuentes terminológicas más características de la disciplina, permitieron establecer una primera gran estructura con las posibles áreas de conocimiento o microdisciplinas. A partir de aquí se estableció un listado de «descriptores candidatos» y, mediante un método deductivo, se reagruparon los descriptores en función de su temática.</p> <p>En una segunda fase se normalizó el vocabulario recogido, que se concretó en un lenguaje documental. Se examinó cada una de las microdisciplinas con el fin de seleccionar los descriptores y normalizarlos. Este proceso supuso una primera selección entre descriptores y no descriptores y, por lo tanto, la elaboración de una primera estructura de equivalencia semántica entre sinónimos. Una vez seleccionados y normalizados los términos descriptores, se elaboró una estructura jerárquica dentro de cada una de las microdisciplinas. La creación de cadenas jerárquicas permitió detectar y eliminar los dobles usos de descriptores y encontrar posibles lagunas, que se llenaron añadiendo los conceptos que faltaban para mantener la coherencia. Finalmente, se examinó cada uno de los descriptores del tesauro para poder establecer sus relaciones asociativas con otros descriptores ubicados en otras áreas de conocimiento.</p> <p>En marzo del 2010 se dispuso de una primera versión del tesauro, concebida como estructura base válida, que tendría que ser obligatoriamente transformada a partir de la inducción de nuevos términos en el proceso de indexación, y de las revisiones a nivel de coherencia. Y, efectivamente, los 2315 términos iniciales se han multiplicado por 5 hasta este 2014.</p> <p>A lo largo del año 2010 se introdujo esta primera versión en la plataforma <a href="http://www.fmomo.org/dedalo">Dédalo</a>, que gestiona el Banc Memorial, y se inició el proceso de indexación de las primeras 109 entrevistas. Este proceso se acompañó de la revisión del tesauro y de la creación de nuevos términos deducidos, valiéndonos de la estructura básica creada. La ampliación de algunas microdisciplinas, a partir de obras de referencia, la deducción de términos y la ampliación de determinadas ramas del tesauro, como, por ejemplo, los centros de privación de libertad de la Guerra Civil, la represión franquista y la Segunda Guerra Mundial, comportaron un aumento exponencial del número de términos. Y, a partir de la necesidad de situar poblaciones que se deducían de los relatos orales, se optó por la inclusión de nomenclátores de varios países, los descriptores toponímicos, que nos permitieron situar poblaciones o territorios. Esta última decisión comportó la revisión estructural del tesauro en 4 microdisciplinas, que es la que se mantiene en el tesauro actual (2014). Así, a finales del 2010 disponíamos de una segunda versión del tesauro, con una gran ampliación de términos y un cambio estructural.</p> <p>El año 2012 se retomó el proyecto, empezando por la ampliación del apartado de personajes públicos a partir de bibliografía especializada, sin indexar nuevos contenidos.</p> <p>En los años 2013 y 2014 se retomaron las tareas de indexación, lo que comportó de nuevo la revisión del tesauro y la proposición de nuevos términos inducidos. Durante este periodo se procedió a una revisión integral de la coherencia del tesauro, dado que la estructuración hecha en el 2010 en la segunda versión del tesauro había dejado sin resolver aspectos de coherencia, que provenían de la estructura de la primera versión. Esta revisión íntegra se realizó a partir de la indexación de nuevos contenidos, que elevaron el número de entrevistas finalizadas a 377.</p> <p>Es importante destacar que, con esta última revisión, se eliminaron términos que no tenían en cuenta la posibilidad de realizar búsquedas combinadas por parte de los usuarios, implementando como práctica para la indexación el uso de palabras clave combinadas (así, por ejemplo, se eliminaron palabras clave como «Ocio y ocio en tiempo de la República» para indexarlas con «Ocio y ocio» y «Segunda República española»). Esta revisión comportó volver a indexar todos aquellos fragmentos de entrevistas de los términos que se eliminaron, lo que estimula el uso de búsquedas combinadas por parte de los usuarios.</p> <p>En julio del 2014, la tercera versión del tesauro consta de 78 012 términos, de los cuales 11 775 son descriptores no toponímicos (el proyecto tiene cargados el nomenclátor oficial de 6 países de los que se habla en las entrevistas, de forma que el número total de topónimos es muy elevado a pesar de que se utiliza una ínfima parte de estos descriptores). Así, el núcleo del tesauro son los descriptores cronológicos, temáticos y onomásticos, que representan un número considerable de palabras clave a utilizar. Esta versión, sin los descriptores toponímicos (los nomenclátores), se puede descargar íntegramente, o parcialmente en sus versiones alfabética y jerárquica.</p> <p>El tesauro sigue vivo, se mantiene y se revisa regularmente en cada indexación de proyectos. Con este vocabulario controlado se han creado, en julio del 2014, un total de 10.056 fragmentos de entrevistas, a los que se han asignado 25.028 términos. Estos datos nos permiten ver, también, el grado de catalogación detallada, puesto que dan una media de 2,5 términos utilizados por fragmento, hecho que nos permite deducir que la búsqueda combinada a partir de términos del tesauro dará resultados muy precisos en las búsquedas que hagan los usuarios.</p> <p> </p> <h3><strong>La estructuración del tesauro</strong></h3> <p>El tesauro se estructura en 4 grandes áreas o microdisciplinas, que dan respuesta a 4 preguntas: cuándo (descriptores cronológicos), qué (descriptores temáticos), quién (descriptores onomásticos) y dónde (descriptores toponímicos).</p> <p>Los descriptores cronológicos tienen un límite temporal establecido por la misma ley del Memorial Democràtic: del 14/04/1931 al 20/03/1980. Este límite cronológico se sobrepasa en algunas ocasiones porque el relato de los testimonios lo supera. Por ello encontramos términos fuera de este marco (como, por ejemplo, «Dictadura de Primo de Rivera» o «Golpe de estado de Tejero»). En esta primera microdisciplina hemos agrupado los periodos históricos, y hemos creado dos agrupaciones cronológicas diferenciadas de estos periodos por razones de coherencia: hemos creado una agrupación con el nombre «Hechos internacionales» para los que han podido tener relación con los relatos de los testimonios, pero que no se ubican geográficamente en Cataluña o en España (por ejemplo, Concilio Vaticano II), y hemos agrupado dentro del término «Exilio 1939» todos aquellos términos que semánticamente guardan relación, pero que también por razones geográficas quedan fuera de los grandes periodos históricos. El orden de los descriptores cronológicos, en la visualización jerárquica, se corresponde con la cronología y no con un orden alfabético.</p> <p>Los descriptores temáticos mantienen una estructura idéntica a la del Tesaurus d''Història de Catalunya de la UAB, y se ha incluido una nueva agrupación con el nombre «Guerra y consecuencias de la guerra», dada la especificidad de muchas entrevistas, que son memorias vinculadas a un hecho bélico pero que no pueden ubicarse en los descriptores cronológicos, y, al mismo tiempo, se ha desvinculado de la agrupación semántica «Defensa y orden público», junto con los términos dependientes del concepto «Guerra».</p> <p>Los descriptores onomásticos son una microdisciplina nueva y diferenciada del tesauro madre, el de la UAB, que se decidió crear porque las entrevistas contienen muchas referencias a personajes públicos, y sobre todo son memorias que guardan relación con lugares de memoria, especialmente centros de privación de libertad.</p> <p>Finalmente, los descriptores toponímicos se incluyeron también en el tesauro, conscientes del volumen que suponía la introducción de nomenclátores de países, pero valorando que muchas de las memorias de los entrevistados se ubicaban en un espacio geográfico que podía ser de interés para los usuarios en la recuperación de información, como las poblaciones de acogida de los exiliados.</p> <p> </p> <h3><strong>Equipo humano</strong></h3> <p>El Tesaurus del Memorial Democràtic parte del Tesaurus d''Història de Catalunya de la UAB. Esta base y la primera adaptación (2009-2010) son obra de Anna Pascual Bosser, que fue dirigida por Maribel Cuadrado y Núria Rius (<a href="http://sct.uab.cat/sibhilla/">SIBHIL·LA</a>-UAB).</p> <p>La ampliación de los personajes públicos del año 2012 es obra de Laura Molinos. La revisión íntegra del tesauro que se llevó a cabo durante el periodo 2013-2014, a partir de la indexación de nuevos contenidos, ha sido realizada por Anna Pascual Bosser y Joan Palahí.</p> <p>La coordinación y la revisión son obra de Gerard Corbella, responsable del Banc Memorial. En la revisión de los términos históricos han participado puntualmente historiadores tanto del Memorial Democràtic como de la UAB.</p> <p> </p> <h3><strong>Norma ISO y tesauro multilingüe</strong></h3> <p>Desde la primera hasta la última versión del tesauro se ha tenido en cuenta la norma ISO 2788:1986 (UNE 50-106-90), para la creación de tesauros monolingües. Dado que el proyecto está planteado para ser visualizado en 4 idiomas, la plataforma <a href="http://www.fmomo.org/dedalo">Dédalo</a> ha tenido en cuenta la norma ISO 5964 (UNE 50-125), para los tesauros multilingües.</p> <p>Respecto al uso del lenguaje natural, en los tesauros de historia consultados constatamos que este lenguaje no se utiliza en el caso de los números ordinales, para facilitar la recuperación de información. Dado que se ha utilizado una base de datos (<a href="http://www.fmomo.org/dedalo">Dédalo</a>) para la creación y gestión del tesauro, hemos optado por la utilización del lenguaje natural porque nos permite recuperar la información (por ejemplo, no usamos «República II» como sí hacen los otros tesauros, sino el natural «Segunda República»).</p> <p>En el apartado de la bibliografía se da cuenta de las obras utilizadas, tanto respecto a normativa técnica como a obras de referencia y de consulta.</p> <p>A partir de la creación de una tercera versión definitiva del tesauro, en una única lengua, hemos optado por la traducción íntegra del corpus a 4 idiomas (del catalán al castellano, al francés y al inglés). El tesauro, en los diferentes idiomas, tiene exactamente los mismos términos que en el original, y se presenta tanto alfabética como jerárquicamente. La traducción ha sido realizada por profesionales acreditados, dentro de la base de datos. La única diferencia con el original es que no se han traducido las notas de alcance de los términos.</p> <p>Tanto la navegación a través de la web como las presentaciones del tesauro en texto se realizan siempre a partir del idioma de consulta del usuario.</p> <p> </p> <h3><strong>Gestión tecnológica</strong></h3> <p>El tesauro se gestiona con <a href="http://www.fmomo.org/dedalo">Dédalo</a>, la plataforma que nos permite hacer la gestión íntegra del Banc Memorial (desde la ingesta de los vídeos hasta la indexación de contenidos). La creación de términos en la base de datos nos permite establecer las relaciones jerárquicas y semánticas de términos, introducir las notas de alcance, restringir el uso de los términos para la indexación, controlar y guiar la polisemia y la sinonimia, generar espacios semánticos sobre conjuntos de modelos y modificar dependencias jerárquicas y semánticas, así como modificar la ortografía, sin perder el trabajo de indexación ya realizado, y traducir los términos a las lenguas del proyecto.</p> <p>La indexación de los contenidos se hace mediante el tesauro y a partir de las transcripciones de las entrevistas. Teniendo en cuenta que estas transcripciones están relacionadas mediante códigos de tiempos con los vídeos de los testimonios, en la recuperación de la información, las indexaciones coinciden tanto con los fragmentos de texto como con los de vídeo.</p> <p>De las transcripciones de las entrevistas en la lengua original (catalán o castellano) se generan traducciones automáticas, que, si bien contienen errores, facilitan a los usuarios otras lenguas para entender el contenido de las entrevistas. Las entrevistas traducidas no se reindexan a partir del tesauro traducido, sino que las marcas de indexación del idioma original se propagan en las transcripciones en los otros idiomas, insertando los términos ya traducidos en el tesauro de la lengua de destino. Estos adelantos tecnológicos nos han permitido disponer de un tesauro multilingüe y con idénticas indexaciones en los 4 idiomas, lo cual posibilitará búsquedas semánticas con idéntica precisión independientemente del idioma de consulta del usuario.</p> <h3> </h3> <h3><strong>Publicación y visualización</strong></h3> <p>Es posible ver el tesauro de dos maneras: la primera es la versión completa (sin los descriptores toponímicos), mientras que la segunda es la versión con los términos utilizados.</p> <p>La versión completa del tesauro no se ha publicado en papel, pero sí se pone a disposición de los usuarios, que se la pueden descargar, íntegra o en las versiones alfabética y jerárquica por separado. Aparte de la versión digital estática (una versión determinada), existe la posibilidad de ver el tesauro en su visualización jerárquica dinámica (pudiendo desplegar las jerarquías), en el apartado de documentación, donde aparecen los 11 775 descriptores cronológicos, temáticos y onomásticos.</p> <p>Hay, además, una segunda forma de visualizar el tesauro, ligada con los contenidos, que nos permite hacer búsquedas semánticas dentro de la web. Se trata de una presentación jerárquica, donde solo son visibles los 1776 términos utilizados del tesauro, junto con los términos genéricos a los cuales está adscrito el descriptor.</p>', '<h2><strong>Tesaurus del Memorial Democràtic</strong></h2> <h3 style="text-align: left;"><strong>Origen</strong></h3> <p>El Tesaurus del Memorial Democràtic es un vocabulario controlado sobre historia contemporánea de Cataluña, hecho a medida para el proyecto del Banc Audiovisual de Testimonios, el archivo de historia oral de esta institución.</p> <p>Para su creación, se tomó como punto de partida el <a href="http://www.vocabularyserver.com/historia_catalunya/">Tesaurus d’Història de Catalunya</a> del Servicio de Información Bibliográfica y de Documentación de Historia, Lengua, Literatura y Arte de Cataluña de la Universidad Autónoma de Barcelona (<a href="http://sct.uab.cat/sibhilla/">SIBHIL·LA</a>-UAB).</p> <p>La decisión de crear un tesauro específico parte de la constatación de la inexistencia de lenguajes documentales adecuados para el marco histórico del que se ocupa el Memorial Democràtic.</p> <h3><strong>La estructuración del tesauro</strong></h3> <p>El tesauro se estructura en 4 grandes áreas o microdisciplinas, que dan respuesta a 4 preguntas: cuándo (descriptores cronológicos), qué (descriptores temáticos), quién (descriptores onomásticos) y dónde (descriptores toponímicos).</p> <p>Los descriptores cronológicos tienen un límite temporal establecido por la misma ley del Memorial Democràtic: del 14/04/1931 al 20/03/1980. Este límite cronológico se sobrepasa en algunas ocasiones porque el relato de los testimonios lo supera.</p> <h3><strong>Publicación y visualización</strong></h3> <p>Es posible ver el tesauro de dos maneras: la primera es la versión completa (sin los descriptores toponímicos), mientras que la segunda es la versión con los términos utilizados.</p> <p>La versión completa del tesauro no se ha publicado en papel, pero sí se pone a disposición de los usuarios, que se la pueden descargar, íntegra o en las versiones alfabética y jerárquica por separado. Hay, además, una segunda forma de visualizar el tesauro, ligada con los contenidos, que nos permite hacer búsquedas semánticas dentro de la web. Se trata de una presentación jerárquica, donde solo son visibles los 1776 términos utilizados del tesauro, junto con los términos genéricos a los cuales está adscrito el descriptor.</p>', 'si');
INSERT INTO `tesauro_presentacion` (`id`, `id_matrix`, `lang`, `documento_completo`, `tesauro_presentacion_documento`, `presentacion_pdf`, `presentacion_general`, `publicacion`) VALUES
(3, 7, 'lg-eng', 'mdcat93-3', '["8"]', '<h2 style="text-align: center;"><strong>DEMOCRATIC MEMORY THESAURUS</strong></h2> <h2 style="text-align: center;"> </h2> <h2 style="text-align: center;"> </h2> <h3><strong>Origin</strong></h3> <p>The Democratic Memory Thesaurus is a controlled vocabulary on the contemporary history of Catalonia, designed specifically for the Audiovisual Bank of Testimonies, the institution’s oral history archive.</p> <p>To create it, the <a href="http://www.vocabularyserver.com/historia_catalunya/" target="_blank">Tesaurus d’Història de Catalunya</a> (Thesaurus of the History of Catalonia) of <a href="http://sct.uab.cat/sibhilla/en" target="_blank">SIBHIL·LA</a>-UAB, the Universitat Autònoma de Barcelona’s Bibliographic Information Service and Documentation of History, Language, Literature and Art of Catalonia<em>,</em> was used as a starting point.</p> <p>The decision to create a specific thesaurus stems from the inexistence of documentary languages adapted to the historic timeframe that the Democratic Memory covers.</p> <p>In 2009 a collaboration agreement was signed between UAB and Democratic Memory with the purpose of adapting UAB’s Tesaurus d’Historia de Catalunya to Banc Memorial’s requirements.Thus, this corpus is adapted to a specific thesaurus on contemporary history for the period of reference of the Democratic Memory:from the proclamation of the Second Republic (14 April 1931) to the first elections of the Parliament of Catalonia after the dictatorship of Franco (20 March 1980).</p> <p> </p> <h3><strong>Creation of the thesaurus</strong></h3> <p>Based on the structure of the pre-existing thesaurus, the construction process of the new corpus began with the preparation of a timeline for the period, the creation of a compendium of vocabulary and terms, the selection and standardisation of descriptors and the establishing of equivalence, hierarchy and association relationships between descriptors.</p> <p>The first phase involved listing the most relevant historical events using specialised literature.Following this, based on a sample of 67 interviews, a total of 758 concepts were defined.These concepts, together with an initial study of the most typical terminology resources for the field, enabled the first main structure to be established, with possible areas of knowledge or micro-disciplines.A list of ‘candidate descriptors’ was then established and using a deductive method they were regrouped according to their subject.</p> <p>During a second phase the vocabulary gathered was standardised, and resulted in a documentary language.Each of the micro-disciplines was studied with the aim of selecting the descriptors and standardising them.This process involved an initial selection of descriptors and non-descriptors and, therefore, the preparation of an initial structure of semantic equivalence between synonyms.Once the descriptor terms were selected and standardised, a hierarchical structure was established within each of the micro-disciplines.The creation of hierarchical chains allowed the detection and elimination of duplicated descriptors and possible gaps to be found which were filled by adding the missing concepts in order to maintain coherence.Finally, each of the descriptors in the thesaurus was examined to establish its associative relations with other descriptors from other knowledge areas.</p> <p>By March 2010 a first version of the thesaurus was available, conceived as a valid base structure, which would have to be altered based on the introduction of new terms during the indexing process and on the revisions at a coherence level.And, indeed, between then and 2014, the 2,315 initial terms increased fivefold.</p> <p>Throughout 2010 this first version was introduced onto the <a href="http://www.fmomo.org/dedalo" target="_blank">Dédalo</a> platform, managed by Banc Memorial, and the indexing process began of the first 109 interviews.This process went hand in hand with the revision of the thesaurus and the creation of new terms obtained, based on the basic structure.The expansion of some micro-disciplines, based on works of reference, the deduction of terms and expansion of some branches of the thesaurus, such as the Civil War detention centres, repression under Franco and the Second World War, meant an exponential increase in the number of terms.And as a result of the need to include places mentioned in the interviews it was decided that nomenclatures of several countries, the toponymic descriptors, should be added, allowing towns and regions to be included.This decision led to the structural revision of the thesaurus in 4 micro-disciplines, which is its current structure (2014).Therefore, at the end of 2010 a second version of the thesaurus existed, with a significant expansion of terms and a structural change.</p> <p>In 2012 the project was resumed, beginning with the expansion of the section on public figures based on specialised literature, without indexing new content.</p> <p>In 2013 and 2014 the indexing task resumed, which led to another revision of the thesaurus and the suggestion of new terms.During this period a complete revision of the coherence of the thesaurus was commenced, given that the structure created in 2010 in the second version of the thesaurus had left unresolved some aspects of coherence, resulting from the first version’s structure.This complete revision was made based on the indexing of new content, which increased the number of completed interviews to 377.</p> <p>It is important to point out that with this final revision, terms that did not take into account the possibility of users making combined searches were eliminated, implementing as indexing practice the use of combined key words (thus eliminating, for example, key words such as “Leisure and free time during the Republic” and indexing them as “Leisure and free time'' and “Second Republic”).This revision led to the re-indexing of all the fragments of interviews with terms that were eliminated, thus encouraging the use of combined searches by users.</p> <p>By July 2014, a third version of the thesaurus included 78,012 terms, of which 11,775 are non-toponymic descriptors (the project includes the official nomenclature of 6 countries mentioned in the interviews, meaning that the total number of toponyms is very high and that a very small part of these descriptors are used).Therefore, the core of the thesaurus comprises the chronologic, thematic and onomastic descriptors, which represent a considerable number of key words used.This version, without the toponymic descriptors (the nomenclatures), can be fully downloaded, or partially in its alphabetic and hierarchical versions.</p> <p>The thesaurus is still alive; it is maintained and is revised regularly during each indexing of projects.With this controlled vocabulary, by July 2014 a total of 10.056 interview fragments had been created, to which 25.028 terms have been assigned.These numbers also allow us to see the level of detailed cataloguing, as they give an average of 2.5 terms used per fragment, something which enables us to deduce that the combined search based on thesaurus terms will provide very precise results in searches done by users.</p> <p> </p> <h3><strong>Structure of the thesaurus</strong></h3> <p>The thesaurus is structured in 4 main areas or micro-disciplines, which respond to 4 questions:when (chronological descriptors), what (thematic descriptors), who (onomastic descriptors) and where (toponymic descriptors).</p> <p>The chronological descriptors have a time frame established by the law on Democratic Memory, from14/04/1931 to 20/03/1980. This limit is exceeded on occasion by the actual testimonies.For this reason terms that fall outside this time frame can be found, such as “Dictatorship of Primo de Rivera” and “Tejero coup d’état”.This first micro-discipline covers the historic periods, and we have created two chronological groups differentiated from them for purposes of coherence:one group with the name “International events” for those mentioned in the testimonies but which are not located geographically in Catalonia or Spain (for example, Second Vatican Council), and we have grouped under ''Exile 1939'' all those terms that are related semantically but which also for geographical reasons fall outside the main historical periods.The organisation of the chronological descriptors, in the hierarchical window, corresponds to the chronology and not to an alphabetical order.  </p> <p>The thematic descriptors have exactly the same structure as that of the Tesaurus d’Història de Catalunya of UAB, and a new group with the name “The war and its consequences” has been included, due to the specificity of many interviews which are memories linked to the conflict but which cannot be place in the chronological descriptors, and at the same time are unconnected with the semantic group “The army and public order”, together with the terms dependent on the concept “War”.</p> <p>The onomastic descriptors are a new multidiscipline, different from the UAB’s thesaurus, and were created because the interviews contain many references to public figures, and above all are memories that are connected to places of memory, particularly detention centres.</p> <p>Finally, the toponymic descriptors were also included in the thesaurus, despite the volume that the introduction of countries would entail, but considering that many of the interviewees'' memories were placed in a geographic area that could be of interest to users when recovering information, such as places that welcomed those in exile.</p> <p> </p> <h3><strong>The team</strong></h3> <p>The Democratic Memory Thesaurus is based on UAB’s Tesaurus d’Història de Catalunya.The original and the first version (2009-2010) are the work of Anna Pascual Bosser, managed by Maribel Cuadrado and Núria Rius (<a href="http://sct.uab.cat/sibhilla/">SIBHIL·LA</a>-UAB).</p> <p>The addition of public figures in 2012 is the work of Laura Molinos.The complete revision of the thesaurus that was carried out during 2013-2014, based on the indexing of new content, was done by Anna Pascual Bosser and Joan Palahí.</p> <p>The coordination and revision are the work of Gerard Corbella, manager of the Banc Memorial.In the revision of historic terms, historians from both Democratic Memory and UAB have participated.</p> <p> </p> <h3><strong>ISO Standard and multilingual thesaurus</strong></h3> <p>From the first version of the thesaurus to the latest, the ISO 2788:1986 (UNE 50-106-90) standard has been taken into account, for the creation of monolingual thesauruses.Given that the project was planned to be viewed in 4 languages, the <a href="http://www.fmomo.org/dedalo">Dédalo</a> platform has taken into consideration the ISO 5964 (UNE 50-125) standard, for multilingual thesauruses.</p> <p>With regard to the use of natural language, in historical thesauruses consulted we established that this language is not used in the case of ordinal numbers, in order to facilitate the recovery of information.Given the use of a database (<a href="http://www.fmomo.org/dedalo">Dédalo</a>), for the creation and management of the thesaurus we opted to use natural language because it allows us to recover the information. For example, unlike other thesauruses we do not use “2nd Republic” but the natural “Second Republic”.</p> <p>In the bibliography section the works used, with regard to both the technical regulations and reference and consultation works, are listed.</p> <p>As of the creation of a third and final version of the thesaurus in a single language, we chose to translate the entire corpus into 4 languages (from Catalan into Spanish, French and English).The thesaurus in the different languages has exactly the same terms as the original and is presented in both alphabetical and hierarchical order.The translations have been done by accredited professionals within the database.The only difference with the original is that the explanatory notes of the terms have not been translated.</p> <p>Both browsing on the website and the presentation of the thesaurus in text form are done based on the user''s search language.</p> <p> </p> <h3><strong>Technology management</strong></h3> <p>The thesaurus is managed using <a href="http://www.fmomo.org/dedalo">Dédalo</a>, a platform that enables the complete management of the Banc Memorial, from uploading videos to indexing content.The creation of terms in the database allows hierarchical and semantic relationships of terms to be established, explanatory notes to be introduced, the use of terms for indexing to be restricted, control and management of polysemy and synonymy, semantic spaces to be generated on sets of models and hierarchical and semantic dependencies to be modified, as well as spelling to be corrected, without losing the indexing work already carried out, and the translation of the terms into the project languages.</p> <p>The indexing of content is done using the thesaurus and based on the interview transcripts.Taking into account that these transcripts are related using time codes with the videos of the testimonies, for the recovery of information the indexes coincide with both the fragments of text as well as the video.</p> <p>From the interview transcripts in the original language (Catalan or Spanish) automatic translations are created, which although may contain errors, do allow users of other languages to understand the general content of the interviews.The translated interviews are not re-indexed based on the translated thesaurus, but the index marks of the original language are included in the transcripts in the other languages, inserting the terms translated in the thesaurus in the target language.This technological progress has enabled us to provide a multilingual thesaurus with identical indexing in the 4 languages, which makes semantic searches possible that are equally as precise regardless of the user’s search language.</p> <h3> </h3> <h3><strong>Publication and display</strong></h3> <p>The thesaurus can be viewed in two ways.The first is the complete version (without toponymic descriptors), whilst the second is the version with the terms used.</p> <p>The complete version of the thesaurus has not been published on paper but is available to users, who can download it, either completely or separately in alphabetical or hierarchical versions.As well as the static digital version (a specific version), the thesaurus can also be displayed in its dynamic hierarchical version (with the hierarchies being expanded), in the documentation section, where the 11,775 chronological, thematic and onomastic descriptors can be viewed.</p> <p>There is however a second way of viewing the thesaurus, linked to the content, which enables semantic searches on the website.This is a hierarchical presentation, where only 1,776 of the terms used in the thesaurus are visible, together with generic terms to which the descriptors are linked.</p>', '<h2><strong>Memorial Democràtic </strong><strong>Thesaurus</strong></h2> <h3 style="text-align: left;"><strong>Origin</strong></h3> <p>The Memorial Democràtic Thesaurus is a controlled vocabulary on the contemporary history of Catalonia, designed specifically for the Audiovisual Bank of Testimonies, the institution’s oral history archive.</p> <p>To create it, the <a href="http://www.vocabularyserver.com/historia_catalunya/">Tesaurus d’Història de Catalunya</a> (Thesaurus of the History of Catalonia) of <a href="http://sct.uab.cat/sibhilla/en">SIBHIL·LA</a>-UAB, the Universitat Autònoma de Barcelona’s Bibliographic Information Service and Documentation of History, Language, Literature and Art of Catalonia<em>,</em> was used as a starting point.</p> <p>The decision to create a specific thesaurus stems from the inexistence of documentary languages adapted to the historic timeframe that the Memorial Democràtic covers.</p> <h3><strong>Structure of the thesaurus</strong></h3> <p>The thesaurus is structured in 4 main areas or micro-disciplines, which respond to 4 questions:when (chronological descriptors), what (thematic descriptors), who (onomastic descriptors) and where (toponymic descriptors).</p> <p>The chronological descriptors have a time frame established by the law on Memorial Democràtic, from14/04/1931 to 20/03/1980. This limit is exceeded on occasion by the actual testimonies.</p> <h3><strong>Publication and display</strong></h3> <p>The complete version of the thesaurus has not been published on paper but is available to users, who can download it, either completely or separately in alphabetical or hierarchical versions.</p> <p>There is however a second way of viewing the thesaurus, linked to the content, which enables semantic searches on the website.This is a hierarchical presentation, where only 1,776 of the terms used in the thesaurus are visible, together with generic terms to which the descriptors are linked.</p>', 'si');
INSERT INTO `tesauro_presentacion` (`id`, `id_matrix`, `lang`, `documento_completo`, `tesauro_presentacion_documento`, `presentacion_pdf`, `presentacion_general`, `publicacion`) VALUES
(4, 7, 'lg-fra', 'mdcat93-4', '["8"]', '<h2 class="ParaAttribute0" style="text-align: center;"><span class="CharAttribute1"><span lang="FR">TH</span></span><span class="CharAttribute1"><span lang="FR">É</span></span><span class="CharAttribute1"><span lang="FR">SAURUS DU MEMORIAL DEMOCR</span></span><span class="CharAttribute1"><span lang="FR">À</span></span><span class="CharAttribute1"><span lang="FR">TIC</span></span></h2> <p style="text-align: center;"> </p> <h3 class="ParaAttribute1"><span class="CharAttribute1"><span lang="FR">Origine</span></span></h3> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Le Th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus du Memorial Democr</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">tic est un vocabulaire contr</span></span><span class="CharAttribute3"><span lang="FR">ô</span></span><span class="CharAttribute3"><span lang="FR">l</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> sur l''histoire contemporaine de la Catalogne, con</span></span><span class="CharAttribute3"><span lang="FR">ç</span></span><span class="CharAttribute3"><span lang="FR">u sur mesure pour le projet de la Banque Audiovisuel de T</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">moignages,  l</span></span><span class="CharAttribute3"><span lang="FR">’</span></span><span class="CharAttribute3"><span lang="FR">archive d</span></span><span class="CharAttribute3"><span lang="FR">’</span></span><span class="CharAttribute3"><span lang="FR">histoire orale de cette institution.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Pour sa cr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ation,  on est parti du </span></span><span lang="FR"><a href="http://www.vocabularyserver.com/historia_catalunya/"><span class="CharAttribute6">Th</span><span class="CharAttribute6">é</span><span class="CharAttribute6">saurus d</span><span class="CharAttribute6">’</span><span class="CharAttribute6">Histoire de Catalogne</span></a></span><span class="CharAttribute3"><span lang="FR"> du Service d</span></span><span class="CharAttribute3"><span lang="FR">’</span></span><span class="CharAttribute3"><span lang="FR">Information Bibliographique et de Documentation d''Histoire,  Langue,  Litt</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rature et Art de Catalogne de l''Universit</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> Autonome de Barcelone (</span></span><span lang="FR"><a href="http://sct.uab.cat/sibhilla/"><span class="CharAttribute6">SIBHIL</span><span class="CharAttribute6">·</span><span class="CharAttribute6">LA</span></a></span><span class="CharAttribute3"><span lang="FR">-UAB). </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">La d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cision de cr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">er un th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus sp</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cifique part du constat de l''absence totale de langages documentaires adapt</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s au cadre historique dont s''occupe le Memorial Democr</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">tic.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">En 2009, un accord de partenariat est sign</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> entre l''UAB et le Memorial Democr</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">tic, l''objectif de cet accord porte sur l''adaptation du Th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus d''Histoire de la Catalogne de l''Universit</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> aux besoins de la banque de donn</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">es du Memorial. Ce corpus est donc adapt</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> un th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus sp</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cifique sur l''histoire contemporaine pour la p</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">riode de r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">f</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rence du Memorial Democr</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">tic : de la proclamation de la Seconde R</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">publique (14 avril 1931) aux premi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">res </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">lections au parlement de Catalogne apr</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">s la dictature de Franco (le 20 mars 1980).</span></span></p> <p class="ParaAttribute1"> </p> <h3 class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Cr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ation du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus</span></span></h3> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">À</span></span><span class="CharAttribute3"><span lang="FR"> partir de la structure d''un th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus pr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">existant,  le processus de fabrication du nouveau corpus d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">bute par l''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">laboration d''une chronologie de la p</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">riode, la cr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ation d''un lexique de vocabulaire et de termes, la s</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">lection et la normalisation des descripteurs puis l''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tablissement des relations d''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">quivalence,  de hi</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rarchie et d''association entre ces descripteurs.  </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">La premi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tape a port</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> sur la </span></span><span lang="FR"><a href="file://drep04/personal/gcorbella/2014/BANC%20AUDIOVISUAL/Traducci%C3%B3/Web/Documentaci%C3%B3%20a%20annexar%20a%20la%20web/Thesaurus/CRONOLOGIA_INICIAL_2009.pdf"><span class="CharAttribute6">compilation des faits historiques</span></a></span><span class="CharAttribute3"><span lang="FR"> les plus importants, pour ce faire, on a consult</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> la bibliographie sp</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cialis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e. En second lieu, </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> partir d''un </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">chantillon de 67 entretiens, on a recueilli 758 concepts. Ces concepts, associ</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> une premi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tude des sources terminologiques les plus caract</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ristiques de la discipline,  permettront d''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tablir une premi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re grande structure avec tous les domaines de connaissance ou micro disciplines envisageables. </span></span><span class="CharAttribute3"><span lang="FR">À</span></span><span class="CharAttribute3"><span lang="FR"> partir de l</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">, on a d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">termin</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> une liste des ''descripteurs candidats'' puis, en appliquant la m</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">thode de la d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">duction,  on a regroup</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> les descripteurs en fonction de leur th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">matique.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Dans un deuxi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">me temps,  on a normalis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> le vocabulaire recueilli, il est alors pass</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> au stade de langage documentaire.  Chacune des micro-disciplines est examin</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e afin de s</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">lectionner les descripteurs et de les normaliser. Ce processus suppose un premier tri entre les descripteurs et les non-descripteurs, il suppose donc l''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">laboration d''une premi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re structure d''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">quivalence s</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">mantique entre les synonymes. Apr</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">s avoir s</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">lectionn</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> et normalis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> les termes descripteurs,  on </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">labore une organisation hi</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rarchique pour chaque micro-discipline.  La cr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ation de cha</span></span><span class="CharAttribute3"><span lang="FR">î</span></span><span class="CharAttribute3"><span lang="FR">nes hi</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rarchiques permet de d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tecter et d''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">liminer les doublons et de d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">celer d''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ventuelles lacunes qui seront combl</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">es en ajoutant les concepts manquants de fa</span></span><span class="CharAttribute3"><span lang="FR">ç</span></span><span class="CharAttribute3"><span lang="FR">on </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> conserver une coh</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rence. Finalement,  chaque descripteur du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus est analys</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> afin d''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tablir les liens vers d''autres descripteurs situ</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s dans d''autres domaines de connaissance.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">En mars 2010, on dispose d''une </span></span><span lang="FR"><a href="file://drep04/personal/gcorbella/2014/BANC%20AUDIOVISUAL/Traducci%C3%B3/Web/Documentaci%C3%B3%20a%20annexar%20a%20la%20web/Thesaurus/Versi%C3%B3_1_complerta.pdf"><span class="CharAttribute6">premi</span><span class="CharAttribute6">è</span><span class="CharAttribute6">re version du th</span><span class="CharAttribute6">é</span><span class="CharAttribute6">saurus</span></a></span><span class="CharAttribute3"><span lang="FR">, con</span></span><span class="CharAttribute3"><span lang="FR">ç</span></span><span class="CharAttribute3"><span lang="FR">ue comme une structure de base qui devrait obligatoirement </span></span><span class="CharAttribute3"><span lang="FR">ê</span></span><span class="CharAttribute3"><span lang="FR">tre transform</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> partir de l''ajout de nouveaux termes dans le processus d''indexation et des r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">visions au niveau de la coh</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rence. Effectivement, les 2315 termes disponibles au d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">part ont </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> multipli</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s par 5 </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> la fin de l''ann</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e 2014. </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Tout au long de l''ann</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e 2010, cette premi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re version a </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> introduite </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> la plateforme </span></span><span lang="FR"><a href="http://www.fmomo.org/dedalo"><span class="CharAttribute6">D</span><span class="CharAttribute6">é</span><span class="CharAttribute6">dalo</span></a></span><span class="CharAttribute3"><span lang="FR">, qui g</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re le Banque de donn</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">es du Memorial, ouvrant le processus d''indexation des 109 premiers entretiens. Ce processus s''accompagne de la r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vision du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus et de la cr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ation de nouveaux termes d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">duits, en s''appuyant sur la structure de base cr</span></span><span class="CharAttribute3"><span lang="FR">éé</span></span><span class="CharAttribute3"><span lang="FR">e. L''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">largissement de certaines micro-disciplines, </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> partir des travaux de r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">f</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rence, la d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">duction de termes et l''ajout de certaines branches du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus, comme c''est le cas pour les centres de privation de libert</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> de la Guerre civile, la r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">pression franquiste et la Seconde Guerre Mondiale, induiront une hausse exponentielle du nombre de termes. En partant du besoin de situer les villages d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">duits des r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cits oraux, on opte pour l''inclusion d''une nomenclature des diff</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rents pays, des descripteurs toponymiques ce qui permet de localiser les villages ou territoires. Ce dernier choix comporte la r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vision structurelle du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus en 4 micro-disciplines, cette organisation est celle maintenue sur le th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus actuel (version 2014). Ainsi, </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> la fin de l''ann</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e 2010 on disposait d''une seconde version du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus, celle-ci incluait un nombre croissant de termes et un changement structurel.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">En 2012, le projet a </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> relanc</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> avec l''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">largissement du paragraphe sur les personnalit</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s publiques </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> partir d''une bibliographie sp</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cialis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e, sans indexation de nouveaux contenus.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">En 2013 et 2014, ce sont les t</span></span><span class="CharAttribute3"><span lang="FR">â</span></span><span class="CharAttribute3"><span lang="FR">ches d''indexation qui ont </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> relanc</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">es, ce point implique une fois encore la r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vision du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus et la proposition de nouveaux termes induits. Au cours de cette p</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">riode, une r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vision compl</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">te a </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> effectu</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e sur la coh</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rence du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus, jusqu''</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> ce que la structure </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">labor</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e en 2010 lors de la seconde version du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus ait laiss</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> appara</span></span><span class="CharAttribute3"><span lang="FR">î</span></span><span class="CharAttribute3"><span lang="FR">tre des d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">fauts de coh</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rence li</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> la structure de la premi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re version. Cette r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vision compl</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">te est r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">alis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> partir de l''indexation de nouveaux contenus qui allait </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">lever le nombre d''entretiens termin</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> 377. </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Il est primordial de souligner que dans le cadre de cette derni</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vision, certains termes ont </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">limin</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s car ils ne prenaient pas en compte la possibilit</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> pour les utilisateurs de faire des recherches combin</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">es, tout simplement comme pratique pour l''indexation de mots cl</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> combin</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s (ainsi, ont </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">limin</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s les mots cl</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s ''Loisirs et d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tente sous la r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">publique'' pour les indexer sous ''Loisirs et d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tente'' puis ''Seconde R</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">publique espagnole''). Cette r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vision implique une nouvelle indexation de tous les fragments d''entretiens des termes qui ont </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">limin</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s, favorisant ainsi l''utilisation de recherches combin</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">es par les utilisateurs.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">En juillet 2014, la troisi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">me version du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus comprend 78</span></span><span class="CharAttribute8"><span lang="FR"> </span></span><span class="CharAttribute8"><span lang="FR">01</span></span><span class="CharAttribute3"><span lang="FR">2 termes, dont 11</span></span><span class="CharAttribute8"><span lang="FR"> </span></span><span class="CharAttribute3"><span lang="FR">775 sont des descripteurs non-toponymiques (le projet est associ</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> la nomenclature officielle des 6 pays auxquels font r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">f</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rence les entretiens, de sorte que le nombre total de toponymes est tr</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">s </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">lev</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> m</span></span><span class="CharAttribute3"><span lang="FR">ê</span></span><span class="CharAttribute3"><span lang="FR">me si seule une infime partie de ceux-ci est utilis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e dans ces descripteurs). Ainsi, le noyau du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus est constitu</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> des descripteurs chronologiques, th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">matiques et onomastiques, ils repr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">sentent un nombre consid</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rable de mots cl</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> utiliser. Cette version, hors descripteurs toponymiques (les nomenclateurs) peut </span></span><span class="CharAttribute3"><span lang="FR">ê</span></span><span class="CharAttribute3"><span lang="FR">tre t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">l</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">charg</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e dans son int</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">gralit</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> ou partiellement dans ses versions alphab</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tique et hi</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rarchique. </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Le th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus est vivant, il est maintenu et r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">guli</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">rement </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> chaque indexation de projets. Avec ce vocabulaire contr</span></span><span class="CharAttribute3"><span lang="FR">ô</span></span><span class="CharAttribute3"><span lang="FR">l</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">, en juillet 2014, ont </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> cr</span></span><span class="CharAttribute3"><span lang="FR">éé</span></span><span class="CharAttribute3"><span lang="FR">s au total 10.056 fragments d</span></span><span class="CharAttribute3"><span lang="FR">’</span></span><span class="CharAttribute3"><span lang="FR">entretiens, auxquels sont venus s''ajouter 25</span></span><span class="CharAttribute8"><span lang="FR">.028</span></span><span class="CharAttribute3"><span lang="FR"> termes. Ces donn</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">es nous permettent </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">galement d''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">valuer le degr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> de classement d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">taill</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">, le ratio est d''environ 2,5 termes par fragment, ce point nous permet de d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">duire que la recherche combin</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> partir des termes du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus donnera des r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">sultats tr</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">s pr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cis lors des recherches lanc</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">es par les utilisateurs.</span></span></p> <p class="ParaAttribute1"> </p> <h3 class="ParaAttribute1"><span class="CharAttribute1"><span lang="FR">La structure du th</span></span><span class="CharAttribute1"><span lang="FR">é</span></span><span class="CharAttribute1"><span lang="FR">saurus</span></span></h3> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Le Th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus est organis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> en 4 grands domaines ou micro-disciplines qui r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">pondent </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> 4 questions : quand (descripteurs chronologiques), quoi (descripteurs th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">matiques), qui (descripteurs onomastiques) et o</span></span><span class="CharAttribute3"><span lang="FR">ù</span></span><span class="CharAttribute3"><span lang="FR">(descripteurs toponymiques).</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Les descripteurs chronologiques se rapportent </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> une limite dans le temps </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tablie par la loi sur le Memorial Democr</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">tic</span></span><span class="CharAttribute3"><span lang="FR"> </span></span><span class="CharAttribute3"><span lang="FR">: du 14/04/1931 au 20/03/1980. Cette limite dans le temps est parfois outrepass</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e du fait que l''histoire relat</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e dans les t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">moignages se situe en dehors de ce laps de temps. C''est pour cette raison que nous nous retrouvons avec des termes s''</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tant d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">roul</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s en dehors de cette fourchette (comme la </span></span><span class="CharAttribute3"><span lang="FR">«</span></span><span class="CharAttribute3"><span lang="FR">Dictature de Primo de Rivera</span></span><span class="CharAttribute3"><span lang="FR">»</span></span><span class="CharAttribute3"><span lang="FR"> ou le </span></span><span class="CharAttribute3"><span lang="FR">«</span></span><span class="CharAttribute3"><span lang="FR">Coup d</span></span><span class="CharAttribute3"><span lang="FR">’é</span></span><span class="CharAttribute3"><span lang="FR">tat de Tejero</span></span><span class="CharAttribute3"><span lang="FR">»</span></span><span class="CharAttribute3"><span lang="FR">). Dans cette premi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re micro-discipline, nous avons regroup</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> les p</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">riodes historiques et nous avons cr</span></span><span class="CharAttribute3"><span lang="FR">éé</span></span><span class="CharAttribute3"><span lang="FR"> deux blocs chronologiques distincts de ces p</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">riodes pour des raisons de coh</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rence</span></span><span class="CharAttribute3"><span lang="FR"> </span></span><span class="CharAttribute3"><span lang="FR">: nous avons cr</span></span><span class="CharAttribute3"><span lang="FR">éé</span></span><span class="CharAttribute3"><span lang="FR"> un bloc ayant pour titre </span></span><span class="CharAttribute3"><span lang="FR">«É</span></span><span class="CharAttribute3"><span lang="FR">v</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">nements internationaux</span></span><span class="CharAttribute3"><span lang="FR">»</span></span><span class="CharAttribute3"><span lang="FR"> r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">unissant tous les faits ayant pu avoir un rapport avec les faits relat</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s dans les t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">moignages mais qui ne se sont pas g</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ographiquement d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">roul</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s en Catalogne ou en Espagne (par exemple, le Concile Vatican II), puis nous avons regroup</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> sous l''appellation </span></span><span class="CharAttribute3"><span lang="FR">«</span></span><span class="CharAttribute3"><span lang="FR">Exil 1939</span></span><span class="CharAttribute3"><span lang="FR">»</span></span><span class="CharAttribute3"><span lang="FR"> tous les termes qui, d''un point de vue s</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">mantique pr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">sentent un lien mais qui sont g</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ographiquement ext</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rieurs aux grandes p</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">riodes historiques. Le classement des descripteurs chronologiques dans l''affichage hi</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rarchique est fait en fonction de la chronologie et non par ordre alphab</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tique. </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Les descripteurs th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">matiques conservent une structure identique </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> celle du Th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus de l''Histoire de la Catalogne de l''UAB, un nouveau groupe a </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> ajout</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> sous le nom de </span></span><span class="CharAttribute3"><span lang="FR">«</span></span><span class="CharAttribute3"><span lang="FR">Guerre et cons</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">quences de la guerre</span></span><span class="CharAttribute3"><span lang="FR">»</span></span><span class="CharAttribute3"><span lang="FR">, au vu du caract</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re sp</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cifique de nombreux entretiens, qui constituent des t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">moignages li</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> un fait de guerre sans pouvoir </span></span><span class="CharAttribute3"><span lang="FR">ê</span></span><span class="CharAttribute3"><span lang="FR">tre rattach</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s aux descripteurs chronologiques, parall</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">lement ils ont </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cart</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s du groupe s</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">mantique </span></span><span class="CharAttribute3"><span lang="FR">«</span></span><span class="CharAttribute3"><span lang="FR">D</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">fense et ordre public</span></span><span class="CharAttribute3"><span lang="FR">»</span></span><span class="CharAttribute3"><span lang="FR">, avec les termes d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">pendants du concept de </span></span><span class="CharAttribute3"><span lang="FR">«</span></span><span class="CharAttribute3"><span lang="FR">Guerre</span></span><span class="CharAttribute3"><span lang="FR">»</span></span><span class="CharAttribute3"><span lang="FR">. </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Les descripteurs onomastiques constituent une micro-discipline nouvelle et distincte du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus m</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re, celui de l''UAB, la cr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ation de ce bloc a </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cid</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e du fait que les entretiens contiennent de nombreuses r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">f</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rences </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> des personnalit</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s publiques mais surtout, ils constituent des t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">moignages en lien avec des lieux de m</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">moire, en particulier les centres de privation de libert</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Enfin les descripteurs toponymiques ont </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> inclus au th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus, les gestionnaires du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">taient sur ce point conscients du volume qu''allait entra</span></span><span class="CharAttribute3"><span lang="FR">î</span></span><span class="CharAttribute3"><span lang="FR">ner l''introduction de nomenclateurs de pays, mais ils ont </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">valu</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> que nombres de t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">moignages relat</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s dans les entretiens faisaient r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">f</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rence </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> des lieux qui pouvaient pr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">senter un int</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">r</span></span><span class="CharAttribute3"><span lang="FR">ê</span></span><span class="CharAttribute3"><span lang="FR">t pour les utilisateurs au moment de la collecte d''informations, comme les villages ayant accueilli des exil</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s. </span></span></p> <h3 class="ParaAttribute1"> </h3> <h3 class="ParaAttribute1"><span class="CharAttribute1"><span lang="FR">Moyens humains</span></span></h3> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Le Th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus du Memorial Democr</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">tic s''appuie sur le Th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus de l</span></span><span class="CharAttribute3"><span lang="FR">’</span></span><span class="CharAttribute3"><span lang="FR">Histoire de la Catalogne de l''UAB. Cette base et sa premi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re adaptation (2009-2010) sont l''</span></span><span class="CharAttribute3"><span lang="FR">œ</span></span><span class="CharAttribute3"><span lang="FR">uvre d</span></span><span class="CharAttribute3"><span lang="FR">’</span></span><span class="CharAttribute3"><span lang="FR">Anna Pascual Bosser, qui a </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> dirig</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e par Maribel Cuadrado et N</span></span><span class="CharAttribute3"><span lang="FR">ú</span></span><span class="CharAttribute3"><span lang="FR">ria Rius (</span></span><span lang="FR"><a href="http://sct.uab.cat/sibhilla/"><span class="CharAttribute6">SIBHIL</span><span class="CharAttribute6">·</span><span class="CharAttribute6">LA</span></a></span><span class="CharAttribute3"><span lang="FR">-UAB). </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">L</span></span><span class="CharAttribute3"><span lang="FR">’é</span></span><span class="CharAttribute3"><span lang="FR">largissement du nombre des personnages publics de l</span></span><span class="CharAttribute3"><span lang="FR">’</span></span><span class="CharAttribute3"><span lang="FR">ann</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e 2012 est le fruit du travail de Laura Molinos. La r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vision compl</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">te du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus men</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e sur la p</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">riode 2013-2014, </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> partir de l''indexation de nouveaux contenus, a </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">alis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e par Anna Pascual Bosser et Joan Palah</span></span><span class="CharAttribute3"><span lang="FR">í</span></span><span class="CharAttribute3"><span lang="FR">. </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">La coordination et la r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vision sont le fruit du travail de Gerard Corbella, responsable de la Banque de donn</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">es du Memorial. Lors de la r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">vision des termes historiques, plusieurs historiens du Memorial Democr</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">tic et de l''UAB ont particip</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> de fa</span></span><span class="CharAttribute3"><span lang="FR">ç</span></span><span class="CharAttribute3"><span lang="FR">on ponctuelle. </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute1"><span lang="FR">Norme ISO et th</span></span><span class="CharAttribute1"><span lang="FR">é</span></span><span class="CharAttribute1"><span lang="FR">saurus multilingue</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">De la premi</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> la derni</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">re version du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus, la norme ISO 2788:1986 (UNE 50-106-90) a </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> prise en compte, pour la cr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ation de th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus monolingues. Jusqu''</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> ce que le projet soit propos</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> pour </span></span><span class="CharAttribute3"><span lang="FR">ê</span></span><span class="CharAttribute3"><span lang="FR">tre consultable en 4 langues, la plateforme </span></span><span lang="FR"><a href="http://www.fmomo.org/dedalo"><span class="CharAttribute6">D</span><span class="CharAttribute6">é</span><span class="CharAttribute6">dalo</span></a></span><span class="CharAttribute3"><span lang="FR"> a pris en compte la norme ISO 5964 (UNE 50-125), pour les th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR', '<h2 class="ParaAttribute0" style="text-align: left;"><strong><span class="CharAttribute1"><span lang="FR"><span class="CharAttribute3"><span lang="FR">Th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus</span></span> du Memorial Democràtic</span></span></strong></h2> <h3 class="ParaAttribute1"><strong><span class="CharAttribute1"><span lang="FR">Origine</span></span></strong></h3> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Le Th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus du Memorial Democr</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">tic est un vocabulaire contr</span></span><span class="CharAttribute3"><span lang="FR">ô</span></span><span class="CharAttribute3"><span lang="FR">l</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> sur l''histoire contemporaine de la Catalogne, con</span></span><span class="CharAttribute3"><span lang="FR">ç</span></span><span class="CharAttribute3"><span lang="FR">u sur mesure pour le projet de la Banque Audiovisuel de T</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">moignages,  l</span></span><span class="CharAttribute3"><span lang="FR">’</span></span><span class="CharAttribute3"><span lang="FR">archive d</span></span><span class="CharAttribute3"><span lang="FR">’</span></span><span class="CharAttribute3"><span lang="FR">histoire orale de cette institution.</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Pour sa cr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ation,  on est parti du </span></span><span lang="FR"><a href="http://www.vocabularyserver.com/historia_catalunya/"><span class="CharAttribute6">Th</span><span class="CharAttribute6">é</span><span class="CharAttribute6">saurus d</span><span class="CharAttribute6">’</span><span class="CharAttribute6">Histoire de Catalogne</span></a></span><span class="CharAttribute3"><span lang="FR"> du Service d</span></span><span class="CharAttribute3"><span lang="FR">’</span></span><span class="CharAttribute3"><span lang="FR">Information Bibliographique et de Documentation d''Histoire,  Langue,  Litt</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rature et Art de Catalogne de l''Universit</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> Autonome de Barcelone (</span></span><span lang="FR"><a href="http://sct.uab.cat/sibhilla/"><span class="CharAttribute6">SIBHIL</span><span class="CharAttribute6">·</span><span class="CharAttribute6">LA</span></a></span><span class="CharAttribute3"><span lang="FR">-UAB). </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">La d</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cision de cr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">er un th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus sp</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">cifique part du constat de l''absence totale de langages documentaires adapt</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s au cadre historique dont s''occupe le Memorial Democr</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">tic.</span></span></p> <h3 class="ParaAttribute1"><strong><span class="CharAttribute1"><span lang="FR">La structure du th</span></span><span class="CharAttribute1"><span lang="FR">é</span></span><span class="CharAttribute1"><span lang="FR">saurus</span></span></strong></h3> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Le Th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus est organis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> en 4 grands domaines ou micro-disciplines qui r</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">pondent </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> 4 questions : quand (descripteurs chronologiques), quoi (descripteurs th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">matiques), qui (descripteurs onomastiques) et o</span></span><span class="CharAttribute3"><span lang="FR">ù</span></span><span class="CharAttribute3"><span lang="FR">(descripteurs toponymiques).</span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Les descripteurs chronologiques se rapportent </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> une limite dans le temps </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tablie par la loi sur le Memorial Democr</span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR">tic</span></span><span class="CharAttribute3"><span lang="FR"> </span></span><span class="CharAttribute3"><span lang="FR">: du 14/04/1931 au 20/03/1980. Cette limite dans le temps est parfois outrepass</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e du fait que l''histoire relat</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e dans les t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">moignages se situe en dehors de ce laps de temps. </span></span></p> <h3 class="ParaAttribute1"><strong><span class="CharAttribute1"><span lang="FR">Publication et affichage</span></span></strong></h3> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">La version compl</span></span><span class="CharAttribute3"><span lang="FR">è</span></span><span class="CharAttribute3"><span lang="FR">te du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus n''a pas </span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> publi</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e sur papier mais elle est mise </span></span><span class="CharAttribute3"><span lang="FR">à</span></span><span class="CharAttribute3"><span lang="FR"> disposition des usagers, ceux-ci peuvent la t</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">l</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">charger dans son int</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">gralit</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> ou s</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">par</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">ment en version alphab</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">tique ou hi</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rarchique. </span></span></p> <p class="ParaAttribute1"><span class="CharAttribute3"><span lang="FR">Il existe n</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">anmoins une autre fa</span></span><span class="CharAttribute3"><span lang="FR">ç</span></span><span class="CharAttribute3"><span lang="FR">on d''afficher le th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus, li</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">e aux contenus, ce qui nous permet de faire des recherches s</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">mantiques sur Internet. Il s''agit d''une pr</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">sentation hi</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">rarchique, sur laquelle sont seulement visibles les 1776 termes utilis</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">s du th</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">saurus, avec les termes g</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">n</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR">riques auxquels est associ</span></span><span class="CharAttribute3"><span lang="FR">é</span></span><span class="CharAttribute3"><span lang="FR"> le descripteur. </span></span></p> <p class="ParaAttribute1"><strong><span lang="FR"> </span></strong></p>', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `tesauro_presentacion_documento`
--

CREATE TABLE IF NOT EXISTS `tesauro_presentacion_documento` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `version` text COLLATE utf8_unicode_ci COMMENT 'Versión - mdcat281',
  `fecha` text COLLATE utf8_unicode_ci COMMENT 'Fecha - mdcat276',
  `html` text COLLATE utf8_unicode_ci COMMENT 'Documento HTML - mdcat289',
  `titulo` text COLLATE utf8_unicode_ci COMMENT 'Título - mdcat277',
  `tesauro_presentacion_logo` text COLLATE utf8_unicode_ci COMMENT 'Logotipo - mdcat275',
  `doc_pdf` text COLLATE utf8_unicode_ci COMMENT 'Documento de presentación - mdcat288',
  `publicacion` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat274'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `tesauro_presentacion_documento`
--

INSERT INTO `tesauro_presentacion_documento` (`id`, `id_matrix`, `lang`, `version`, `fecha`, `html`, `titulo`, `tesauro_presentacion_logo`, `doc_pdf`, `publicacion`) VALUES
(1, 8, 'lg-cat', 'Versió 3.0', 'Thursday12-2014-07-31T00:00:00+02:00am31', 'mdcat289-9', 'Tesaurus del Memorial Democràtic.', '["9"]', 'mdcat288-1', 'si'),
(2, 8, 'lg-spa', 'Versió 3.0', 'Thursday12-00pam', 'mdcat289-9', 'Tesauro del Memorial Democràtic', '["9"]', 'mdcat288-7', 'si'),
(3, 8, 'lg-eng', 'Versió 3.0', 'Thursday12-Europe/Madrid712', 'mdcat289-9', 'Tesaurus del Memorial Democràtic', '["9"]', 'mdcat288-8', 'si'),
(4, 8, 'lg-fra', 'Versió 3.0', 'Thursday12-fThu, 31 Jul 2014 00:00:00 +0200am', 'mdcat289-9', 'Tesaurus del Memorial Democràtic', '["9"]', 'mdcat288-9', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `tesauro_presentacion_logo`
--

CREATE TABLE IF NOT EXISTS `tesauro_presentacion_logo` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `logo` text COLLATE utf8_unicode_ci COMMENT 'Imágen - mdcat269',
  `logo_pie` text COLLATE utf8_unicode_ci COMMENT 'Pié de foto - mdcat270'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `tesauro_presentacion_logo`
--

INSERT INTO `tesauro_presentacion_logo` (`id`, `id_matrix`, `lang`, `logo`, `logo_pie`) VALUES
(1, 9, 'lg-cat', 'mdcat269-1', ''),
(2, 9, 'lg-spa', 'mdcat269-1', ''),
(3, 9, 'lg-eng', 'mdcat269-1', ''),
(4, 9, 'lg-fra', 'mdcat269-1', '');

-- --------------------------------------------------------

--
-- Table structure for table `titulos_busquedas`
--

CREATE TABLE IF NOT EXISTS `titulos_busquedas` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `busqueda_semantica_simple` text COLLATE utf8_unicode_ci COMMENT 'Búsqueda semántica simple - mdcat56',
  `busqueda_acumulativa` text COLLATE utf8_unicode_ci COMMENT 'Búsqueda acumulativa - mdcat64',
  `busqueda_libre` text COLLATE utf8_unicode_ci COMMENT 'Búsqueda libre - mdcat58',
  `busqueda_semantica_combinada` text COLLATE utf8_unicode_ci COMMENT 'Búsqueda semántica combinada - mdcat60',
  `busqueda_avanzada` text COLLATE utf8_unicode_ci COMMENT 'Búsqueda avanzada - mdcat62',
  `publicacion_busqueda_semantica_combinada` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat59',
  `publicacion_busqueda_avanzada` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat61',
  `publicacion_busqueda_libre` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat57',
  `publicacion_busqueda_acumulativa` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat63',
  `publicacion_busqueda_semantica_simple` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat55'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `titulos_busquedas`
--

INSERT INTO `titulos_busquedas` (`id`, `id_matrix`, `lang`, `busqueda_semantica_simple`, `busqueda_acumulativa`, `busqueda_libre`, `busqueda_semantica_combinada`, `busqueda_avanzada`, `publicacion_busqueda_semantica_combinada`, `publicacion_busqueda_avanzada`, `publicacion_busqueda_libre`, `publicacion_busqueda_acumulativa`, `publicacion_busqueda_semantica_simple`) VALUES
(1, 5, 'lg-cat', '<h2 style="text-align: left;">Cerca semàntica simple</h2> <p>Mitjançant una navegació jeràrquica a partir del tesaurus del Memorial Democràtic, podeu trobar els fragments de les entrevistes que han estat indexats amb un terme concret. Els termes corresponen a conceptes que descriuen el contingut d’un fragment d’una entrevista.</p> <p>Els termes que van acompanyats de la icona d’un fotograma contenen fragments indexats. Aquest tipus de cerca permet veure els continguts lligats a un concepte, que són descrits per una paraula clau. Per a cerques més precises, utilitzeu la cerca semàntica combinada.</p>', '<h2 style="text-align: left;">Cerca acumulativa</h2> <p>A partir de la icona de suma podeu guardar la vostra pròpia col·lecció de testimonis a partir de les paraules clau que seleccioneu.</p>', '<h2 style="text-align: left;">Cerca lliure</h2> <p>Introduïu la paraula que busqueu i els resultats us conduiran als fragments de les transcripcions, on apareixerà la paraula buscada. També podeu utilitzar operadors per afinar la cerca (vegeu la icona d’interrogant).</p>', '<h2 style="text-align: left;">Cerca semàntica combinada</h2> <p>Mitjançant una navegació jeràrquica a partir del tesaurus del Memorial Democràtic, podreu trobar els fragments de les entrevistes que han estat indexats amb un terme concret. Els termes corresponen a conceptes que descriuen el contingut d’un fragment d’una entrevista.</p> <p>Els termes utilitzats en la indexació van acompanyats d’una icona de suma. A partir de la selecció d’un primer terme podeu visualitzar tots els fragments creats amb el concepte seleccionat, i els altres termes que hi combinen. Aquesta navegació permet obtenir resultats molt precisos, mitjançant la combinació de conceptes.</p>', '<h2 style="text-align: left;">Cerca avançada</h2> <p>Mitjançant la selecció o combinació de camps de la base de dades que alimenta aquest web podeu seleccionar les entrevistes que us interessen segons les vostres preferències. Els resultats mostren un resum de l’entrevista i totes les paraules clau utilitzades per indexar-ne els continguts.</p>', 'si', 'si', 'si', 'si', 'si'),
(2, 5, 'lg-spa', '<h2 style="text-align: left;">Búsqueda semántica simple</h2> <p>Mediante una navegación jerárquica a partir del tesauro del Memorial Democràtic, se pueden encontrar los fragmentos de las entrevistas que han sido indexados con un término concreto. Los términos corresponden a conceptos que describen el contenido de un fragmento de una entrevista.</p> <p>Los términos que van acompañados del icono de un fotograma contienen fragmentos indexados. Este tipo de búsqueda permite ver los contenidos ligados a un concepto, que son descritos por una palabra clave. Para búsquedas más precisas, utilícese la búsqueda semántica combinada.</p>', '<h2 style="text-align: left;">Búsqueda acumulativa</h2> <p>A partir del icono de suma es posible guardar la propia colección de testimonios a partir de las palabras clave que se seleccionan.</p>', '<h2 style="text-align: left;">Busqueda libre</h2> <p>Introducir la palabra que se busca, y los resultados conducirán a los fragmentos de las transcripciones, donde aparecerá la palabra buscada. También se pueden utilizar operadores para afinar la búsqueda (véase el icono de interrogante).</p>', '<h2 style="text-align: left;">Búsqueda semántica combinada</h2> <p>Mediante una navegación jerárquica a partir del tesauro del Memorial Democràtic, se pueden encontrar los fragmentos de las entrevistas que han sido indexados con un término concreto. Los términos corresponden a conceptos que describen el contenido de un fragmento de una entrevista.</p> <p>Los términos utilizados en la indexación van acompañados de un icono de suma. A partir de la selección de un primer término se pueden visualizar todos los fragmentos creados con el concepto seleccionado, y los otros términos que combinan. Esta navegación permite obtener resultados muy precisos, mediante la combinación de conceptos.</p>', '<h2 style="text-align: left;">Búsqueda avanzada</h2> <p>Mediante la selección o combinación de campos de la base de datos que alimenta esta web se pueden seleccionar las entrevistas de interés según las preferencias particulares. Los resultados muestran un resumen de la entrevista y todas las palabras clave utilizadas para indexar los contenidos.</p>', 'si', 'si', 'si', 'si', 'si'),
(3, 5, 'lg-eng', '<h2 style="text-align: left;">Simple semantic search</h2> <p>Through hierarchical navigation based on the thesaurus of Democratic Memory, you will find interview fragments that have been indexed using a specific term. The terms correspond to concepts that describe the content of an interview fragment.</p> <p>The terms that have a frame icon contain indexed fragments. This search method allows the content related to a concept that is described by a key word, to be displayed. For more precise searches, use the combined semantic search.</p>', '<h2 style="text-align: left;">Accumulative search</h2> <p>Using the addition icon, you can save your collection of testimonies based on the key words selected.</p>', '<h2 style="text-align: left;">Free text search</h2> <p>Introduce the word you wish to search for and the results will show fragments of the transcriptions in which the word appears. You can also use search operators to refine your search (see the ? icon).</p>', '<h2>Combined semantic search</h2> <p>Through hierarchical navigation based on the thesaurus of Democratic Memory, you will find interview fragments that have been indexed using a specific term. The terms correspond to concepts that describe the content of an interview fragment.</p> <p>The terms used in the indexing have an addition icon. Based on the selection of a first term, you can visualise all of the fragments created with the selected concept, and the other terms they are combined with. This navigation method allows more precise results to be obtained, using a combination of concepts.</p>', '<h2 style="text-align: left;">Advanced search</h2> <p>By the selection or combination of fields in the database that feeds this website, you can select interviews of interest according to preferences. The results show a summary of the interview and all of the key words used to index its content.</p>', 'si', 'si', 'si', 'si', 'si'),
(4, 5, 'lg-fra', '<h2 style="text-align: left;">Recherche sémantique simple </h2> <p>À travers une navigation hiérarchique, à partir du thésaurus du Mémorial Démocratique, vous pouvez trouver les fragments des entretiens qui ont été indexés à l''aide d''un terme concret. Les termes correspondent à des concepts qui décrivent le contenu d''un fragment d''un entretien.</p> <p>Les termes qui sont assortis de l''icône d''un photogramme contiennent des fragments indexés. Cette forme de recherche permet de voir les contenus associés à un concept, et qui sont décrits par un mot-clé. Pour des recherches plus précises, veuillez utiliser la recherche sémantique combinée. </p>', '<h2 style="text-align: left;">Recherche cumulative </h2> <p>À partir de l''icône de somme, vous pouvez garder votre propre recueil de témoignages à partir des mots-clés que vous sélectionnez.</p>', '<h2 style="text-align: left;">Recherche libre </h2> <p>Saisissez le mot que vous recherchez et les résultats vous conduiront aux fragments des transcriptions, où apparaîtra le mot recherché. Vous pouvez utiliser également des opérateurs afin d''affiner la recherche (voir l''icône des interrogations). </p>', '<h2 style="text-align: left;">Recherche sémantique combinée </h2> <p>À travers une navigation hiérarchique à partir du thésaurus du Mémorial démocratique, vous pouvez trouver les fragments des entretiens qui ont été indexés à l''aide d''un terme concret. Les termes correspondent à des concepts qui décrivent le contenu d''un fragment d''un entretien.</p> <p>Les termes utilisés dans l''indexation sont accompagnés d''une icône de somme. À partir de la sélection d''un premier terme, vous pouvez visualiser tous les fragments créés avec le concept sélectionné, et les autres termes combinés. Cette navigation permet d''obtenir des résultats plus précis, par combinaison de concepts. </p>', '<h2 style="text-align: left;">Recherche avancée </h2> <p>Par la sélection ou la combinaison de champs de la base de données qui alimente ce site, vous pouvez sélectionner les entretiens qui vous intéressent conformément à vos préférences. Les résultats montrent un résumé de l''entretien et tous les mots-clés utilisés pour indexer ses contenus. </p>', 'si', 'si', 'si', 'si', 'si');

-- --------------------------------------------------------

--
-- Table structure for table `titulos_visualizaciones`
--

CREATE TABLE IF NOT EXISTS `titulos_visualizaciones` (
  `id` int(12) NOT NULL,
  `id_matrix` int(12) unsigned DEFAULT NULL,
  `lang` varchar(8) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Campo creado automáticamente para guardar el idioma (sin correspondencia en estructura)',
  `presentacion_cronologica` text COLLATE utf8_unicode_ci COMMENT 'Presentación de cronológia - mdcat76',
  `presentacion_rostros` text COLLATE utf8_unicode_ci COMMENT 'Presentación por rostros - mdcat82',
  `presentacion_contextual` text COLLATE utf8_unicode_ci COMMENT 'Presentación contextual - mdcat80',
  `presentacion_geografica` text COLLATE utf8_unicode_ci COMMENT 'Presentación de geográfica - mdcat78',
  `publicacion_cronologica` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat75',
  `publicacion_geografica` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat77',
  `publicacion_contextual` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat79',
  `publicacion_rostros` enum('si','no') COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Publicación - mdcat81'
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci PACK_KEYS=0 COMMENT='Tabla autogenerada en Dédalo4 para difusión';

--
-- Dumping data for table `titulos_visualizaciones`
--

INSERT INTO `titulos_visualizaciones` (`id`, `id_matrix`, `lang`, `presentacion_cronologica`, `presentacion_rostros`, `presentacion_contextual`, `presentacion_geografica`, `publicacion_cronologica`, `publicacion_geografica`, `publicacion_contextual`, `publicacion_rostros`) VALUES
(1, 6, 'lg-cat', '<h2 style="text-align: left;">Visualització cronològica</h2> <p>Podeu navegar des dels períodes històrics generals fins a esdeveniments concrets del segle xx a Catalunya, a Espanya i al món, explicats pels testimonis que configuren aquest arxiu. La navegació és cronològica (d’esquerra a dreta) i jeràrquica (de dalt a baix).</p>', '<h2 style="text-align: left;">Visualització persones</h2> <p>Accediu, a partir del fotograma de l’entrevista, al testimoni que us interessi. </p>', '<h2 style="text-align: left;">Visualització contextual</h2> <p>Aquesta forma de visualització permet navegar a través dels termes que integren el tesaurus del Memorial Democràtic, de manera que es vegin les relacions conceptuals que estableixen les paraules clau d’aquest vocabulari controlat, i accedir als continguts de les entrevistes.</p>', '<h2 style="text-align: left;">Visualització geogràfica</h2> <p>Navegant sobre un mapa del món trobareu testimonis que relaten les seues vivències sobre un lloc determinat. Tant poden ser poblacions de naixement i de residència dels entrevistats com llocs on han viscut experiències concretes (presons, camps de concentració, destinacions dels exiliats...).</p>', 'si', 'si', 'si', 'si'),
(2, 6, 'lg-spa', '<h2 style="text-align: left;">Visualización cronológica</h2> <p>Permite navegar desde los periodos históricos generales hasta acontecimientos concretos del siglo xx en Cataluña, en España y en el mundo, explicados por los testimonios que configuran este archivo. La navegación es cronológica (de izquierda a derecha) y jerárquica (de arriba abajo).</p>', '<h2 style="text-align: left;">Visualización personas</h2> <p>Se puede acceder, a partir del fotograma de la entrevista, al testimonio de interés. </p>', '<h2 style="text-align: left;">Visualización contextual</h2> <p>Esta forma de visualización permite navegar a través de los términos que integran el tesauro del Memorial Democràtic, de forma que se vean las relaciones conceptuales que establecen las palabras clave de este vocabulario controlado, y acceder a los contenidos de las entrevistas.</p>', '<h2 style="text-align: left;">Visualización geográfica</h2> <p>Navegando sobre un mapa del mundo, se encontrarán testimonios que relatan sus vivencias acerca de un lugar determinado. Pueden ser tanto poblaciones de nacimiento y de residencia de los entrevistados como lugares donde han vivido experiencias concretas (cárceles, campos de concentración, destinos de los exiliados...).</p>', 'si', 'si', 'si', 'si'),
(3, 6, 'lg-eng', '<h2 style="text-align: left;">Chronological display</h2> <p>You can browse through general historic periods and specific events of the 20th century in Catalonia, Spain and the world, described by the testimonies included in this archive. Navigation is chronological (from left to right) and hierarchical (from top to bottom).</p>', '<h2 style="text-align: left;">People display</h2> <p>You can access the testimony you are interested in based on the frame of the interview. </p>', '<h2 style="text-align: left;">Contextual display</h2> <p>This display option allows you to browse through the terms of the thesaurus of Democratic Memory, so that the conceptual relations established by the key words of this controlled vocabulary can be viewed, and the content of the interviews accessed.</p>', '<h2 style="text-align: left;">Geographic display</h2> <p>Browsing using a world map, you will find testimonies that describe experiences in specific locations. These can include towns of origin and residency of the interviewees as well as places where they have had specific experiences (prisons, concentration camps, countries of exile...).</p>', 'si', 'si', 'si', 'si'),
(4, 6, 'lg-fra', '<h2 style="text-align: left;">Visualisation chronologique</h2> <p>Vous pouvez naviguer des périodes historiques générales à des événements concrets du XXe siècle en Catalogne, en Espagne et dans le reste du monde, expliquées par les témoignages qui forment ce fichier. La navigation est chronologique (de gauche à droite) et hiérarchique (de haut en bas). </p>', '<h2 style="text-align: left;">Visualisation personnes</h2> <p>Accédez à partir du photogramme à l''entretien, au témoignage qui vous intéresse. </p>', '<h2 style="text-align: left;">Visualisation contextuelle</h2> <p>Cette forme de visualisation permet de naviguer à travers des termes du thésaurus du Mémorial Démocratique, de manière à voir les relations conceptuelles qu''établissent les mots-clés de ce vocabulaire contrôlé, et accéder aux contenus des entretiens. </p>', '<h2 style="text-align: left;">Visualisation géographique</h2> <p>En vous déplaçant sur une carte du monde, vous trouverez des témoins qui partageront leur récit sur un lieu déterminé. Il peut s''agir de lieux de naissance et de résidence de ces personnes, comme de lieux où ils ont vécu des expériences concrètes (prisons, camps de concentration, destination des exilés...). </p>', 'si', 'si', 'si', 'si');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articulos_proyecto`
--
ALTER TABLE `articulos_proyecto`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `articulos_proyecto_portal` (`articulos_proyecto_portal`);

--
-- Indexes for table `articulos_proyecto_portal`
--
ALTER TABLE `articulos_proyecto_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `fecha` (`fecha`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `comentario` (`comentario`), ADD FULLTEXT KEY `version` (`version`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`), ADD FULLTEXT KEY `weblink` (`weblink`);

--
-- Indexes for table `concepcion_proyecto`
--
ALTER TABLE `concepcion_proyecto`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `concepcion_proyecto_portal` (`concepcion_proyecto_portal`);

--
-- Indexes for table `concepcion_proyecto_portal`
--
ALTER TABLE `concepcion_proyecto_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `fecha` (`fecha`), ADD FULLTEXT KEY `version` (`version`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`), ADD FULLTEXT KEY `weblink` (`weblink`);

--
-- Indexes for table `creditos`
--
ALTER TABLE `creditos`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `creditos_personas` (`creditos_personas`);

--
-- Indexes for table `creditos_personas`
--
ALTER TABLE `creditos_personas`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `apellidos` (`apellidos`), ADD FULLTEXT KEY `nombre` (`nombre`), ADD FULLTEXT KEY `tipologia` (`tipologia`), ADD FULLTEXT KEY `creditos_personas_imagen` (`creditos_personas_imagen`);

--
-- Indexes for table `creditos_personas_imagen`
--
ALTER TABLE `creditos_personas_imagen`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD FULLTEXT KEY `url` (`url`), ADD FULLTEXT KEY `pie` (`pie`);

--
-- Indexes for table `documentales`
--
ALTER TABLE `documentales`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `documentales_portal` (`documentales_portal`), ADD FULLTEXT KEY `presentacion` (`presentacion`);

--
-- Indexes for table `documentales_portal`
--
ALTER TABLE `documentales_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `descripcion` (`descripcion`), ADD FULLTEXT KEY `video` (`video`), ADD FULLTEXT KEY `autor` (`autor`), ADD FULLTEXT KEY `observaciones` (`observaciones`), ADD FULLTEXT KEY `titulo` (`titulo`);

--
-- Indexes for table `enlaces_archivos_testimonios`
--
ALTER TABLE `enlaces_archivos_testimonios`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `enlaces_archivos_testimonios_portal` (`enlaces_archivos_testimonios_portal`);

--
-- Indexes for table `enlaces_archivos_testimonios_portal`
--
ALTER TABLE `enlaces_archivos_testimonios_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `weblink` (`weblink`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `comentario` (`comentario`), ADD FULLTEXT KEY `agrupacion` (`agrupacion`), ADD FULLTEXT KEY `agrupacion_label` (`agrupacion_label`), ADD FULLTEXT KEY `categoria` (`categoria`), ADD FULLTEXT KEY `categoria_label` (`categoria_label`);

--
-- Indexes for table `enlaces_fuentes_orales`
--
ALTER TABLE `enlaces_fuentes_orales`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `enlaces_fuentes_orales_portal` (`enlaces_fuentes_orales_portal`), ADD FULLTEXT KEY `presentacion` (`presentacion`);

--
-- Indexes for table `enlaces_fuentes_orales_portal`
--
ALTER TABLE `enlaces_fuentes_orales_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `weblink` (`weblink`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `comentario` (`comentario`), ADD FULLTEXT KEY `agrupacion_label` (`agrupacion_label`), ADD FULLTEXT KEY `agrupacion` (`agrupacion`), ADD FULLTEXT KEY `categoria` (`categoria`), ADD FULLTEXT KEY `categoria_label` (`categoria_label`);

--
-- Indexes for table `entrevistas_expertos`
--
ALTER TABLE `entrevistas_expertos`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `entrevistas_expertos_personas` (`entrevistas_expertos_personas`);

--
-- Indexes for table `entrevistas_expertos_personas`
--
ALTER TABLE `entrevistas_expertos_personas`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `video` (`video`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `subtitulado` (`subtitulado`);

--
-- Indexes for table `exposiciones_virtuales`
--
ALTER TABLE `exposiciones_virtuales`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `exposiciones_virtuales_portal` (`exposiciones_virtuales_portal`);

--
-- Indexes for table `exposiciones_virtuales_portal`
--
ALTER TABLE `exposiciones_virtuales_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `comentario` (`comentario`), ADD FULLTEXT KEY `weblink` (`weblink`);

--
-- Indexes for table `formularios`
--
ALTER TABLE `formularios`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `formularios_precios` (`formularios_precios`);

--
-- Indexes for table `formularios_precios`
--
ALTER TABLE `formularios_precios`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `fecha` (`fecha`), ADD FULLTEXT KEY `version` (`version`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`);

--
-- Indexes for table `gestion_ho`
--
ALTER TABLE `gestion_ho`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `gestion_ho_portal` (`gestion_ho_portal`);

--
-- Indexes for table `gestion_ho_portal`
--
ALTER TABLE `gestion_ho_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `comentario` (`comentario`), ADD FULLTEXT KEY `fecha` (`fecha`), ADD FULLTEXT KEY `version` (`version`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`), ADD FULLTEXT KEY `weblink` (`weblink`);

--
-- Indexes for table `info_legal`
--
ALTER TABLE `info_legal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `info_legal_doc` (`info_legal_doc`), ADD FULLTEXT KEY `intro` (`intro`);

--
-- Indexes for table `info_legal_doc`
--
ALTER TABLE `info_legal_doc`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `Comentario` (`Comentario`), ADD FULLTEXT KEY `html` (`html`), ADD FULLTEXT KEY `fecha` (`fecha`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`);

--
-- Indexes for table `listado_entrevistados`
--
ALTER TABLE `listado_entrevistados`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `listado_entrevistados_portal` (`listado_entrevistados_portal`), ADD FULLTEXT KEY `publicacion` (`publicacion`);

--
-- Indexes for table `listado_entrevistados_logo`
--
ALTER TABLE `listado_entrevistados_logo`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD FULLTEXT KEY `logo_pie` (`logo_pie`), ADD FULLTEXT KEY `logo` (`logo`);

--
-- Indexes for table `listado_entrevistados_portal`
--
ALTER TABLE `listado_entrevistados_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `fecha` (`fecha`), ADD FULLTEXT KEY `listado_entrevistados_logo` (`listado_entrevistados_logo`), ADD FULLTEXT KEY `html` (`html`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `version` (`version`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`);

--
-- Indexes for table `listado_proyectos`
--
ALTER TABLE `listado_proyectos`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `listado_proyectos_portal` (`listado_proyectos_portal`), ADD FULLTEXT KEY `presentacion` (`presentacion`);

--
-- Indexes for table `listado_proyectos_logo`
--
ALTER TABLE `listado_proyectos_logo`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD FULLTEXT KEY `logo` (`logo`), ADD FULLTEXT KEY `logo_pie` (`logo_pie`);

--
-- Indexes for table `listado_proyectos_portal`
--
ALTER TABLE `listado_proyectos_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `version` (`version`), ADD FULLTEXT KEY `fecha` (`fecha`), ADD FULLTEXT KEY `html` (`html`), ADD FULLTEXT KEY `listado_proyectos_logo` (`listado_proyectos_logo`);

--
-- Indexes for table `listado_resumen_entrevistas`
--
ALTER TABLE `listado_resumen_entrevistas`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `listado_resumen_entrevistas_portal` (`listado_resumen_entrevistas_portal`);

--
-- Indexes for table `listado_resumen_entrevistas_logo`
--
ALTER TABLE `listado_resumen_entrevistas_logo`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD FULLTEXT KEY `logo_pie` (`logo_pie`), ADD FULLTEXT KEY `logo` (`logo`);

--
-- Indexes for table `listado_resumen_entrevistas_portal`
--
ALTER TABLE `listado_resumen_entrevistas_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `html` (`html`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`), ADD FULLTEXT KEY `listado_resumen_entrevistas_logo` (`listado_resumen_entrevistas_logo`), ADD FULLTEXT KEY `fecha` (`fecha`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `version` (`version`);

--
-- Indexes for table `protocolos_investigacion`
--
ALTER TABLE `protocolos_investigacion`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `protocolos_investigacion_portal` (`protocolos_investigacion_portal`);

--
-- Indexes for table `protocolos_investigacion_portal`
--
ALTER TABLE `protocolos_investigacion_portal`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `weblink` (`weblink`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `comentario` (`comentario`), ADD FULLTEXT KEY `version` (`version`), ADD FULLTEXT KEY `fecha` (`fecha`);

--
-- Indexes for table `proyecto`
--
ALTER TABLE `proyecto`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `proyecto_fotografias` (`proyecto_fotografias`), ADD FULLTEXT KEY `proyecto_video` (`proyecto_video`);

--
-- Indexes for table `proyecto_fotografias`
--
ALTER TABLE `proyecto_fotografias`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD FULLTEXT KEY `url` (`url`), ADD FULLTEXT KEY `pie` (`pie`);

--
-- Indexes for table `proyecto_video`
--
ALTER TABLE `proyecto_video`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD FULLTEXT KEY `video` (`video`), ADD FULLTEXT KEY `subtitulacion` (`subtitulacion`);

--
-- Indexes for table `tesauro_alfabetico`
--
ALTER TABLE `tesauro_alfabetico`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `tesauro_alfabetico_documento` (`tesauro_alfabetico_documento`);

--
-- Indexes for table `tesauro_alfabetico_documento`
--
ALTER TABLE `tesauro_alfabetico_documento`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`), ADD FULLTEXT KEY `tesauro_alfabetico_logo` (`tesauro_alfabetico_logo`), ADD FULLTEXT KEY `fecha` (`fecha`), ADD FULLTEXT KEY `html` (`html`), ADD FULLTEXT KEY `version` (`version`);

--
-- Indexes for table `tesauro_alfabetico_logo`
--
ALTER TABLE `tesauro_alfabetico_logo`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD FULLTEXT KEY `logo` (`logo`), ADD FULLTEXT KEY `logo_pie` (`logo_pie`);

--
-- Indexes for table `tesauro_jerarquico`
--
ALTER TABLE `tesauro_jerarquico`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `presentacion` (`presentacion`), ADD FULLTEXT KEY `tesauro_jerarquico_documento` (`tesauro_jerarquico_documento`);

--
-- Indexes for table `tesauro_jerarquico_documento`
--
ALTER TABLE `tesauro_jerarquico_documento`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `tesauro_jerarquico_logo` (`tesauro_jerarquico_logo`), ADD FULLTEXT KEY `version` (`version`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`), ADD FULLTEXT KEY `html` (`html`), ADD FULLTEXT KEY `fecha` (`fecha`);

--
-- Indexes for table `tesauro_jerarquico_logo`
--
ALTER TABLE `tesauro_jerarquico_logo`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD FULLTEXT KEY `logo_pie` (`logo_pie`), ADD FULLTEXT KEY `logo` (`logo`);

--
-- Indexes for table `tesauro_presentacion`
--
ALTER TABLE `tesauro_presentacion`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `documento_completo` (`documento_completo`), ADD FULLTEXT KEY `tesauro_presentacion_documento` (`tesauro_presentacion_documento`), ADD FULLTEXT KEY `presentacion_pdf` (`presentacion_pdf`), ADD FULLTEXT KEY `presentacion_general` (`presentacion_general`);

--
-- Indexes for table `tesauro_presentacion_documento`
--
ALTER TABLE `tesauro_presentacion_documento`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion` (`publicacion`), ADD FULLTEXT KEY `version` (`version`), ADD FULLTEXT KEY `fecha` (`fecha`), ADD FULLTEXT KEY `html` (`html`), ADD FULLTEXT KEY `titulo` (`titulo`), ADD FULLTEXT KEY `tesauro_presentacion_logo` (`tesauro_presentacion_logo`), ADD FULLTEXT KEY `doc_pdf` (`doc_pdf`);

--
-- Indexes for table `tesauro_presentacion_logo`
--
ALTER TABLE `tesauro_presentacion_logo`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD FULLTEXT KEY `logo` (`logo`), ADD FULLTEXT KEY `logo_pie` (`logo_pie`);

--
-- Indexes for table `titulos_busquedas`
--
ALTER TABLE `titulos_busquedas`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion_busqueda_semantica_combinada` (`publicacion_busqueda_semantica_combinada`), ADD KEY `publicacion_busqueda_avanzada` (`publicacion_busqueda_avanzada`), ADD KEY `publicacion_busqueda_libre` (`publicacion_busqueda_libre`), ADD KEY `publicacion_busqueda_acumulativa` (`publicacion_busqueda_acumulativa`), ADD KEY `publicacion_busqueda_semantica_simple` (`publicacion_busqueda_semantica_simple`), ADD FULLTEXT KEY `busqueda_semantica_simple` (`busqueda_semantica_simple`), ADD FULLTEXT KEY `busqueda_acumulativa` (`busqueda_acumulativa`), ADD FULLTEXT KEY `busqueda_libre` (`busqueda_libre`), ADD FULLTEXT KEY `busqueda_semantica_combinada` (`busqueda_semantica_combinada`), ADD FULLTEXT KEY `busqueda_avanzada` (`busqueda_avanzada`);

--
-- Indexes for table `titulos_visualizaciones`
--
ALTER TABLE `titulos_visualizaciones`
  ADD PRIMARY KEY (`id`), ADD KEY `id_matrix` (`id_matrix`), ADD KEY `lang` (`lang`), ADD KEY `publicacion_cronologica` (`publicacion_cronologica`), ADD KEY `publicacion_geografica` (`publicacion_geografica`), ADD KEY `publicacion_contextual` (`publicacion_contextual`), ADD KEY `publicacion_rostros` (`publicacion_rostros`), ADD FULLTEXT KEY `presentacion_cronologica` (`presentacion_cronologica`), ADD FULLTEXT KEY `presentacion_rostros` (`presentacion_rostros`), ADD FULLTEXT KEY `presentacion_contextual` (`presentacion_contextual`), ADD FULLTEXT KEY `presentacion_geografica` (`presentacion_geografica`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articulos_proyecto`
--
ALTER TABLE `articulos_proyecto`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `articulos_proyecto_portal`
--
ALTER TABLE `articulos_proyecto_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `concepcion_proyecto`
--
ALTER TABLE `concepcion_proyecto`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `concepcion_proyecto_portal`
--
ALTER TABLE `concepcion_proyecto_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `creditos`
--
ALTER TABLE `creditos`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `creditos_personas`
--
ALTER TABLE `creditos_personas`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `creditos_personas_imagen`
--
ALTER TABLE `creditos_personas_imagen`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `documentales`
--
ALTER TABLE `documentales`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `documentales_portal`
--
ALTER TABLE `documentales_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `enlaces_archivos_testimonios`
--
ALTER TABLE `enlaces_archivos_testimonios`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `enlaces_archivos_testimonios_portal`
--
ALTER TABLE `enlaces_archivos_testimonios_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `enlaces_fuentes_orales`
--
ALTER TABLE `enlaces_fuentes_orales`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `enlaces_fuentes_orales_portal`
--
ALTER TABLE `enlaces_fuentes_orales_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=213;
--
-- AUTO_INCREMENT for table `entrevistas_expertos`
--
ALTER TABLE `entrevistas_expertos`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `entrevistas_expertos_personas`
--
ALTER TABLE `entrevistas_expertos_personas`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `exposiciones_virtuales`
--
ALTER TABLE `exposiciones_virtuales`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `exposiciones_virtuales_portal`
--
ALTER TABLE `exposiciones_virtuales_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `formularios`
--
ALTER TABLE `formularios`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `formularios_precios`
--
ALTER TABLE `formularios_precios`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gestion_ho`
--
ALTER TABLE `gestion_ho`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `gestion_ho_portal`
--
ALTER TABLE `gestion_ho_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `info_legal`
--
ALTER TABLE `info_legal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `info_legal_doc`
--
ALTER TABLE `info_legal_doc`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `listado_entrevistados`
--
ALTER TABLE `listado_entrevistados`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `listado_entrevistados_logo`
--
ALTER TABLE `listado_entrevistados_logo`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `listado_entrevistados_portal`
--
ALTER TABLE `listado_entrevistados_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `listado_proyectos`
--
ALTER TABLE `listado_proyectos`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `listado_proyectos_logo`
--
ALTER TABLE `listado_proyectos_logo`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `listado_proyectos_portal`
--
ALTER TABLE `listado_proyectos_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `listado_resumen_entrevistas`
--
ALTER TABLE `listado_resumen_entrevistas`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `listado_resumen_entrevistas_logo`
--
ALTER TABLE `listado_resumen_entrevistas_logo`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `listado_resumen_entrevistas_portal`
--
ALTER TABLE `listado_resumen_entrevistas_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `protocolos_investigacion`
--
ALTER TABLE `protocolos_investigacion`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `protocolos_investigacion_portal`
--
ALTER TABLE `protocolos_investigacion_portal`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `proyecto`
--
ALTER TABLE `proyecto`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `proyecto_fotografias`
--
ALTER TABLE `proyecto_fotografias`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `proyecto_video`
--
ALTER TABLE `proyecto_video`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `tesauro_alfabetico`
--
ALTER TABLE `tesauro_alfabetico`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tesauro_alfabetico_documento`
--
ALTER TABLE `tesauro_alfabetico_documento`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tesauro_alfabetico_logo`
--
ALTER TABLE `tesauro_alfabetico_logo`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tesauro_jerarquico`
--
ALTER TABLE `tesauro_jerarquico`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tesauro_jerarquico_documento`
--
ALTER TABLE `tesauro_jerarquico_documento`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tesauro_jerarquico_logo`
--
ALTER TABLE `tesauro_jerarquico_logo`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tesauro_presentacion`
--
ALTER TABLE `tesauro_presentacion`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tesauro_presentacion_documento`
--
ALTER TABLE `tesauro_presentacion_documento`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tesauro_presentacion_logo`
--
ALTER TABLE `tesauro_presentacion_logo`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `titulos_busquedas`
--
ALTER TABLE `titulos_busquedas`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `titulos_visualizaciones`
--
ALTER TABLE `titulos_visualizaciones`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
