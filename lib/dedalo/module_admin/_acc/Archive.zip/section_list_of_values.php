<?php
	
	# CONTROLER
	
	
	$id					= $this->get_id();
	$tipo				= $this->get_tipo();
	$permissions		= common::get_permissions($tipo);
	$modo				= $this->get_modo();
	$ar_css				= $this->get_ar_css();
		
	$section_name		= false;
	
	$ar_section_list	= $this->get_list_by_tipo();
	
	
	# GROUPS HTML	
	//print_r($ar_groups); die();
	
	$ar_section_list_html	= $ar_section_list->get_html();	
		
		
		# LOAD PAGE
		switch($modo) {
			
			#case 'edit'	:  $page_html	= substr(__FILE__,0,-4).'.phtml';		break;
			#case 'list'				:  $page_html	= substr(__FILE__,0,-4).'_list.phtml';				break;
			#case 'list_of_values'	:  $page_html	= substr(__FILE__,0,-4).'_list_of_values.phtml';	break;	
		}
		$page_html	= substr(__FILE__,0,-4).'_list.phtml';			
		include($page_html);
		#exit();
		
		unset($ar_groups_html);
		unset($ar_titulos);
		unset($ar_components);				
		
	
	
	
?>