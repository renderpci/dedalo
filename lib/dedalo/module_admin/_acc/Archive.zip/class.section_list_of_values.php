<?php
require_once(DEDALO_LIB_BASE_PATH . '/component_common/class.component_common.php'); 
require_once(DEDALO_LIB_BASE_PATH . '/section_group/class.section_group.php');
require_once(DEDALO_ROOT . '/ts/class.RecordObj_ts.php');
 

class section_list_of_values extends common {
	
	protected $tipo;
	protected $modo;
	protected $lang;
	
	# STRUCTURE DATA
	protected $RecordObj_ts ;
	protected $modelo;
	protected $norden;
	protected $label;
	
	protected $ar_css;
	protected $section_name;
	protected $ar_section_list;
	protected $ar_buttons_tipo ;
	
	function __construct($tipo) {
		
		$this->tipo				= $tipo;
		$this->modo				= 'list';
		$this->lang 			= DEDALO_DATA_LANG ;
		$this->userID_matrix 	= navigator::get_userID_matrix();
		
		$this->load_structure_data();
	}	
	
	# HTML
	public function get_html() {
			
		$called_class		= get_called_class();
					
		$file = DEDALO_LIB_BASE_PATH .'/'.$called_class.'/'.$called_class.'.php' ; 
	
		ob_start();
		include ( $file ); #die("$file");
		$html =  ob_get_contents();
		ob_get_clean();			
		
		return $html;		
	}
	
	public function get_list_by_tipo() {
		
		$ar_list =array();
		
		$ar_childrens_of_this	= $this->RecordObj_ts->get_ar_childrens_of_this();
		
		if( is_array($ar_childrens_of_this) ) foreach($ar_childrens_of_this as $terminoID) {	
			
			$RecordObj_ts		= new RecordObj_ts($terminoID);
			$modeloID			= $RecordObj_ts->get_modelo();
			$modelo				= RecordObj_ts::get_termino_by_tipo($modeloID);
			
			switch($modelo) {
				
				# STORE BUTTONS OF SECTION
				case (strpos($modelo, 'button_') !== false)	: $this->ar_buttons_tipo[$modelo]	= $terminoID;									break;	
				
				# STORE SECTION LIST ARRAY
				case 'section_list'							: $ar_section_list		 	 = new section_list($terminoID, $this);			break;	
			}
			
		}		
		return $ar_section_list;
	}

}
?>